$(document).ready(function() {
    var showPopup = false;
    var hidePopup = true;
    var showPlay = true;
    let start = 1818;
    let duration = 5;
    let ShowFlag = false
    const ShowForm = 600
    document.getElementById('play').addEventListener('click', () => {
        window.scrollTo(0, 0)
        $('#play').fadeOut('fast', function() {
            $('#video').prop('muted', false).prop('currentTime', 0).trigger('play')
            $('#container_video').addClass('fullscreen')
            document.documentElement.classList.add('is-locked')
            $('#close').fadeIn()
            showPlay = false
        })
    })
    $('#video').on('timeupdate', function() {
        if(!ShowFlag && $(this).prop('currentTime') >= ShowForm){
            $('#order').fadeIn()
            ShowFlag = true
        }
        if (!showPlay && !showPopup && $(this).prop('currentTime') > start) {
            $('#popup').fadeIn('fast')
            showPopup = true;

        }
        if (hidePopup && $(this).prop('currentTime') > start + duration) {
            $('#popup').fadeOut('fast')
            hidePopup = false;
        }

    }).on('ended', showOrder)
    $('#popup').on('click', showOrder)
    $('#close').on('click', function() {
        $(this).hide()
        $('#container_video').removeClass('fullscreen')
        document.documentElement.classList.remove('is-locked')
    })

    function showOrder() {
        $('#container_video').removeClass('fullscreen')
        $("#play").css("display", "none");
        start_timer();
        document.documentElement.classList.remove('is-locked')
        $('#popup').fadeOut()
        $('#close').fadeOut()
        $('#video').fadeOut('fast', function() {
            $(this).trigger('pause')
            $('#order').fadeIn('fast', function() {
                $('html, body').animate({ scrollTop: $('#order').offset().top - 20 }, 200)
            })
        })
    }
})

var time = 600;
var intr;

function start_timer() {
    intr = setInterval(tick, 1000);
}

function tick() {
    time = time - 1;
    var mins = Math.floor(time / 60);
    var secs = time - mins * 60;
    if (mins == 0 && secs == 0) {
        clearInterval(intr);
    }
    secs = secs >= 10 ? secs : "0" + secs;
    mins = mins >= 10 ? mins : "0" + mins;
    $("#min").html(mins);
    $("#sec").html(secs);
}