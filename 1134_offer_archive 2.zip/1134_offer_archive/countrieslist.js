(function() {
    'use strict';

    window.countryList = {
        at: { name: 'Австрия', code: 'at', price: 49, oldPrice: 98, labelPrice: 'EUR', phoneHelper: 'Например +43 123456789', nameHelper: 'Maria Huber' },
        be: { name: 'Бельгия', code: 'be', price: 49, oldPrice: 98, labelPrice: 'EUR', phoneHelper: 'Например +32 1234567890', nameHelper: 'Marie Dupont' },
        bg: { name: 'Болгария', code: 'bg', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +359 123456789', nameHelper: 'Мария Иванова', isDefault: true },
        hu: { name: 'Венгрия', code: 'hu', price: 12900, oldPrice: 25800, labelPrice: 'HUF', phoneHelper: 'Например +36 123456789', nameHelper: 'Anna Nagy' },
        de: { name: 'Германия', code: 'de', price: 49, oldPrice: 98, labelPrice: 'EUR', phoneHelper: 'Например +49 123456789', nameHelper: 'Hannah Becker' },
        gr: { name: 'Греция', code: 'gr', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +30 0123456789', nameHelper: 'Maria Papadopoulou' },
        es: { name: 'Испания', code: 'es', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +34 123456789', nameHelper: 'María García' },
        it: { name: 'Италия', code: 'it', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +39 1234567890', nameHelper: 'Maria Rossi' },
        lv: { name: 'Латвия', code: 'lv', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +371 123456789', nameHelper: 'Sanita Berzina' },
        lt: { name: 'Литва', code: 'lt', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +370 123456789', nameHelper: 'Laima Daukante' },
        pl: { name: 'Польша', code: 'pl', price: 155, oldPrice: 310, labelPrice: 'PLN', phoneHelper: 'Например +48 123456789', nameHelper: 'Anna Kowalska' },
        pt: { name: 'Португалия', code: 'pt', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +351 123456789', nameHelper: 'Maria Silva' },
        ro: { name: 'Румыния', code: 'ro', price: 169, oldPrice: 338, labelPrice: 'RON', phoneHelper: 'Например +40 123456789', nameHelper: 'Maria Ionescu' },
        sk: { name: 'Словакия', code: 'sk', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +421 123456789', nameHelper: 'Anna Novak' },
        si: { name: 'Словения', code: 'si', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +386 123456789', nameHelper: 'Ana Novak' },
        hr: { name: 'Хорватия', code: 'hr', price: 44, oldPrice: 88, labelPrice: 'EUR', phoneHelper: 'Например +385 123456789', nameHelper: 'Ana Horvat' },
        cz: { name: 'Чехия', code: 'cz', price: 890, oldPrice: 1780, labelPrice: 'CZK', phoneHelper: 'Например +420 123456789', nameHelper: 'Anna Novak' },
        ch: { name: 'Швейцария', code: 'ch', price: 69, oldPrice: 138, labelPrice: 'CHF', phoneHelper: 'Например +41 123456789', nameHelper: 'Anna Müller' },
        ee: { name: 'Эстония', code: 'ee', price: 39, oldPrice: 78, labelPrice: 'EUR', phoneHelper: 'Например +372 123456789', nameHelper: 'Sofia Juurimaa' }
    };
})();
