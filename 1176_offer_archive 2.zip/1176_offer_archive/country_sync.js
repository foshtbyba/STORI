/*
 * Подключается ПОСЛЕ countrieslist.js и countries.js.
 * Логика анти-мислид:
 * 1) ?c=unknown — принудительный тест сценария «гео не определилось» (ручной выбор страны).
 * 2) ?c=de или ?country=de — явный код страны оффера -> сразу показываем «Вы из [страна]?» (Да / Нет).
 * 3) Без параметров — тройной каскад IP-геолокации (api.country.is -> ipwho.is -> ipapi.co):
 *    - Если IP входит в 19 стран оффера -> выставляем страну и показываем «Вы из [страна]?» (Да / Нет).
 *    - Если IP НЕ входит в список стран оффера (VPN / нецелевое гео) или все гео-сервисы недоступны ->
 *      вызываем window.onCountryUndetected(), открывая обязательный ручной выбор страны (сейв от мислида на дефолтную Австрию).
 */
document.addEventListener('DOMContentLoaded', function () {
  var selects = Array.prototype.slice.call(document.querySelectorAll('.country_select'));
  var countries = window.countryList || {};

  if (!selects.length) return;

  selects.forEach(function (select) {
    select.addEventListener('change', function () {
      selects.forEach(function (other) {
        if (other !== select) other.value = select.value;
      });
    });
  });

  var params = new URLSearchParams(window.location.search);
  var urlCode = (params.get('c') || params.get('country') || '').toLowerCase();

  if (urlCode === 'unknown' || urlCode === 'none') {
    notifyUndetected();
    return;
  }

  if (urlCode && countries[urlCode]) {
    applyCountry(urlCode);
    if (typeof window.onCountryConfirmed === 'function') {
      window.onCountryConfirmed(urlCode);
    }
    return;
  }

  detectByIP();

  function applyCountry(code) {
    if (selects[0]) {
      selects[0].value = code;
      selects[0].dispatchEvent(new Event('change'));
    }
  }

  function applyDetectedCode(rawCode) {
    var code = (rawCode || '').trim().toLowerCase();
    if (code && countries[code]) {
      applyCountry(code);
      if (typeof window.onCountryDetected === 'function') {
        window.onCountryDetected(code);
      }
      return true;
    }
    return false;
  }

  function notifyUndetected() {
    if (typeof window.onCountryUndetected === 'function') {
      window.onCountryUndetected();
    }
  }

  function detectByIP() {
    // 1. Быстрый JSON-сервис api.country.is
    requestJSON('https://api.country.is/', function (data) {
      if (data && data.country) {
        if (!applyDetectedCode(data.country)) {
          // IP определился корректно, но страна НЕ входит в список стран оффера (например VPN США/РФ/Нидерланды) -> сейв от мислида
          notifyUndetected();
        }
        return;
      }
      tryIpWhoIs();
    }, tryIpWhoIs);

    // 2. Резервный сервис ipwho.is
    function tryIpWhoIs() {
      requestJSON('https://ipwho.is/', function (data) {
        if (data && data.country_code) {
          if (!applyDetectedCode(data.country_code)) {
            notifyUndetected();
          }
          return;
        }
        tryIpApi();
      }, tryIpApi);
    }

    // 3. Резервный сервис ipapi.co
    function tryIpApi() {
      var done = false;
      function fallback() {
        if (done) return;
        done = true;
        notifyUndetected();
      }
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://ipapi.co/country_code/', true);
        xhr.timeout = 3000;
        xhr.onload = function () {
          if (done) return;
          done = true;
          if (xhr.status === 200 && xhr.responseText) {
            if (!applyDetectedCode(xhr.responseText)) {
              notifyUndetected();
            }
            return;
          }
          notifyUndetected();
        };
        xhr.onerror = fallback;
        xhr.ontimeout = fallback;
        xhr.send();
      } catch (e) {
        fallback();
      }
    }
  }

  function requestJSON(url, onSuccess, onFail) {
    var handled = false;
    function fail() {
      if (handled) return;
      handled = true;
      if (typeof onFail === 'function') onFail();
    }
    try {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.timeout = 2500;
      xhr.onload = function () {
        if (handled) return;
        if (xhr.status === 200) {
          try {
            var parsed = JSON.parse(xhr.responseText);
            handled = true;
            onSuccess(parsed);
            return;
          } catch (err) {}
        }
        fail();
      };
      xhr.onerror = fail;
      xhr.ontimeout = fail;
      xhr.send();
    } catch (e) {
      fail();
    }
  }
});
