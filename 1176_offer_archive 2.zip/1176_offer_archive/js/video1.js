$(document).ready(function () {
  var vid = document.getElementById("video");
  var $container = $("#container_video");
  var $play = $("#play");
  var $close = $("#close");
  var $fullscreenOrderBtn = $("#fullscreenOrderBtn");
  var $progressWrap = $("#vslProgressWrap");
  var $progressBar = $("#vslProgressBar");
  var $watchNotice = $("#watchNotice");
  var $orderFormSection = $("#order-form-section");
  var $orderArticle = $("#order");

  var UNLOCK_THRESHOLD = 0.15; // 15% a videóból — űrlap megnyitása a videó alatt
  var CTA_BTN_THRESHOLD = 0.95; // 95% a videóból — rendelés gomb megjelenítése a videó fölött
  var unlocked = false;
  var ctaBtnUnlocked = false;
  var timerStarted = false;

  if (!vid) return;

  function setPausedVisualState() {
    vid.style.filter = "brightness(0.55)";
    $play.css("display", "flex");
  }

  function setPlayingVisualState() {
    vid.style.filter = "brightness(1)";
    $play.hide();
    $progressWrap.show();
  }

  function enterFullscreen() {
    $container.addClass("fullscreen");
    $("body").addClass("noscroll");
    $close.css("display", "flex");
    if (ctaBtnUnlocked) {
      $fullscreenOrderBtn.fadeIn(200);
    }
  }

  function exitFullscreen(scrollToForm) {
    vid.pause();
    setPausedVisualState();
    $container.removeClass("fullscreen");
    $("body").removeClass("noscroll");
    $close.hide();
    $fullscreenOrderBtn.hide();

    if (scrollToForm && unlocked) {
      setTimeout(function () {
        $("html, body").animate(
          { scrollTop: $orderFormSection.offset().top - 70 },
          350
        );
      }, 60);
    }
  }

  vid.pause();
  vid.muted = true;
  setPausedVisualState();

  vid.addEventListener("canplay", function () {
    if (vid.paused) {
      vid.style.filter = "brightness(0.55)";
    }
  });

  function startOrTogglePlay() {
    if (vid.paused) {
      enterFullscreen();
      vid.muted = false;
      var playPromise = vid.play();
      setPlayingVisualState();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(function () {
          vid.muted = true;
          vid.play();
        });
      }
    } else {
      vid.pause();
      setPausedVisualState();
    }
  }

  $play.on("click", function (e) {
    e.stopPropagation();
    startOrTogglePlay();
  });

  $(vid).on("click", function (e) {
    e.stopPropagation();
    startOrTogglePlay();
  });

  $close.on("click", function (e) {
    e.stopPropagation();
    exitFullscreen(unlocked);
  });

  $fullscreenOrderBtn.on("click", function (e) {
    e.stopPropagation();
    exitFullscreen(true);
  });

  $(document).on("keydown", function (e) {
    if (e.key === "Escape" && $container.hasClass("fullscreen")) {
      exitFullscreen(unlocked);
    }
  });

  function unlockOrderSections(shouldScroll) {
    if (!unlocked) {
      unlocked = true;

      $watchNotice.html("&#10003; A kedvezményes program megnyílt — töltse ki az űrlapot lent");
      $watchNotice.addClass("watch-notice--unlocked");

      $orderFormSection.stop(true, true).slideDown(350);
      $orderArticle.stop(true, true).fadeIn(400);

      if (!timerStarted) {
        timerStarted = true;
        startTimer(600);
      }
    }

    if (shouldScroll) {
      if ($container.hasClass("fullscreen")) {
        exitFullscreen(true);
      } else {
        $("html, body").animate(
          { scrollTop: $orderFormSection.offset().top - 70 },
          350
        );
      }
    }
  }

  function unlockFullscreenCtaBtn() {
    if (ctaBtnUnlocked) return;
    ctaBtnUnlocked = true;
    if ($container.hasClass("fullscreen")) {
      $fullscreenOrderBtn.fadeIn(250);
    }
  }

  vid.addEventListener("timeupdate", function () {
    var dur = vid.duration;
    if (dur && isFinite(dur) && dur > 0) {
      var ratio = vid.currentTime / dur;
      var pct = Math.min(100, Math.max(0, ratio * 100));
      $progressBar.css("width", pct.toFixed(1) + "%");

      if (!unlocked && ratio >= UNLOCK_THRESHOLD) {
        unlockOrderSections(false);
      }
      if (!ctaBtnUnlocked && ratio >= CTA_BTN_THRESHOLD) {
        unlockFullscreenCtaBtn();
      }
    } else if (!unlocked && vid.currentTime >= 40) {
      unlockOrderSections(false);
    }
  });

  $(vid).on("ended", function () {
    unlockOrderSections(true);
  });

  var params = new URLSearchParams(window.location.search);
  if (params.get("unlock") === "1") {
    unlockOrderSections(false);
  }

  window.addEventListener("message", function (event) {
    if (event && event.data && event.data.type === "UNLOCK_FORM_PREVIEW") {
      unlockOrderSections(true);
    }
  });

  function startTimer(seconds) {
    var $timer = $(".timer_value");
    if (!$timer.length) return;
    var tick = function () {
      if (seconds <= 0) {
        $timer.text("00:00");
        return;
      }
      var m = Math.floor(seconds / 60);
      var s = seconds % 60;
      $timer.text(
        (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s
      );
      seconds--;
      setTimeout(tick, 1000);
    };
    tick();
  }
});
