/* global pysOptions */

! function ($, options) {
    if (options.debug) {
        console.log('PYS:', options);
    }

    var uniqueId = {};

    // State tracking for AND trigger logic: { eventId: { triggered: {}, total: N, fired: false } }
    var pysCustomEventsState = {};

    // State tracking for "once per page" fire frequency: { eventId: true }
    var pysEventFiredOnce = {};
    if (options.triggerLogic) {
        Object.entries(options.triggerLogic).forEach(function([eventId, logic]) {
            if (logic === 'AND') {
                var count = 0;
                Object.values(options.triggerEventTypes).forEach(function(events) {
                    if (events.hasOwnProperty(eventId)) count++;
                });
                pysCustomEventsState[eventId] = { triggered: {}, total: count, fired: false };
            }
        });
    }

    var firstVisit = false;

    var isTrackEventForGA = [];

    var isAdsLoad = false;

    let gtm_variables = {};
    let gtm_datalayername = "dynamicVariable";
    // Resolved by cookieDomain() on first use, not here.
    var probedCookieDomain = null;

    /**
     * Domain attribute for cookies we write. Probed once, on first use (not
     * at load) so the probe's own write lands behind whatever consent gate
     * the caller is behind.
     *
     * Not suppressed by options.cookie.disabled_all_cookie: deleting a
     * cookie needs the same domain it was written on, so suppressing here
     * would leave parent-scoped cookies in place while appearing removed.
     *
     * Memoised only after the probe runs, so a disabled_all_cookie or option
     * arriving later over REST is still honored.
     *
     * An answer already reported to PHP in pys_cd is reused, so the probe
     * runs once per visitor, not once per page load.
     */
    function cookieDomain() {
        if (probedCookieDomain !== null) {
            return probedCookieDomain;
        }
        if (!options || !options.hasOwnProperty("track_cookie_for_subdomains")
            || !options.track_cookie_for_subdomains) {
            return '';
        }
        probedCookieDomain = reportedCookieDomain();
        if (probedCookieDomain === null) {
            probedCookieDomain = probeCookieDomain();
        }
        return probedCookieDomain;
    }

    /**
     * The domain an earlier page load verified and stored in pys_cd, or
     * null when there is nothing usable and the probe has to run.
     *
     * The browser sending us pys_cd scoped to that domain is itself proof
     * the scope is accepted, so no probe is needed. The value is checked
     * against the current host on a label boundary; anything else (another
     * site's value, a tampered one) is ignored and the probe decides.
     *
     * A value with the shape of a public suffix (co.uk, github.io) is
     * test-written before it is trusted: the value is not the cookie's own
     * scope, so a sibling subdomain can plant one, and reusing it would
     * make every PYS cookie this visitor gets vanish. PHP validates the
     * same value only for its own writes; this covers ours. The test costs
     * one throwaway write, and only for values of that shape — see
     * suspiciousCookieDomain().
     *
     * 'host-only' is deliberately not reused: it may be a false negative
     * from a full cookie jar, and reportCookieDomain() replaces it once a
     * probe succeeds, so re-probing lets it self-heal. The other false
     * negative — a domain narrower than the registrable one, from the same
     * full jar — is accepted as is: it is reused and stays until pys_cd
     * expires (365 days) or is cleared, because re-probing it would put the
     * throwaway write back on every page load for every visitor.
     */
    function reportedCookieDomain() {
        var reported, host;
        try {
            reported = Cookies.get('pys_cd');
            host = String(location.hostname || '').toLowerCase();
        } catch (e) {
            return null;
        }
        if (!reported || reported === 'host-only') return null;
        reported = String(reported).toLowerCase();
        if (reported.indexOf('.') === -1 || !host) return null;
        if (host !== reported && host.slice(-(reported.length + 1)) !== '.' + reported) {
            return null;
        }
        if (suspiciousCookieDomain(reported) && !cookieDomainAccepted('.' + reported)) {
            return null;
        }
        return '.' + reported;
    }

    /**
     * Whether a reported domain has the shape of a public suffix and so
     * needs a test write before it is reused: two labels that are both
     * short (co.uk, com.au, net.br, ac.jp), or one of the multi-tenant
     * hosts whose registrable part is a subdomain (github.io, vercel.app).
     * A real two-label domain of that shape (hp.com) pays one throwaway
     * write per page load — what every site paid before pys_cd was reused.
     */
    function suspiciousCookieDomain(domain) {
        var labels = String(domain).split('.');
        if (labels.length === 2 && labels[0].length <= 3 && labels[1].length <= 3) {
            return true;
        }
        var known = ['github.io', 'vercel.app', 'pages.dev', 'wpcomstaging.com',
            'appspot.com', 'netlify.app', 'herokuapp.com', 'myshopify.com'];
        return known.indexOf(domain) !== -1;
    }

    /**
     * Find the broadest domain this browser will actually accept a cookie
     * on, walking from the broadest candidate inward.
     *
     * We used to rely on tldjs.getDomain(), but its bundled Public Suffix
     * List predates ~2018 and returns the public suffix itself for newer
     * domains (vercel.app, pages.dev, wpcomstaging.com), so cookies scoped
     * there were silently dropped. Asking the browser instead keeps us in
     * sync with its own current PSL.
     *
     * The probe cookie is written and removed synchronously, carries no
     * data, and never outlives this call. If a consent tool blocks the
     * write, cookieDomainAccepted() reports it rejected and we fall through
     * to host-only — the correct outcome.
     *
     * Returns '' when nothing works (IP/single-label host, or all writes
     * blocked); host-only is never rejected, so it's the safe floor.
     */
    function probeCookieDomain() {
        var host = '';
        try { host = String(location.hostname || ''); } catch (e) { return ''; }

        // No Domain attribute is valid for an IP literal or a dotless host.
        if (!host || host.indexOf('.') === -1) return '';
        if (host.indexOf(':') !== -1) return '';          // IPv6 literal
        if (/^[\d.]+$/.test(host)) return '';             // IPv4 literal

        var labels = host.split('.');
        // Broadest first: last two labels, then three, ... up to the full host.
        for (var take = 2; take <= labels.length; take++) {
            var candidate = '.' + labels.slice(labels.length - take).join('.');
            if (cookieDomainAccepted(candidate)) return candidate;
        }
        return '';
    }

    /**
     * Write a throwaway cookie at $candidate and report whether it stuck.
     * A false negative is possible if the jar is at its per-domain limit;
     * we then fall through to a narrower candidate and ultimately host-only.
     *
     * The name is fixed: consent scanners (Cookiebot and the like) record
     * every write, not the jar afterwards, and a random name made each
     * crawled page a new entry in the site's cookie declaration. The random
     * part lives in the value instead, which still tells this write apart
     * from a stale cookie left behind by an earlier, interrupted probe.
     */
    function cookieDomainAccepted(candidate) {
        var name = 'pys_dt';
        var value = String(Math.floor(Math.random() * 1e9));
        var accepted = false;
        try {
            document.cookie = name + '=' + value + '; path=/; domain=' + candidate + '; SameSite=Lax';
            accepted = ('; ' + document.cookie + ';').indexOf('; ' + name + '=' + value + ';') !== -1;
        } catch (e) {
            return false;
        } finally {
            // Remove either way; deleting an unset cookie is a no-op.
            try {
                document.cookie = name + '=; path=/; domain=' + candidate + '; max-age=0';
            } catch (e) {}
        }
        return accepted;
    }

    /**
     * Hand PHP the cookie domain that probeCookieDomain() verified, since
     * PHP has no Public Suffix List and guesses wrong on hosts like
     * shop.example.co.uk or mysite.github.io — scoping its cookies to a
     * public suffix the browser then drops.
     *
     * Value is the site's registrable domain (no PII, same for every
     * visitor); PHP validates it against the request host before use (see
     * pys_cookie_domain_resolve).
     *
     * Written from manageCookies() under the same consent gates as every
     * other cookie, not unconditionally.
     *
     * No domain at all is an answer too — see reportHostOnlyCookieDomain().
     */
    function reportCookieDomain(resolved) {
        var bare = resolved ? String(resolved).replace(/^\./, '') : '';
        if (!bare || bare.indexOf('.') === -1) {
            reportHostOnlyCookieDomain();
            return;
        }
        try {
            if (Cookies.get('pys_cd') === bare) return; // already reported
            // A 'host-only' answer from an earlier load is a separate jar
            // entry (no Domain attribute), and PHP reads whichever the
            // browser sends first — so it is removed, not outranked.
            Cookies.remove('pys_cd', { path: '/', domain: '' });
            Cookies.set('pys_cd', bare, {
                expires: 365,
                path: '/',
                domain: resolved,
                sameSite: 'Lax'
            });
        } catch (e) {}
    }

    /**
     * Tell PHP that host-only is the scope in use: the option asks for a
     * Domain attribute, but probeCookieDomain() found none this browser
     * accepts (a public-suffix host such as example.github.io, or every
     * candidate write refused). Without this PHP cannot tell "not answered
     * yet" from "never will", and withholds its own cookies for ever.
     *
     * Only with the option on: off, PHP writes host-only already and waits
     * for nothing. Never overwrites an existing report — a domain accepted
     * on an earlier load outranks a probe that failed on this one (a full
     * cookie jar gives a false negative).
     */
    function reportHostOnlyCookieDomain() {
        if (!options || !options.track_cookie_for_subdomains) return;
        try {
            if (Cookies.get('pys_cd') !== undefined) return; // an answer exists
            Cookies.set('pys_cd', 'host-only', {
                expires: 365,
                path: '/',
                sameSite: 'Lax'
            });
        } catch (e) {}
    }

    // Per-page referrer for Facebook CAPI events. Captured once per script
    // load so SPA-style navigations within the same HTML document do not
    // overwrite it. Internal/external is NOT filtered — Meta expects this
    // field to describe the URL of the previous page for THIS event.
    var pageReferrer = '';
    try {
        pageReferrer = stripUrlQuery((document.referrer || '').toString());
    } catch (e) {}

    // Session-entry referrer (fallback). Captured at session start the first
    // time the visitor lands from an EXTERNAL site, mirrored to a session
    // cookie so PHP can read it for orphan events (async/cron) that arrive
    // without a per-page payload. Never the primary source.
    var PYS_SESSION_ENTRY_REFERRER_KEY = 'pys_session_entry_referrer';
    function stripUrlQuery(url) {
        if (!url) return '';
        var clean = String(url);
        var q = clean.indexOf('?');
        if (q !== -1) clean = clean.substring(0, q);
        var h = clean.indexOf('#');
        if (h !== -1) clean = clean.substring(0, h);
        return clean;
    }
    var sessionEntryReferrer = '';
    function getOrInitSessionEntryReferrer(consentGranted) {
        var value = '';
        try {
            if (typeof window.sessionStorage !== 'undefined') {
                value = window.sessionStorage.getItem(PYS_SESSION_ENTRY_REFERRER_KEY) || '';
            }
        } catch (e) {}

        // Runs at script load; a consent tool's automatic blocking can hold
        // js.cookie back until consent, and the whole file must survive that.
        if (!value && typeof Cookies !== 'undefined') {
            var cookieValue = Cookies.get(PYS_SESSION_ENTRY_REFERRER_KEY);
            if (cookieValue && cookieValue !== 'undefined') {
                value = cookieValue;
                try {
                    if (typeof window.sessionStorage !== 'undefined') {
                        window.sessionStorage.setItem(PYS_SESSION_ENTRY_REFERRER_KEY, value);
                    }
                } catch (e) {}
            }
        }

        if (!value) {
            var raw = '';
            try {
                raw = stripUrlQuery((document.referrer || '').toString());
            } catch (e) {}
            if (raw) {
                var refHost = '';
                try {
                    refHost = new URL(raw).hostname;
                } catch (e) {}
                if (refHost && refHost !== window.location.hostname) {
                    value = raw;
                    try {
                        if (typeof window.sessionStorage !== 'undefined') {
                            window.sessionStorage.setItem(PYS_SESSION_ENTRY_REFERRER_KEY, value);
                        }
                    } catch (e) {}
                }
            }
        }

        // Mirror to a session cookie only once consent is given. The cookie
        // is session-scoped (no expires) and dies with the browser, just
        // like the sessionStorage entry.
        if (value && consentGranted && options && options.cookie
            && !options.cookie.disabled_all_cookie) {
            var existingCookie = Cookies.get(PYS_SESSION_ENTRY_REFERRER_KEY);
            if (!existingCookie || existingCookie === 'undefined') {
                Cookies.set(PYS_SESSION_ENTRY_REFERRER_KEY, value, { path: '/', domain: cookieDomain() });
            }
        }

        sessionEntryReferrer = value;
        return value;
    }

    // Populate sessionStorage / sessionEntryReferrer immediately. Cookie
    // mirroring is deferred to the consent-gated path in Facebook.loadPixel().
    getOrInitSessionEntryReferrer(false);

    // Per-page event referrer (session cookie). Snapshot of document.referrer
    // for the CURRENT page, refreshed on every page load. Read server-side
    // by saveFbTagsInOrder() to capture the buyer's checkout-page referrer
    // for orphan CAPI events (APT, gateway webhooks, manual status changes).
    // Internal URLs are intentionally NOT filtered — the goal is the page
    // that led the buyer to checkout, which is usually internal.
    // If document.referrer is empty (direct navigation), the previous value
    // is preserved so a session that began with an external referrer keeps
    // it across same-tab navigations.
    var PYS_EVENT_REFERRER_KEY = 'pys_event_referrer';
    function writeEventReferrerCookie() {
        if (!pageReferrer) {
            return;
        }
        if (!options || !options.cookie || options.cookie.disabled_all_cookie) {
            return;
        }
        try {
            Cookies.set(PYS_EVENT_REFERRER_KEY, pageReferrer, { path: '/', domain: cookieDomain() });
        } catch (e) {}
    }

    /**
     * Resolve parameter value based on mode (static or dynamic)
     *
     * @param {Object|string} param - Parameter object with { value, selector } or string value
     * @returns {string|null} - Resolved value
     */
    function resolveParamValue(param, key = '') {

        // 1️⃣ null / undefined - skip this parameter
        if (param === null || param === undefined) {
            return null;
        }

        // 2️⃣ primitive
        if (typeof param !== 'object') {
            return param;
        }

        // 3️⃣ array
        if (Array.isArray(param)) {
            return param.map(item => resolveParamValue(item, key));
        }

        // 4️⃣ NEW FORMAT OBJECT (config-object)
        const isConfigObject =
            ('value' in param || 'selector' in param || 'dynamic' in param || 'input_type' in param) &&
            Object.keys(param).every(k =>
                ['value','selector','dynamic','input_type','name'].includes(k)
            );

        if (isConfigObject) {

            // STATIC MODE
            const isStatic =
                !param.dynamic ||
                !param.selector ||
                param.selector.trim() === '';

            if (isStatic) {
                let value = param.value ?? null;

                if (param.input_type === "float" || param.input_type === "int") {
                    value = extractNumericValue(
                        value,
                        param.input_type === "int"
                    );
                }

                return value;
            }

            // DYNAMIC MODE
            try {
                const el = document.querySelector(param.selector);
                if (!el) return null;

                let value =
                    el.value ??
                    el.innerText ??
                    el.textContent ??
                    el.getAttribute("content") ??
                    el.getAttribute("data-value") ??
                    null;

                if (param.input_type === "float" || param.input_type === "int") {
                    value = extractNumericValue(
                        value,
                        param.input_type === "int"
                    );
                }

                return value;

            } catch {
                return null;
            }
        }

        // 5️⃣ Plain object (recursive traversal) - filter out null/undefined values
        return Object.fromEntries(
            Object.entries(param)
                .map(([k, v]) => [k, resolveParamValue(v, k)])
                .filter(([k, v]) => v !== null && v !== undefined)
        );
    }

    function extractNumericValue(value, isInt=false) {
        if (value === null || value === undefined) {
            return null;
        }
        if (isInt) {
            return parseInt(value);
        }
        return parseFloat(value);
    }

    var loadTags = [];

    var dummyPinterest = function () {

        /**
         * Public API
         */
        return {
            tag: function() {
                return "pinterest";
            },
            isEnabled: function () {},

            disable: function () {},

            loadPixel: function () {},

            fireEvent: function (name, data) {
                return false;
            },

            onAdSenseEvent: function (event) {},

            onClickEvent: function (params) {},

            onWatchVideo: function (params) {},

            onCommentEvent: function (event) {},

            onFormEvent: function (params) {},

            onDownloadEvent: function (params) {},



            onWooAddToCartOnButtonEvent: function (product_id) {},

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {},

            onWooRemoveFromCartEvent: function (cart_item_hash) {},

            onWooAffiliateEvent: function (product_id) {},

            onWooPayPalEvent: function (event) {},

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {},

            onEddRemoveFromCartEvent: function (item) {},

            onPageScroll: function (event) {},
            onTime: function (event) {

            },

        }

    }();

    var dummyBing = function () {

        /**
         * Public API
         */
        return {
            tag: function() {
                return "bing";
            },
            isEnabled: function () {},

            disable: function () {},

            loadPixel: function () {},

            fireEvent: function (name, data) {
                return false;
            },

            onAdSenseEvent: function (event) {},

            onClickEvent: function (params) {},

            onWatchVideo: function (params) {},

            onCommentEvent: function (event) {},

            onFormEvent: function (params) {},

            onDownloadEvent: function (params) {},


            onWooAddToCartOnButtonEvent: function (product_id) {},

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {},

            onWooRemoveFromCartEvent: function (cart_item_hash) {},

            onWooAffiliateEvent: function (product_id) {},

            onWooPayPalEvent: function (event) {},

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {},

            onEddRemoveFromCartEvent: function (item) {},
            onPageScroll: function (event) {},
            onTime: function (event) {

            },
        }

    }();

    var dummyReddit = function () {
        /**
         * Public API
         */
        return {
            tag: function () {
                return "reddit";
            },
            isEnabled: function () {
            },

            disable: function () {
            },

            loadPixel: function () {
            },

            fireEvent: function ( name, data ) {
                return false;
            },

            onAdSenseEvent: function ( event ) {
            },

            onClickEvent: function ( params ) {
            },

            onWatchVideo: function ( params ) {
            },

            onCommentEvent: function ( event ) {
            },

            onFormEvent: function ( params ) {
            },

            onDownloadEvent: function ( params ) {
            },

            onWooAddToCartOnButtonEvent: function ( product_id ) {
            },

            onWooAddToCartOnSingleEvent: function ( product_id, qty, product_type, is_external, $form ) {
            },

            onWooRemoveFromCartEvent: function ( cart_item_hash ) {
            },

            onWooAffiliateEvent: function ( product_id ) {
            },

            onWooPayPalEvent: function ( event ) {
            },

            onEddAddToCartOnButtonEvent: function ( download_id, price_index, qty ) {
            },

            onEddRemoveFromCartEvent: function ( item ) {
            },

            onPageScroll: function ( event ) {
            },

            onTime: function ( event ) {
            },
        }
    }();

    var Utils = function (options) {


        var Pinterest = dummyPinterest;

        var Bing = dummyBing;

	    var Reddit = dummyReddit;

        var gtag_loaded = false;

        var gtm_loaded = false;

        // The GTM container's consent state is sent once per page load. Two code
        // paths reach it (loadGTMScript() and the gtm_just_data_layer branch of
        // GTM.loadPixel(), which can both run for the same page), and Consent Mode
        // expects a single transition, not a stream of them.
        var gtm_consent_state_pushed = false;

        let isNewSession = checkSession();

        // In-flight pys_get_pbid request. Several code paths call manageCookies()
        // before the first reply lands; one request is enough for all of them.
        var pbidRequest = null;
        // True once a pixel has waited for that reply (or given up on it), so
        // the hold in holdForIdentity() happens at most once per page.
        var pbidSettled = false;
        var PBID_WAIT_MS = 1000;
        // A pys_get_pbid reply that arrived before options.cookie was known
        // (REST mode fills it in, and a consent plugin may call loadPixel()
        // before that). Applied by the next requestPbid() call instead of
        // asking the server again.
        var pbidPendingReply = null;

        let dataLayerName = 'dataLayerPYS';

        let GTMdataLayerName = 'dataLayer';


        function loadPixels() {

            Utils.refreshAddonPixels();

            Awin.loadPixel();

            if (!options.gdpr.all_disabled_by_api) {
                if (!options.gdpr.tiktok_disabled_by_api) {
                    TikTok.loadPixel();
                }

                if (!options.gdpr.openai_disabled_by_api) {
                    OpenAI.loadPixel();
                }

                if (!options.gdpr.facebook_disabled_by_api) {
                    Facebook.loadPixel();
                }

                if (!options.gdpr.analytics_disabled_by_api) {
                    Analytics.loadPixel();
                }

                if (!options.gdpr.google_ads_disabled_by_api) {
                    GAds.loadPixel();
                }

                if (!options.gdpr.analytics_disabled_by_api) {
                    GTM.loadPixel();
                }

                if (!options.gdpr.pinterest_disabled_by_api) {
                    Pinterest.loadPixel();
                }

                if (!options.gdpr.bing_disabled_by_api) {
                    Bing.loadPixel();
                }

                if (!options.gdpr.reddit_disabled_by_api) {
                    Reddit.loadPixel();
                }

            }
            if (options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== "undefined") {
                if (typeof CS_Data.cs_google_analytics_consent_mode !== "undefined" && CS_Data.cs_google_analytics_consent_mode == 1) {
                    Analytics.loadPixel();
                }
                if (typeof CS_Data.cs_google_ads_consent_mode !== "undefined" && CS_Data.cs_google_ads_consent_mode == 1 ) {
                    GAds.loadPixel();
                }
            }
        }

        /**
         * WATCHVIDEO UTILS
         */

        function isJSApiAttrEnabled(url) {
            return url.indexOf('enablejsapi') > -1;
        }

        function isOriginAttrEnabled(url) {
            return url.indexOf('origin') > -1;
        }

        // Returns key/value pairs of percentages: number of seconds to achieve
        function getVideoCompletionMarks(duration) {

            var marks = {};
            var points = [0, 10, 50, 90, 100];

            for (var i = 0; i < points.length; i++) {

                var _point = points[i];
                var _mark = _point + '%';
                var _time = duration * _point / 100;

                if (_point === 100) {
                    _time = _time - 1;
                }

                // 10% => 123
                marks[_mark] = Math.floor(_time);

            }

            return marks;

        }

        // Determine if the element is a YouTube video or not
        function tagIsYouTubeVideo(tag) {
            var src = tag.src || '';
            return src.indexOf('youtube.com/embed/') > -1 || src.indexOf('youtube.com/v/') > -1;
        }

        function tagIsYouTubeAsyncVideo(tag) {
            if(tag.src && tag.src.indexOf("data:image") !== -1) return false; // video is loaded
            var keys = Object.keys(tag.dataset);
            for(var i = 0;i<keys.length;i++) {
                if(keys[i].toLowerCase().indexOf("src") > -1) {
                    var src = tag.dataset[keys[i]];
                    return src.indexOf('youtube.com/embed/') > -1 || src.indexOf('youtube.com/v/') > -1;
                }
            }
            return false; //not find src
        }

        // Turn embed objects into iframe objects and ensure they have the right parameters
        function normalizeYouTubeIframe(tag) {

            var loc = window.location;
            var a = document.createElement('a');
            a.href = tag.src;
            a.hostname = 'www.youtube.com';
            a.protocol = loc.protocol;
            var tmpPathname = a.pathname.charAt(0) === '/' ? a.pathname : '/' + a.pathname; // IE10 shim

            if (!isJSApiAttrEnabled(a.search)) {
                a.search = (a.search.length > 0 ? a.search + '&' : '') + 'enablejsapi=1';
            }

            // for security reasons, YouTube wants an origin parameter set that matches our hostname
            if (!isOriginAttrEnabled(a.search) && loc.hostname.indexOf('localhost') === -1) {

                var port = loc.port ? ':' + loc.port : '';
                var origin = loc.protocol + '%2F%2F' + loc.hostname + port;

                a.search = a.search + '&origin=' + origin;

            }

            if (tag.type === 'application/x-shockwave-flash') {

                var newIframe = document.createElement('iframe');
                newIframe.height = tag.height;
                newIframe.width = tag.width;
                tmpPathname = tmpPathname.replace('/v/', '/embed/');

                tag.parentNode.parentNode.replaceChild(newIframe, tag.parentNode);

                tag = newIframe;

            }

            a.pathname = tmpPathname;

            if (tag.src !== a.href + a.hash) {
                tag.src = a.href + a.hash;
            }

            return tag;

        }

        // Add event handlers for events emitted by the YouTube API
        function addYouTubeEvents(iframe) {

            var player = YT.get(iframe.id);
            if (!player) {
                player = new YT.Player(iframe, {});
            }

            if (typeof iframe.pauseFlag === 'undefined') {

                iframe.pauseFlag = false;
                player.addEventListener('onStateChange', function (evt) {
                    onYouTubePlayerStateChange(evt, iframe);
                });

                player.addEventListener('onPlaybackRateChange', function(evt) {
                    var currRate = evt.data;
                    var prevRate = iframe._pysSpeedRate !== undefined ? iframe._pysSpeedRate : 1;
                    iframe._pysSpeedRate = currRate;
                    if(currRate == prevRate) return;
                    if (options.triggerEventTypes && options.triggerEventTypes.video_speed) {
                        var href = window.location.href;
                        var ytVideoId = '';
                        try { ytVideoId = player.getVideoData().video_id || ''; } catch(e) {}
                        Object.keys(options.triggerEventTypes.video_speed).forEach(function(evtId) {
                            var evtConfig   = options.triggerEventTypes.video_speed[evtId];
                            var urls        = Array.isArray(evtConfig) ? evtConfig : (evtConfig.urls || []);
                            var speedRate   = Array.isArray(evtConfig) ? 'any' : (evtConfig.speed_rate || 'any');
                            var evtTriggers = Array.isArray(evtConfig) ? [] : (evtConfig.triggers || []);
                            var pageOk      = !urls || urls.length === 0 || urls.some(function(u) { return u === '*' || u === '' || href.indexOf(u) !== -1; });
                            var rateOk      = speedRate === 'any' ? currRate !== prevRate : (speedRate === 'increase' ? currRate > prevRate : currRate < prevRate);
                            var videoOk     = evtTriggers.length === 0 || evtTriggers.some(function(t) { return t.type === 'youtube' && t.rule === ytVideoId; });
                            if (pageOk && rateOk && videoOk) {
                                Utils.handleTriggerFired(evtId, 'video_speed');
                            }
                        });
                    }
                    if (options.dynamicEvents && options.dynamicEvents.automatic_event_video_speed) {
                        var ytSpeedUrl = iframe.src || '';
                        var ytSpeedTitle = '';
                        try { ytSpeedTitle = player.getVideoData().title || ''; } catch(e) {}
                        var params = {
                            video_url: ytSpeedUrl,
                            video_type: 'youtube',
                            video_title: ytSpeedTitle || 'Unknown Title',
                            playback_speed: currRate,
                            element: 'iframe'
                        };
                        Object.keys(options.dynamicEvents.automatic_event_video_speed).forEach(function(slug) {
                            var pysEvent = Utils.clone(options.dynamicEvents.automatic_event_video_speed[slug]);
                            Utils.copyProperties(params, pysEvent.params);
                            var px = getPixelBySlag(slug); if (px) px.fireEvent(pysEvent.name, pysEvent);
                        });
                    }
                });

            }

        }

        function addDynYouTubeVideos(el) {
            // We only bind to iFrames with a YouTube URL with the enablejsapi=1 and
            // origin=<<hostname>> parameters
            if (el.tagName === 'IFRAME'
                && tagIsYouTubeVideo(el)
                && isJSApiAttrEnabled(el.src)
                && isOriginAttrEnabled(el.src))
            {
                addYouTubeEvents(el);
            }
        }

        // Event handler for events emitted from the YouTube API
        function onYouTubePlayerStateChange(evt, iframe) {

            var stateIndex = evt.data;
            var player = evt.target;
            var targetVideoUrl = player.getVideoUrl();
            var targetVideoId = targetVideoUrl.match(/[?&]v=([^&#]*)/)[1]; // Extract the ID
            var playerState = player.getPlayerState();
            var marks = getVideoCompletionMarks(player.getDuration());

            iframe.playTracker = iframe.playTracker || {};

            if (playerState === YT.PlayerState.PLAYING && !iframe.timer) {

                clearInterval(iframe.timer);

                // check every second to see if we've hit any of our percentage viewed marks
                iframe.timer = setInterval(function () {
                    checkYouTubeCompletion(player, marks, iframe.videoId);
                }, 1000);

            } else {

                clearInterval(iframe.timer);
                iframe.timer = false;

            }

            // playlist edge-case handler
            if (stateIndex === YT.PlayerState.PLAYING) {
                iframe.playTracker[targetVideoId] = true;
                iframe.videoId = targetVideoId;
                iframe.pauseFlag = false;
            }

            if (!iframe.playTracker[iframe.videoId]) {
                return false; // this video hasn't started yet, so this is spam
            }

            if (stateIndex === YT.PlayerState.PAUSED) {

                if (!iframe.pauseFlag) {
                    iframe.pauseFlag = true;
                } else {
                    return false; // we don't want to fire consecutive pause events
                }

            }

        }

        // Trigger event if YouTube video mark was reached
        function checkYouTubeCompletion(player, marks, videoId) {

            var currentTime = player.getCurrentTime();

            player[videoId] = player[videoId] || {};

            for (var key in marks) {

                if (marks[key] <= currentTime && !player[videoId][key]) {
                    player[videoId][key] = true;

                    var data = player.getVideoData();

                    if (key === '0%') {
                        key = 'play';
                    }

                    var params = {
                        video_type: 'youtube',
                        video_id: videoId,
                        video_title: data.title,
                    };

                    let disable_watch_video = [];

                    //Custom
                    if ( options.triggerEventTypes.hasOwnProperty( "video_view" ) ) {
                        Object.entries( options.triggerEventTypes.video_view ).forEach( function ( [ trigger_id, triggers ] ) {
                            triggers.forEach( function ( trigger ) {
                                if ( trigger.type === 'youtube' && trigger.rule === videoId ) {

                                    let pixels = Object.keys( options.triggerEvents[ trigger_id ] );
                                    for ( let i = 0; i < pixels.length; i++ ) {
                                        let event = Utils.clone( options.triggerEvents[ trigger_id ][ pixels[ i ] ] );

                                        if ( trigger.disable_watch_video ) {
                                            disable_watch_video.push( pixels[ i ] );
                                        }

                                        if ( currentTime >= marks[ trigger.value ] ) {
                                            if (pixels[i] !== 'reddit') {
                                                event.params["progress"] = key;
                                                Utils.copyProperties( params, event.params );
                                            }

                                            if ( event.fired !== true ) {
                                                if ( Utils.isEventInTimeWindow( event.name, event, 'dyn_' + pixels[ i ] + '_' + trigger_id ) ) {
                                                    event = Utils.getFormFilledData( event );
                                                    getPixelBySlag( pixels[ i ] ).fireEvent( event.name, event );
                                                    options.triggerEvents[ trigger_id ][ pixels[ i ] ].fired = true;
                                                }
                                            }
                                        }
                                    }
                                }
                            } )
                        } )
                    }

                    // Auto
                    if( options.automatic.enable_video
                        && options.automatic.enable_youtube
                        && options.dynamicEvents.hasOwnProperty("automatic_event_video")
                    ) {
                        var pixels = Object.keys(options.dynamicEvents.automatic_event_video);

                        for (var i = 0; i < pixels.length; i++) {
                            if ( disable_watch_video.includes( pixels[ i ] ) ) {
                                continue;
                            }
                            var event = Utils.clone(options.dynamicEvents.automatic_event_video[pixels[i]]);

                            if ( pixels[ i ] !== 'reddit' ) {
                                event.params[ "progress" ] = key;
                                Utils.copyProperties(params, event.params)
                            }

                            if ( pixels[i] === 'tiktok' || pixels[i] === 'reddit' ) {
                                var time_trigger = event.automatic_event_video_trigger;
                                if ( currentTime >= marks[time_trigger] && event.fired !== true ) {
                                    getPixelBySlag(pixels[i]).onWatchVideo(event);

                                    //tiktok and reddit watch video fire once
                                    options.dynamicEvents.automatic_event_video[pixels[i]].fired = true;
                                }
                            } else {
                                Utils.copyProperties(Utils.getRequestParams(), event.params);
                                getPixelBySlag(pixels[i]).onWatchVideo(event);
                            }
                        }
                    }

                    if(key == "play") {

                        $.each(options.triggerEventTypes, function (triggerType, events) {
                            $.each(events, function (eventId, triggers) {
                                switch (triggerType) {
                                    case 'video_play':
                                        Utils.handleTriggerFired(eventId, triggerType);
                                        break;
                                }

                            });
                        });
                    }

                }

            }

        }

        // Determine if the element is a Vimeo video or not
        function tagIsVimeoVideo(tag) {
            var src = tag.src || '';
            return src.indexOf('player.vimeo.com/video/') > -1;
        }

        function tagIsAsincVimeoVideo(tag) {
            if(tag.src) return false; // video is loaded
            var keys = Object.keys(tag.dataset);
            for(var i = 0;i<keys.length;i++) {
                if(keys[i].toLowerCase().indexOf("src") > -1) {
                    var src = tag.dataset[keys[i]];
                    return src.indexOf('player.vimeo.com/video/') > -1;
                }
            }
            return false; //not find src
        }

        function attachVimeoPlayerToTag(tag) {
            var player = new Vimeo.Player(tag);

            player.getDuration().then(function (pl,seconds) {
                pl.pysMarks = getVideoCompletionMarks(seconds);
            }.bind(null,player));

            player.getVideoTitle().then(function (pl,title) {
                pl.pysVideoTitle = title;
            }.bind(null,player));

            player.getVideoId().then(function (pl,id) {
                pl.pysVideoId = id;
            }.bind(null,player));

            player.pysCompletedMarks = {};

            player.on('play', function () {

                if (this.pysTimer) {
                    return;
                }

                clearInterval(this.pysTimer);

                var player = this;

                this.pysTimer = setInterval(function () {
                    checkVimeoCompletion(player);
                }, 1000);

            });

            player.on('pause', function () {
                clearInterval(this.pysTimer);
                this.pysTimer = false;
            });

            player.on('ended', function () {
                clearInterval(this.pysTimer);
                this.pysTimer = false;
            });

            player.on('playbackratechange', function(data) {
                var currRate = data.playbackRate;
                var prevRate = player._pysSpeedRate !== undefined ? player._pysSpeedRate : 1;
                player._pysSpeedRate = currRate;
                if(currRate == prevRate) return;
                if (options.triggerEventTypes && options.triggerEventTypes.video_speed) {
                    var href = window.location.href;
                    var vmVideoId = player.pysVideoId ? String(player.pysVideoId) : '';
                    Object.keys(options.triggerEventTypes.video_speed).forEach(function(evtId) {
                        var evtConfig   = options.triggerEventTypes.video_speed[evtId];
                        var urls        = Array.isArray(evtConfig) ? evtConfig : (evtConfig.urls || []);
                        var speedRate   = Array.isArray(evtConfig) ? 'any' : (evtConfig.speed_rate || 'any');
                        var evtTriggers = Array.isArray(evtConfig) ? [] : (evtConfig.triggers || []);
                        var pageOk      = !urls || urls.length === 0 || urls.some(function(u) { return u === '*' || u === '' || href.indexOf(u) !== -1; });
                        var rateOk      = speedRate === 'any' ? currRate !== prevRate : (speedRate === 'increase' ? currRate > prevRate : currRate < prevRate);
                        var videoOk     = evtTriggers.length === 0 || evtTriggers.some(function(t) { return t.type === 'vimeo' && t.rule == vmVideoId; });
                        if (pageOk && rateOk && videoOk) {
                            Utils.handleTriggerFired(evtId, 'video_speed');
                        }
                    });
                }
                if (options.dynamicEvents && options.dynamicEvents.automatic_event_video_speed) {
                    var vimeoEl = player.element || null;
                    var params = {
                        video_url: vimeoEl ? (vimeoEl.src || '') : '',
                        video_type: 'vimeo',
                        video_title: player.pysVideoTitle || 'Unknown Title',
                        playback_speed: currRate,
                        element: 'iframe'
                    };
                    Object.keys(options.dynamicEvents.automatic_event_video_speed).forEach(function(slug) {
                        var pysEvent = Utils.clone(options.dynamicEvents.automatic_event_video_speed[slug]);
                        Utils.copyProperties(params, pysEvent.params);
                        var px = getPixelBySlag(slug); if (px) px.fireEvent(pysEvent.name, pysEvent);
                    });
                }
            });
        }

        // Trigger event if Vimeo video mark was reached
        function checkVimeoCompletion(player) {

            player.getCurrentTime().then(function (seconds) {

                for (var key in player.pysMarks) {

                    if (player.pysMarks[key] <= seconds && !player.pysCompletedMarks[key]) {

                        player.pysCompletedMarks[key] = true;

                        if (key === '0%') {
                            key = 'play';
                        }

                        var params = {
                            video_type: 'vimeo',
                            video_id: player.pysVideoId,
                            video_title: player.pysVideoTitle,
                        };

                        let disable_watch_video = [];

                        //Custom
                        if ( options.triggerEventTypes.hasOwnProperty( "video_view" ) ) {
                            Object.entries( options.triggerEventTypes.video_view ).forEach( function ( [ trigger_id, triggers ] ) {
                                triggers.forEach( function ( trigger ) {
                                    if ( trigger.type === 'vimeo' && trigger.rule == player.pysVideoId ) {
                                        let pixels = Object.keys( options.triggerEvents[ trigger_id ] );
                                        for ( let i = 0; i < pixels.length; i++ ) {
                                            let event = Utils.clone( options.triggerEvents[ trigger_id ][ pixels[ i ] ] );

                                            if ( trigger.disable_watch_video ) {
                                                disable_watch_video.push( pixels[ i ] );
                                            }

                                            if ( seconds >= player.pysMarks[ trigger.value ] ) {
                                                if ( pixels[ i ] !== 'reddit' ) {
                                                    event.params[ "progress" ] = key;
                                                    Utils.copyProperties( params, event.params );
                                                }

                                                if ( event.fired !== true ) {
                                                    if ( Utils.isEventInTimeWindow( event.name, event, 'dyn_' + pixels[ i ] + '_' + trigger_id ) ) {
                                                        event = Utils.getFormFilledData( event );
                                                        getPixelBySlag( pixels[ i ] ).fireEvent( event.name, event );
                                                        options.triggerEvents[ trigger_id ][ pixels[ i ] ].fired = true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } )
                            } )
                        }

                        // Auto
                        if(options.automatic.enable_video
                            && options.automatic.enable_vimeo
                            && options.dynamicEvents.hasOwnProperty("automatic_event_video")
                        ) {
                            var pixels = Object.keys(options.dynamicEvents.automatic_event_video);

                            for (var i = 0; i < pixels.length; i++) {
                                if ( disable_watch_video.includes( pixels[ i ] ) ) {
                                    continue;
                                }

                                var event = Utils.clone(options.dynamicEvents.automatic_event_video[pixels[i]]);

                                if ( pixels[i] !== 'reddit' ) {
                                    event.params["progress"] = key;
                                    Utils.copyProperties(params, event.params);
                                }

                                if ( pixels[i] === 'tiktok' || pixels[i] === 'reddit' ) {
                                    var time_trigger = event.automatic_event_video_trigger;
                                    if ( seconds >= player.pysMarks[time_trigger] && event.fired !== true ) {
                                        getPixelBySlag(pixels[i]).onWatchVideo(event);

                                        //tiktok and reddit watch video fire once
                                        options.dynamicEvents.automatic_event_video[pixels[i]].fired = true;
                                    }
                                } else {
                                    Utils.copyProperties(Utils.getRequestParams(), event.params);
                                    getPixelBySlag(pixels[i]).onWatchVideo(event);
                                }
                            }
                        }

                        if(key == "play") {
                            $.each(options.triggerEventTypes, function (triggerType, events) {
                                $.each(events, function (eventId, triggers) {
                                    switch (triggerType) {
                                        case 'video_play':
                                            Utils.handleTriggerFired(eventId, triggerType);
                                            break;
                                    }

                                });
                            });
                        }
                    }

                }

            });

        }

        // ── HTML5 <video> WatchVideo tracking ───────────────────────────────────
        function initHtml5VideoTracking() {

            if ( !options.automatic.enable_video
                || !options.dynamicEvents.hasOwnProperty('automatic_event_video')
            ) {
                return;
            }

            // play event — fires once per element when playback starts
            document.addEventListener('play', function (e) {
                var el = e.target;
                if ( !el || el.tagName !== 'VIDEO' ) return;

                el.pysCompletedMarks = el.pysCompletedMarks || {};
                if ( el.pysCompletedMarks['play'] ) return;

                var url = el.src || el.currentSrc || '';
                el.pysCompletedMarks['play'] = true;

                fireHtml5VideoMilestone( el, url, 'play' );

            }, true );

            // timeupdate — check percentage milestones
            document.addEventListener('timeupdate', function (e) {
                var el = e.target;
                if ( !el || el.tagName !== 'VIDEO' ) return;

                var duration = el.duration;
                if ( !duration || isNaN(duration) || !isFinite(duration) ) return;

                var currentTime = el.currentTime;
                var marks = getVideoCompletionMarks( duration );
                var url   = el.src || el.currentSrc || '';

                el.pysCompletedMarks = el.pysCompletedMarks || {};

                for ( var key in marks ) {
                    if ( key === '0%' ) continue; // handled by 'play' listener

                    if ( marks[ key ] <= currentTime && !el.pysCompletedMarks[ key ] ) {
                        el.pysCompletedMarks[ key ] = true;
                        fireHtml5VideoMilestone( el, url, key );
                    }
                }

            }, true );
        }

        function fireHtml5VideoMilestone( el, url, key ) {

            var progressLabel = ( key === '0%' ) ? 'play' : key;

            var params = {
                video_type:  'html5',
                video_id:    el.id || url,
                video_title: Utils.getHtml5VideoTitle( url ),
            };

            var pixels = Object.keys( options.dynamicEvents.automatic_event_video );

            for ( var i = 0; i < pixels.length; i++ ) {
                var event = Utils.clone( options.dynamicEvents.automatic_event_video[ pixels[ i ] ] );

                if ( pixels[ i ] !== 'reddit' ) {
                    event.params[ 'progress' ] = progressLabel;
                    Utils.copyProperties( params, event.params );
                }

                if ( pixels[ i ] === 'tiktok' || pixels[ i ] === 'reddit' ) {
                    var time_trigger = event.automatic_event_video_trigger;
                    var marks        = getVideoCompletionMarks( el.duration || 0 );
                    if ( el.currentTime >= marks[ time_trigger ] && event.fired !== true ) {
                        getPixelBySlag( pixels[ i ] ).onWatchVideo( event );
                        options.dynamicEvents.automatic_event_video[ pixels[ i ] ].fired = true;
                    }
                } else {
                    Utils.copyProperties( Utils.getRequestParams(), event.params );
                    getPixelBySlag( pixels[ i ] ).onWatchVideo( event );
                }
            }

            // handle custom video_view triggers (mirrors YouTube/Vimeo pattern)
            if ( key === 'play' ) {
                $.each( options.triggerEventTypes, function ( triggerType, events ) {
                    $.each( events, function ( eventId ) {
                        if ( triggerType === 'video_play' ) {
                            Utils.handleTriggerFired( eventId, triggerType );
                        }
                    } );
                } );
            }
        }

        /**
         * COOKIES UTILS
         */

        var utmTerms = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content' ,'utm_term'];
        var utmId = ['fbadid', 'gadid', 'padid', 'bingid'];
        var requestParams = [];


        function getDomain(url) {

            url = url.replace(/(https?:\/\/)?(www.)?/i, '');

            if (url.indexOf('/') !== -1) {
                return url.split('/')[0];
            }

            return url;
        }

        function checkSession() {

            // Runs at script load; without js.cookie nothing can be known, and
            // "new session" is the answer every caller already handles.
            if( typeof Cookies === 'undefined' ||
                Cookies.get('pys_start_session') === undefined ||
                Cookies.get('pys_session_limit') === undefined) {
                firstVisit = true;
                return true
            }
            return false

        }

        function getTrafficSource() {

            try {

                let referrer = stripUrlQuery(document.referrer.toString()),
                    source;

                let direct = referrer.length === 0;
                let internal = direct ? false : referrer.indexOf(options.siteUrl) === 0;
                let external = !direct && !internal;

                if (external === false) {
                    source = 'direct';
                } else {
                    source = referrer;
                }

                if (source !== 'direct') {
                    // leave only domain (Issue #70)
                    return getDomain(source);
                } else {
                    return source;
                }

            } catch (e) {
                console.error(e);
                return 'direct';
            }

        }

        /**
         * Return query variables object with where property name is query variable
         * and property value is query variable value.
         */
        function getQueryVars() {

            try {

                var result = {},
                    tmp = [];

                window.location.search
                    .substr(1)
                    .split("&")
                    .forEach(function (item) {

                        tmp = item.split('=');

                        if (tmp.length > 1) {
                            result[tmp[0]] = tmp[1];
                        }

                    });

                return result;

            } catch (e) {
                console.error(e);
                return {};
            }

        }

        function getLandingPageValue() {
            let name = "pys_landing_page"
            if(options.visit_data_model === "last_visit") {
                name = "last_pys_landing_page"
            }
            if(Cookies.get(name) && Cookies.get(name) !== "undefined") {
                return Cookies.get(name);
            }
            // No cookie of our own. The dynamic-options endpoint may still know:
            // it answers per visitor and is never cached, so it is allowed to carry
            // the PHP session copy — which is all a visitor whose cookies a consent
            // manager has blocked ever has. In the HTML this value is always empty,
            // and an empty value means "nothing to say", so this branch is simply
            // skipped unless the endpoint filled it in.
            if ( options.hasOwnProperty( "tracking_analytics" )
                && options.tracking_analytics
                && options.tracking_analytics.TrafficLanding ) {
                return options.tracking_analytics.TrafficLanding;
            }

            // Nobody knows better than the current URL: it is what the cookie would
            // have been set to a moment ago.
            return window.location.href;
        }
        function getTrafficSourceValue() {
            let name = "pysTrafficSource"
            if(options.visit_data_model === "last_visit") {
                name = "last_pysTrafficSource"
            }
            if(Cookies.get(name) && Cookies.get(name) !== "undefined") {
                return Cookies.get(name);
            }
            // See getLandingPageValue(): filled by the dynamic-options endpoint only.
            if ( options.hasOwnProperty( "tracking_analytics" )
                && options.tracking_analytics
                && options.tracking_analytics.TrafficSource ) {
                return options.tracking_analytics.TrafficSource;
            }
            return "";
        }

        /**
         * Handle alternative GCLID parameter for Safari compatibility
         * Creates _gcl_aw cookie when alternative parameter is detected and _gcl_aw doesn't exist
         */
        function handleAlternativeGclid() {
            // Check if alternative GCLID is enabled
            if (!options.GATags || !options.GATags.gclid_alternative_enabled || !options.GATags.gclid_alternative_param) {
                return;
            }

            // GDPR consent checks - stop if any consent filter blocks it
            if (options.gdpr.all_disabled_by_api) {
                return;
            }
            if (options.gdpr.analytics_disabled_by_api) {
                return;
            }
            if (options.cookie.disabled_all_cookie) {
                return;
            }
            if (options.cookie.disabled_google_alternative_id) {
                return;
            }

            const alternativeParam = options.GATags.gclid_alternative_param;
            const queryVars = getQueryVars();

            // Check if alternative parameter exists in URL
            if (queryVars[alternativeParam]) {
                const gclidValue = queryVars[alternativeParam];

                // Only create _gcl_aw cookie if it doesn't exist
                if (!Cookies.get('_gcl_aw')) {
                    // Create _gcl_aw cookie with the alternative parameter value in Google's format
                    // Format: GCL.{timestamp}.{gclid_value}
                    const timestamp = Math.floor(Date.now() / 1000);
                    const cookieValue = 'GCL.' + timestamp + '.' + gclidValue;

                    // Set cookie for 90 days (Google's standard)
                    const expires = new Date();
                    expires.setTime(expires.getTime() + (90 * 24 * 60 * 60 * 1000));

                    Cookies.set('_gcl_aw', cookieValue, {
                        expires: expires,
                        path: '/',
                        domain: cookieDomain()
                    });

                    if (options.debug) {
                        console.log('PYS: Created _gcl_aw cookie from alternative parameter:', alternativeParam, '=', gclidValue);
                    }
                }
            }
        }

        function getUTMId(useLast = false) {
            try {
                let cookiePrefix = 'pys_'
                let terms = [];
                if (useLast) {
                    cookiePrefix = 'last_pys_'
                }
                // Fall back to this request's own query string, not to the server
                // options: cached HTML carries whatever the visitor who generated
                // the cache entry arrived with.
                let queryVars = getQueryVars();
                $.each(utmId, function (index, name) {
                    if (Cookies.get(cookiePrefix + name)) {
                        terms[name] = Cookies.get(cookiePrefix + name)
                    }
                    else if(options.hasOwnProperty("tracking_analytics")
                        && options.tracking_analytics
                        && options.tracking_analytics.TrafficUtmsId
                        && options.tracking_analytics.TrafficUtmsId[name]) {
                        terms[name] = filterEmails(options.tracking_analytics.TrafficUtmsId[name])
                    }
                    else if(queryVars.hasOwnProperty(name)) {
                        terms[name] = filterEmails(queryVars[name])
                    }
                });
                return terms;
            } catch (e) {
                console.error(e);
                return [];
            }
        }
        /**
         * Return UTM terms from request query variables or from cookies.
         */
        function getUTMs(useLast = false) {

            try {
                let cookiePrefix = 'pys_'
                if(useLast) {
                    cookiePrefix = 'last_pys_'
                }
                let terms = [];
                // See getUTMId(): the query string, never the server options.
                let queryVars = getQueryVars();
                $.each(utmTerms, function (index, name) {
                    if (Cookies.get(cookiePrefix + name)) {
                        let value = Cookies.get(cookiePrefix + name);
                        terms[name] = filterEmails(value); // do not allow email in request params (Issue #70)
                    }
                    else if(options.hasOwnProperty("tracking_analytics")
                        && options.tracking_analytics
                        && options.tracking_analytics.TrafficUtms
                        && options.tracking_analytics.TrafficUtms[name]) {
                        terms[name] = filterEmails(options.tracking_analytics.TrafficUtms[name])
                    }
                    else if(queryVars.hasOwnProperty(name)) {
                        terms[name] = filterEmails(queryVars[name])
                    }
                });

                return terms;

            } catch (e) {
                console.error(e);
                return [];
            }

        }

        function getDateTime() {
            var dateTime = new Array();
            var date = new Date(),
                days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
                months = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December'
                ],
                hours = ['00-01', '01-02', '02-03', '03-04', '04-05', '05-06', '06-07', '07-08',
                    '08-09', '09-10', '10-11', '11-12', '12-13', '13-14', '14-15', '15-16', '16-17',
                    '17-18', '18-19', '19-20', '20-21', '21-22', '22-23', '23-24'
                ];
            dateTime.push(hours[date.getHours()]);
            dateTime.push(days[date.getDay()]);
            dateTime.push(months[date.getMonth()]);
            return dateTime;
        }

        function filterEmails(value) {
            return Utils.validateEmail(value) ? undefined : value;
        }

        /**
         * PUBLIC API
         */
        return {

            PRODUCT_SIMPLE : 0,
            PRODUCT_VARIABLE : 1,
            PRODUCT_BUNDLE : 2,
            PRODUCT_GROUPED : 3,
            utmTerms : utmTerms,
            utmId : utmId,
            isNewSession: checkSession(),
            setHidePixelCookie: function(){
                let refresh_after_consent = false;
                if ( !firstVisit && options.gdpr.consent_magic_integration_enabled && window.CS_Data !== undefined && window.CS_Data.cs_refresh_after_consent) {
                    refresh_after_consent = true;
                }
                if( !refresh_after_consent && !firstVisit) return false;

                const url_parts = window.location.href;
                const url_params = new URLSearchParams(window.location.search);
                const matchingPixels = ["facebook", "ga", "gtm", "google_ads", "bing", "pinterest", "tiktok", "reddit", "openai"];
                $.each(matchingPixels, function (index, slug) {
                    var module = getPixelBySlag(slug);
                    if (module && module.isEnabled()) {
                        const fullUrl = window.location.href;
                        $.each(module.getHidePixel(), function (index, hide_info) {
                            for (const item of hide_info.hide_tag_contain) {
                                if (item && fullUrl.includes(item)) {
                                    let hideTagTimeInMilliseconds = hide_info.hide_tag_time * 60 * 60 * 1000;
                                    let expiresTime = new Date().getTime() + hideTagTimeInMilliseconds;
                                    Cookies.set('hide_tag_' + hide_info.pixel, true, { expires: new Date(expiresTime), path: '/' });
                                    break;
                                }
                            }
                        });
                    }

                });
            },
            /**
             * Is this Meta pixel opted into Meta-Enabled Conversion API?
             */
            isMetaEnabledCapiPixel: function (pixelId) {
                var pixels = options.facebook && options.facebook.metaEnabledCapiPixels;
                return Array.isArray(pixels) && pixels.indexOf(pixelId) !== -1;
            },
            hideMatchingPixel: function(pixelValue, slug) {
                if(Cookies.get('hide_tag_'+pixelValue))
                {
                    return true;
                }
                return false;
            },
            /**
             * Whether a send_to value actually points at a destination.
             *
             * gtag('event', name, { send_to: [] }) has no destination, so gtag.js
             * parks the hit until a matching config command appears. Tag Assistant
             * reports that as "Some hits will only be sent after a config command
             * is issued via gtag('config')". Callers must skip the event instead.
             */
            hasSendToTarget: function (target) {
                if (Array.isArray(target)) {
                    return target.length > 0;
                }
                return typeof target === 'string' && target !== '';
            },
            validateEmail: function (email) {
                var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(email);
            },
            fireEventForAllPixel:function(functionName,events){
                Utils.refreshAddonPixels();

                if (events.hasOwnProperty(Facebook.tag()))
                    Facebook[functionName](events[Facebook.tag()]);
                if (events.hasOwnProperty(Analytics.tag()))
                    Analytics[functionName](events[Analytics.tag()]);
                if (events.hasOwnProperty(GAds.tag()))
                    GAds[functionName](events[GAds.tag()]);
                if (events.hasOwnProperty(Pinterest.tag()))
                    Pinterest[functionName](events[Pinterest.tag()]);
                if (events.hasOwnProperty(Bing.tag()))
                    Bing[functionName](events[Bing.tag()]);
                if (events.hasOwnProperty(TikTok.tag()))
                    TikTok[functionName](events[TikTok.tag()]);
                if (events.hasOwnProperty(Reddit.tag()))
                    Reddit[functionName](events[Reddit.tag()]);

                if (events.hasOwnProperty(GTM.tag()))
                    GTM[functionName](events[GTM.tag()]);
            },

            getQueryValue:function (name){
                return getQueryVars()[name];
            },

            filterEmails: function (value) {
                return filterEmails(value);
            },

            /**
             * Re-read the pixels that live in separate plugins.
             */
            refreshAddonPixels: function () {
                Pinterest = Utils.setupPinterestObject();
                Bing = Utils.setupBingObject();
                Reddit = Utils.setupRedditObject();
            },

            /**
             * Is one of ConsentMagic's switches actually on?
             */
            csModeEnabled: function ( value ) {
                return Number( value ) === 1;
            },

            setupPinterestObject: function () {
                Pinterest = window.pys.Pinterest || Pinterest;
                return Pinterest;
            },

            setupBingObject: function () {
                Bing = window.pys.Bing || Bing;
                return Bing;
            },

            setupRedditObject: function () {
                Reddit = window.pys.Reddit || Reddit;
                return Reddit;
            },

            // Clone all object members to another and return it
            copyProperties: function (from, to) {
                for (var key in from) {
                    if("function" == typeof from[key]) {
                        continue;
                    }
                    to[key] = from[key];
                }
                return to;
            },

            getVideoTypeFromUrl: function (url) {
                if (!url) return 'unknown';
                if (url.indexOf('youtube.com') !== -1 || url.indexOf('youtu.be') !== -1) return 'youtube';
                if (url.indexOf('vimeo.com') !== -1) return 'vimeo';
                return 'html5';
            },

            getHtml5VideoTitle: function (url) {
                if (!url) return 'Unknown Title';
                var path = url.split('?')[0].split('#')[0];
                var filename = path.split('/').pop();
                if (!filename) return 'Unknown Title';
                var ext = filename.lastIndexOf('.');
                return ext > 0 ? filename.slice(0, ext) : filename;
            },

            /**
             * Generate unique ID
             *
             * For purchase events (woo_purchase, edd_purchase):
             * - Server eventID has priority (for server-browser deduplication)
             * - If server didn't provide eventID, generate one keyed by order_id
             *
             * For other events:
             * - Use existing logic with event type as key
             */
            generateUniqueId : function (event) {
                var eventsWithHook = [
                    'woo_purchase',
                    'woo_start_trial',
                    'woo_subscription_created',
                    'woo_subscription_renewal',
                    'edd_purchase',
                    'edd_start_trial',
                    'edd_subscription_created',
                    'edd_subscription_renewal',
                    'edd_license_created',
                    'edd_license_upgrade',
                    'edd_license_renewal'
                ];

                // For events with server hooks: prioritize server eventID
                if ( eventsWithHook.includes( event.e_id ) ) {
                    // If server provided eventID, use it (for deduplication)
                    if ( event.eventID && event.eventID.length > 0 ) {
                        var orderKey = event.e_id;
                        if ( !uniqueId.hasOwnProperty( orderKey ) ) {
                            uniqueId[orderKey] = event.eventID;
                        }
                        return uniqueId[orderKey];
                    }
                }

                if (
                    event.eventID.length == 0 ||
                    ( !event.isVariationTrigger &&
                        ( event.type == "static" && options.ajaxForServerStaticEvent ||
                            event.type !== "static" && options.ajaxForServerEvent )
                    )
                ) {
                    let idKey = event.hasOwnProperty('custom_event_post_id') ? event.custom_event_post_id : event.e_id;
                    if ( !uniqueId.hasOwnProperty( idKey ) ) {
                        uniqueId[idKey] = pys_generate_token();
                    }
                    return uniqueId[idKey];
                }
                else if ( event.eventID.length !== 0 ) {
                    return event.eventID;
                }
            },

            // Flatten object for sendBeacon compatibility
            flattenObject: function (obj, prefix = '', res = {}) {
                for (const [key, value] of Object.entries(obj)) {
                    const prefixedKey = prefix
                        ? (Array.isArray(obj) ? `${prefix}[${key}]` : `${prefix}[${key}]`)
                        : key;
                    if (value !== null && typeof value === 'object' && !(value instanceof File)) {
                        this.flattenObject(value, prefixedKey, res);
                    } else {
                        res[prefixedKey] = value;
                    }
                }
                return res;
            },

            sendServerAjaxRequest: function ( url, data ) {
                // Check if we should use REST API for TikTok or Facebook
                if (data.action === 'pys_tiktok_api_event' && window.pysTikTokRest) {
                    // Use TikTok REST API
                    this.sendRestAPIRequest(data, 'tiktok');
                    return;
                }

                if (data.action === 'pys_openai_api_event' && window.pysOpenAIRest) {
                    this.sendRestAPIRequest(data, 'openai');
                    return;
                }

                if (data.action === 'pys_api_event' && data.pixel === 'facebook' && window.pysFacebookRest) {
                    // Use Facebook REST API
                    this.sendRestAPIRequest(data, 'facebook');
                    return;
                }

                // Check if sendBeacon is enabled and supported
                if (options.useSendBeacon && navigator.sendBeacon) {
                    try {
                        // Flatten the data object for sendBeacon compatibility
                        const flattenedData = this.flattenObject(data);
                        const formData = new URLSearchParams();

                        // Convert flattened data to URLSearchParams
                        for (const [key, value] of Object.entries(flattenedData)) {
                            if (value !== null && value !== undefined) {
                                formData.append(key, value);
                            }
                        }

                        // Try to send using sendBeacon
                        const success = navigator.sendBeacon(url, formData);
                        if (success) {
                            return; // Successfully sent via sendBeacon
                        }
                    } catch (e) {
                        // If sendBeacon fails, fall back to jQuery.ajax
                        if (options.debug) {
                            console.log('PYS: sendBeacon failed, falling back to jQuery.ajax:', e);
                        }
                    }
                }

                // Fallback to jQuery.ajax
                jQuery.ajax( {
                    type: 'POST',
                    url: url,
                    data: data,
                    headers: {
                        'Cache-Control': 'no-cache'
                    },
                    success: function () {
                    },
                } );
            },

            purchaseMarkerSent: {},
            purchaseMarkerPlatforms: ['facebook', 'ga', 'google_ads', 'tiktok', 'pinterest', 'openai', 'bing', 'reddit'],

            // Tell the server which platforms the browser really sent the thank-you
            // Purchase to (see PurchaseDelivery on the PHP side). Never throws: a
            // missing marker only makes the server fall back after its grace window.
            sendPurchaseMarker: function ( marker, platform ) {
                try {
                    if ( !marker || !marker.type || !marker.order_id || !marker.token || !platform ) {
                        return;
                    }

                    var key = marker.type + ':' + marker.order_id + ':' + platform;
                    if ( Utils.purchaseMarkerSent[key] ) {
                        return;
                    }
                    Utils.purchaseMarkerSent[key] = true;

                    if ( navigator.sendBeacon ) {
                        try {
                            var formData = new FormData();
                            formData.append( 'action', 'pys_purchase_marker' );
                            formData.append( 'type', marker.type );
                            formData.append( 'order_id', marker.order_id );
                            formData.append( 'token', marker.token );
                            formData.append( 'platforms[]', platform );

                            if ( navigator.sendBeacon( options.ajaxUrl, formData ) ) {
                                return;
                            }
                        } catch ( e ) {
                            if ( options.debug ) {
                                console.log( 'PYS: sendBeacon failed, falling back to jQuery.ajax:', e );
                            }
                        }
                    }

                    // Fallback to jQuery.ajax
                    jQuery.ajax( {
                        type: 'POST',
                        url: options.ajaxUrl,
                        data: {
                            action: 'pys_purchase_marker',
                            type: marker.type,
                            order_id: marker.order_id,
                            token: marker.token,
                            platforms: [ platform ]
                        },
                        headers: {
                            'Cache-Control': 'no-cache'
                        },
                        success: function () {
                        },
                    } );
                } catch ( e ) {
                    if ( options.debug ) {
                        console.log( 'PYS: purchase marker failed:', e );
                    }
                }
            },

            // Send event via REST API (unified function for TikTok, Facebook, and other platforms)
            // Replaces the old sendTikTokRestAPIRequest and sendFacebookRestAPIRequest functions
            sendRestAPIRequest: function (data, platform) {
                let restApiUrl;

                // Get platform-specific REST API configuration
                switch (platform) {
                    case 'tiktok':
                        restApiUrl = window.pysTikTokRest ? window.pysTikTokRest.restApiUrl : '/wp-json/pys-tiktok/v1/event';
                        break;
                    case 'facebook':
                        restApiUrl = window.pysFacebookRest ? window.pysFacebookRest.restApiUrl : '/wp-json/pys-facebook/v1/event';
                        break;
                    case 'pinterest':
                        restApiUrl = window.pysPinterestRest ? window.pysPinterestRest.restApiUrl : '/wp-json/pys-pinterest/v1/event';
                        break;
                    case 'openai':
                        restApiUrl = window.pysOpenAIRest ? window.pysOpenAIRest.restApiUrl : '/wp-json/pys-openai/v1/event';
                        break;
                    default:
                        console.error('PYS: Unknown platform for REST API:', platform);
                        this.sendAjaxFallback(data);
                        return;
                }

                // Prepare data for REST API
                const restApiData = {
                    event: data.event,
                    event_slug: data.event_slug,
                    data: JSON.stringify(data.data || {}),
                    ids: JSON.stringify(data.ids || []),
                    eventID: data.event_id || data.eventID || '',
                    woo_order: data.woo_order || '0',
                    edd_order: data.edd_order || '0',
                    order_key: data.order_key || ''
                };

                // Facebook-only: forward the per-page referrer so the CAPI
                // helper can attach it to custom_data.referrer_url.
                if (platform === 'facebook') {
                    const forwardedReferrer = data.referrer_url || pageReferrer;
                    if (forwardedReferrer) {
                        restApiData.referrer_url = forwardedReferrer;
                    }
                }

                // Variant A: send the actual page URL where the event happened
                // so the server sets event_source_url to this page, not the
                // REST endpoint. PHP applies enable_remove_source_url_params.
                restApiData.event_source_url = data.url || window.location.href;

                // Try to send using sendBeacon first (if enabled)
                if (options.useSendBeacon && navigator.sendBeacon) {
                    try {
                        const formData = new URLSearchParams();
                        for (const [key, value] of Object.entries(restApiData)) {
                            formData.append(key, value);
                        }

                        if (navigator.sendBeacon(restApiUrl, formData)) {
                            return;
                        }
                    } catch (e) {
                        // sendBeacon failed, continue to fetch
                    }
                }

                // Try to send using fetch with REST API
                if (window.fetch) {
                    const headers = {
                        'Content-Type': 'application/json'
                    };

                    fetch(restApiUrl, {
                        method: 'POST',
                        headers: headers,
                        body: JSON.stringify(restApiData)
                    })
                        .then(response => {
                            if (!response.ok) {
                                const err = new Error(platform + ' REST API request failed: ' + response.status);
                                // Server overloaded: admin-ajax would only add load, so do not fall back
                                err.noFallback = [429, 502, 503, 504, 520, 521, 522, 523, 524].indexOf(response.status) !== -1;
                                throw err;
                            }
                        })
                        .catch(error => {
                            if (error && error.noFallback) {
                                if (options.debug) {
                                    console.log('PYS: ' + platform + ' REST API overloaded, AJAX fallback skipped:', error);
                                }
                                return;
                            }
                            // Fallback to AJAX if REST API fails
                            if (options.debug) {
                                console.log('PYS: ' + platform + ' REST API failed, falling back to AJAX:', error);
                            }
                            this.sendAjaxFallback(data);
                        });
                } else {
                    // Fallback to AJAX if fetch is not supported
                    this.sendAjaxFallback(data);
                }
            },



            // Fallback AJAX method
            sendAjaxFallback: function (data) {
                jQuery.ajax({
                    type: 'POST',
                    url: options.ajaxUrl,
                    data: data,
                    headers: {
                        'Cache-Control': 'no-cache'
                    },
                    success: function () {
                    },
                });
            },

            clone: function(obj) {
                var copy;

                // Handle the 3 simple types, and null or undefined
                if (null == obj || "object" != typeof obj) return obj;

                // Handle Date
                if (obj instanceof Date) {
                    copy = new Date();
                    copy.setTime(obj.getTime());
                    return copy;
                }

                // Handle Array
                if (obj instanceof Array) {
                    copy = [];
                    for (var i = 0, len = obj.length; i < len; i++) {
                        if("function" == typeof obj[i]) {
                            continue;
                        }
                        copy[i] = Utils.clone(obj[i]);
                    }
                    return copy;
                }

                // Handle Object
                if (obj instanceof Object) {
                    copy = {};
                    for (var attr in obj) {
                        if (obj.hasOwnProperty(attr)) {
                            if("function" == typeof obj[attr]) {
                                continue;
                            }
                            copy[attr] = Utils.clone(obj[attr]);
                        }
                    }
                    return copy;
                }

                return obj;
            },

            // Returns array of elements with given tag name
            getTagsAsArray: function (tag) {
                return [].slice.call(document.getElementsByTagName(tag));
            },


            initializeVideoAPIs: function (options) {
                let trigger_has_video_YT, trigger_has_video_Vimeo = false;
                if (options.hasOwnProperty('automatic') && options.automatic.enable_video) {
                    if ( options.triggerEventTypes.hasOwnProperty( "video_view" ) ) {
                        Object.entries( options.triggerEventTypes.video_view ).forEach( function ( [ trigger_id, triggers ] ) {
                            triggers.forEach( function ( trigger ) {
                                if (trigger.type === 'youtube') {
                                    trigger_has_video_YT = true;
                                }
                                if(trigger.type === 'vimeo'){
                                    trigger_has_video_Vimeo = true;
                                }
                            });
                        });
                    }
                    if (
                        options.hasOwnProperty('enable_automatic_events') &&
                        options.enable_automatic_events
                    ) {
                        if (options.automatic.enable_youtube || trigger_has_video_YT) {
                            Utils.initYouTubeAPI();
                        }
                        if (options.automatic.enable_vimeo || trigger_has_video_Vimeo) {
                            Utils.initVimeoAPI();
                        }
                        initHtml5VideoTracking();
                    }
                }

                // Also init YT/Vimeo APIs for video_speed custom triggers and global VideoSpeed event
                var has_video_speed_trigger = options.triggerEventTypes && options.triggerEventTypes.hasOwnProperty('video_speed') &&
                    Object.keys(options.triggerEventTypes.video_speed).length > 0;
                var has_global_video_speed = options.dynamicEvents && options.dynamicEvents.hasOwnProperty('automatic_event_video_speed');
                if (has_video_speed_trigger || has_global_video_speed) {
                    Utils.initYouTubeAPI();
                    Utils.initVimeoAPI();
                }
            },
            /**
             * Load and initialize YouTube API
             *
             * @link: https://developers.google.com/youtube/iframe_api_reference
             */
            initYouTubeAPI: function () {

                // maybe load YouTube JS API
                if (typeof window.YT === 'undefined') {
                    var tag = document.createElement('script');
                    tag.src = '//www.youtube.com/iframe_api';
                    var firstScriptTag = document.getElementsByTagName('script')[0];
                    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
                }

                // initialize when API is ready
                if ( typeof window.onYouTubeIframeAPIReady !== 'function' ) {

                    window.onYouTubeIframeAPIReady = function () {

                        // collect all possible YouTube tags
                        var potentialVideos = Utils.getTagsAsArray( 'iframe' ).concat( Utils.getTagsAsArray( 'embed' ) );

                        // turn videos into trackable videos with events
                        for ( var i = 0; i < potentialVideos.length; i++ ) {
                            var video = potentialVideos[ i ];
                            if ( tagIsYouTubeVideo( video ) ) {
                                var iframe = normalizeYouTubeIframe( video );
                                addYouTubeEvents( iframe );
                            } else if ( tagIsYouTubeAsyncVideo( video ) ){
                                video.addEventListener( "load", function ( evt ) {
                                    var iframe = normalizeYouTubeIframe( evt.currentTarget );
                                    addYouTubeEvents( iframe );
                                } );
                            }
                        }

                        var targets = document.querySelectorAll( '.elementor-widget-video .elementor-wrapper' );

                        const config = {
                            attributes: false,
                            childList: true,
                            subtree: true
                        };

                        const callback = function ( mutationsList, observer ) {
                            for ( let mutation of mutationsList ) {
                                if ( mutation.type === 'childList' ) {
                                    for ( var m = 0; m < mutation.addedNodes.length; m++ ) {
                                        addDynYouTubeVideos( mutation.addedNodes[ m ] );
                                    }
                                }
                            }
                        };
                        // observe elementator widget-video and add event when it add iframe
                        for ( var i = 0; i < targets.length; i++ ) {
                            const observer = new MutationObserver( callback );
                            observer.observe( targets[ i ], config );//maybe remove before add
                        }
                    }
                }
            },

            /**
             * Load and initialize Vimeo API
             *
             * @link: https://github.com/vimeo/player.js
             */
            initVimeoAPI: function () {


                $(document).ready(function () {

                    var potentialVideos = Utils.getTagsAsArray('iframe').concat(Utils.getTagsAsArray('embed'));

                    for (var i = 0; i < potentialVideos.length; i++) {
                        var tag = potentialVideos[i];
                        if (tagIsVimeoVideo(tag)) {
                            var nextElementHasClass = $(tag).closest('.elementor-widget-video').find('.elementor-custom-embed-image-overlay');
                            if(nextElementHasClass.length > 0) {
                                tag.addEventListener("load", function() {
                                    attachVimeoPlayerToTag(this);
                                });
                            }
                            else {
                                attachVimeoPlayerToTag(tag);
                            }


                        } else {
                            if (tagIsAsincVimeoVideo(tag)) {
                                tag.addEventListener("load", function(evt) {
                                    attachVimeoPlayerToTag(evt.currentTarget);
                                });
                            }
                        }
                    }

                });

            },

            /**
             * Ask PHP for this browser's external_id (single-flight).
             *
             * The cookie keeps the id across a network change, so it is
             * requested whenever external_id is on -- not only when server
             * events go over AJAX. Returns the in-flight jqXHR, or null when no
             * request is warranted (feature off, cookie already there, no
             * Meta pixel).
             */
            requestPbid: function () {
                if (!options.send_external_id || Cookies.get('pbid') || !Facebook.isEnabled()) {
                    return null;
                }

                if (!pbidRequest) {
                    var deferred = jQuery.Deferred();

                    var applyReply = function (res) {
                        if (typeof options.cookie === 'undefined') {
                            pbidPendingReply = res;
                            return;
                        }
                        pbidPendingReply = null;
                        if (res && res.success && res.data && res.data.pbid) {
                            if(!(options.cookie.disabled_all_cookie || options.cookie.externalID_disabled_by_api)){
                                var expires = parseInt(options.external_id_expire || 180);
                                Cookies.set('pbid', res.data.pbid, { expires: expires,path: '/',domain: cookieDomain() });
                            }

                            if(options.hasOwnProperty('facebook')) {
                                options.facebook.advancedMatching = {
                                    ...options.facebook.advancedMatching,  // spread current advancedMatching values
                                    external_id: res.data.pbid
                                };
                            }
                        }
                    };

                    var settle = function (res) {
                        try {
                            applyReply(res);
                        } catch (e) {
                            if (options.debug) console.warn('[PYS] pbid reply:', e);
                        }
                        deferred.resolve(res);
                    };

                    var viaAjax = function () {
                        jQuery.ajax({
                            url: options.ajaxUrl,
                            dataType: 'json',
                            data: {
                                action: 'pys_get_pbid'
                            }
                        }).done(settle).fail(function () {
                            deferred.reject();
                        });
                    };

                    // The head snippet (EventsManager::outputPbidPrefetch()) may
                    // have started this request before public.js was even
                    // downloaded; reuse its reply, and only make our own request
                    // when there is none or it failed.
                    var prefetch = window.pysPbidPrefetch;
                    window.pysPbidPrefetch = null;

                    if (pbidPendingReply && typeof options.cookie !== 'undefined') {
                        applyReply(pbidPendingReply);
                        if (Cookies.get('pbid')) {
                            return null;
                        }
                    }

                    if (prefetch && typeof prefetch.then === 'function') {
                        prefetch.then(settle, viaAjax);
                    } else {
                        viaAjax();
                    }

                    pbidRequest = deferred.promise();
                    pbidRequest.always(function () {
                        pbidRequest = null;
                    });
                }

                return pbidRequest;
            },

            /**
             * Defer `fn` until this browser's external_id is known, or until a
             * short ceiling passes. Returns true when `fn` was deferred (it will
             * be called back), false when the caller may go ahead right now.
             *
             * Pixels read external_id when they initialise. On a first visit the
             * cookie does not exist yet, and the inline value in the page may
             * belong to whoever rendered a cached copy of it; the reply to
             * pys_get_pbid is never cached and names this browser, so the first
             * PageView waits for it. Sites that fetch identity over REST already
             * have the right value by now and do not wait again.
             */
            holdForIdentity: function (fn) {
                if (pbidSettled || !options.send_external_id || Cookies.get('pbid')) {
                    return false;
                }

                if (options.dynamicDataUrl && options.facebook && options.facebook.advancedMatching
                    && options.facebook.advancedMatching.external_id) {
                    return false;
                }

                var request = Utils.requestPbid();
                if (!request) {
                    return false;
                }

                var done = false;
                var finish = function () {
                    if (done) {
                        return;
                    }
                    done = true;
                    pbidSettled = true;
                    fn();
                };

                request.always(finish);
                setTimeout(finish, PBID_WAIT_MS);

                return true;
            },

            manageCookies: function () {
                if ( typeof options.cookie === 'undefined' ) {
                    return;
                }

                // Handle alternative GCLID parameter for Safari compatibility
                handleAlternativeGclid();

                if (options.gdpr.cookiebot_integration_enabled && typeof Cookiebot !== 'undefined') {
                    if (Cookiebot.consented === false && !Cookiebot.consent['marketing'] && !Cookiebot.consent['statistics']) {
                        return;
                    }
                }

                let cm_consent_not_expressed = false;
                if ( options.gdpr.consent_magic_integration_enabled && window.CS_Data !== undefined && window.CS_Data.cs_refresh_after_consent == 1 ) {
                    if ( Cookies.get( 'cs_viewed_cookie_policy' ) === undefined ) {
                        cm_consent_not_expressed = true;
                    }
                }

                // Hand PHP the browser-verified cookie domain, under the same
                // consent gates as every cookie written below it.
                if( !cm_consent_not_expressed && !options.cookie.disabled_all_cookie ) {
                    reportCookieDomain(cookieDomain());
                }

                if( !cm_consent_not_expressed && isNewSession && !options.cookie.disabled_all_cookie && !options.cookie.disabled_start_session_cookie) {
                    let duration = options.last_visit_duration * 60000
                    var now = new Date();
                    now.setTime(now.getTime() + duration);
                    Cookies.set('pys_session_limit', true,{ expires: now, path: '/',domain: cookieDomain() })
                    Cookies.set('pys_start_session', true,{ path: '/',domain: cookieDomain() });
                    Utils.setHidePixelCookie();
                }

                if (!Cookies.get('pbid')) {
                    Utils.requestPbid();
                } else if (Facebook.isEnabled()){
                    if(options.hasOwnProperty('facebook')) {
                        options.facebook.advancedMatching = {
                            ...options.facebook.advancedMatching,
                            external_id: Cookies.get('pbid')
                        };
                    }
                }
                let expires = parseInt(options.cookie_duration); //  days
                let queryVars = getQueryVars();
                let landing = window.location.href;
                try {
                    // save data for first visit
                    if(Cookies.get('pys_first_visit') === undefined && (!options.cookie.disabled_all_cookie)) {

                        if(!options.cookie.disabled_first_visit_cookie)
                        {
                            Cookies.set('pys_first_visit', true, { expires: expires, path: '/',domain: cookieDomain() });
                        }
                        else {
                            Cookies.remove('pys_first_visit', { path: '/',domain: cookieDomain() } )
                        }

                        if(!options.cookie.disabled_trafficsource_cookie)
                        {
                            Cookies.set('pysTrafficSource', getTrafficSource(), { expires: expires,path: '/',domain: cookieDomain() });
                        }
                        else {
                            Cookies.remove('pysTrafficSource', { path: '/',domain: cookieDomain() })
                        }

                        if(!options.cookie.disabled_landing_page_cookie && options.enable_lading_page_param)
                        {
                            Cookies.set('pys_landing_page',landing,{ expires: expires,path: '/',domain: cookieDomain() });
                        }
                        else {
                            Cookies.remove('pys_landing_page', { path: '/',domain: cookieDomain() })
                        }

                        if(!options.cookie.disabled_utmTerms_cookie)
                        {
                            $.each(utmTerms, function (index, name) {
                                if (queryVars.hasOwnProperty(name)) {
                                    Cookies.set('pys_' + name, queryVars[name], { expires: expires,path: '/',domain: cookieDomain() });
                                } else {
                                    Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                                }
                            });
                        }
                        else {
                            $.each(utmTerms, function (index, name) {
                                Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                            });
                        }

                        if(!options.cookie.disabled_utmId_cookie)
                        {
                            $.each(utmId,function(index,name) {
                                if (queryVars.hasOwnProperty(name)) {
                                    Cookies.set('pys_' + name, queryVars[name], { expires: expires,path: '/',domain: cookieDomain() });
                                } else {
                                    Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                                }
                            })
                        }
                        else {
                            $.each(utmId, function (index, name) {
                                Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                            });
                        }

                    }
                    // save data for last visit if it new session
                    if(isNewSession && (!options.cookie.disabled_all_cookie)) {
                        if(!options.cookie.disabled_trafficsource_cookie)
                        {
                            Cookies.set('last_pysTrafficSource', getTrafficSource(), { expires: expires,path: '/',domain: cookieDomain() });
                        }
                        else {
                            Cookies.remove('last_pysTrafficSource', { path: '/',domain: cookieDomain() })
                        }

                        if(!options.cookie.disabled_landing_page_cookie && options.enable_lading_page_param)
                        {
                            Cookies.set('last_pys_landing_page',landing,{ expires: expires,path: '/',domain: cookieDomain() });
                        }
                        else {
                            Cookies.remove('last_pys_landing_page', { path: '/',domain: cookieDomain() })
                        }

                        if(!options.cookie.disabled_utmTerms_cookie)
                        {
                            $.each(utmTerms, function (index, name) {
                                if (queryVars.hasOwnProperty(name)) {
                                    Cookies.set('last_pys_' + name, queryVars[name], { expires: expires,path: '/',domain: cookieDomain() });
                                }
                            });
                        }
                        else {
                            $.each(utmTerms, function (index, name) {
                                Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                            });
                        }

                        if(!options.cookie.disabled_utmId_cookie)
                        {
                            $.each(utmId,function(index,name) {
                                if (queryVars.hasOwnProperty(name)) {
                                    Cookies.set('last_pys_' + name, queryVars[name], { expires: expires,path: '/',domain: cookieDomain() });
                                }
                            })
                        }
                        else {
                            $.each(utmId, function (index, name) {
                                Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                            });
                        }

                    }
                    if(options.cookie.disabled_start_session_cookie) {
                        Cookies.remove('pys_start_session', { path: '/',domain: cookieDomain() })
                        Cookies.remove('pys_session_limit', { path: '/',domain: cookieDomain() })
                    }
                    if(options.cookie.disabled_all_cookie)
                    {
                        Cookies.remove('pys_first_visit', { path: '/',domain: cookieDomain() })
                        Cookies.remove('pysTrafficSource', { path: '/',domain: cookieDomain() })
                        Cookies.remove('pys_landing_page', { path: '/',domain: cookieDomain() })
                        Cookies.remove('last_pys_landing_page', { path: '/',domain: cookieDomain() })
                        Cookies.remove('last_pysTrafficSource', { path: '/',domain: cookieDomain() })
                        Cookies.remove('pys_start_session', { path: '/',domain: cookieDomain() })
                        Cookies.remove('pys_session_limit', { path: '/',domain: cookieDomain() })
                        $.each(Utils.utmTerms, function (index, name) {
                            Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                        });
                        $.each(Utils.utmId,function(index,name) {
                            Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                        })
                        $.each(Utils.utmTerms, function (index, name) {
                            Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                        });
                        $.each(Utils.utmId,function(index,name) {
                            Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                        });
                    }
                } catch (e) {
                    console.error(e);
                }
            },

            initializeRequestParams: function () {

                if (options.trackTrafficSource) {
                    requestParams.traffic_source = getTrafficSourceValue();
                }

                if (options.trackUTMs) {

                    var utms = getUTMs(options.visit_data_model === "last_visit");

                    $.each(utmTerms, function (index, term) {
                        if (term in utms) {
                            requestParams[term] = utms[term];
                        }
                    });

                }


                var dateTime = getDateTime();
                if(options.enable_event_time_param) {
                    requestParams.event_hour = dateTime[0];
                }

                if(options.enable_event_day_param) {
                    requestParams.event_day = dateTime[1];
                }
                if(options.enable_event_month_param) {
                    requestParams.event_month = dateTime[2];
                }

                if(options.enable_lading_page_param){
                    requestParams.landing_page = stripUrlQuery(getLandingPageValue());
                }
            },

            getRequestParams: function () {
                return requestParams;
            },

            /**
             * DOWNLOAD DOCS
             */

            getLinkExtension: function (link) {

                // Remove anchor, query string and everything before last slash
                link = link.substring(0, (link.indexOf("#") === -1) ? link.length : link.indexOf("#"));
                link = link.substring(0, (link.indexOf("?") === -1) ? link.length : link.indexOf("?"));
                link = link.substring(link.lastIndexOf("/") + 1, link.length);

                // If there's a period left in the URL, then there's a extension
                if (link.length > 0 && link.indexOf('.') !== -1) {
                    link = link.substring(link.lastIndexOf(".") + 1); // Remove everything but what's after the first period
                    return link;
                } else {
                    return "";
                }
            },

            getLinkFilename: function (link) {

                // Remove anchor, query string and everything before last slash
                link = link.substring(0, (link.indexOf("#") === -1) ? link.length : link.indexOf("#"));
                link = link.substring(0, (link.indexOf("?") === -1) ? link.length : link.indexOf("?"));
                link = link.substring(link.lastIndexOf("/") + 1, link.length);

                // If there's a period left in the URL, then there's a extension
                if (link.length > 0 && link.indexOf('.') !== -1) {
                    return link;
                } else {
                    return "";
                }
            },

            /**
             * CUSTOM EVENTS
             */

            setupMouseOverClickEvents: function (eventId, triggers, triggerType) {

                // Non-default binding used to avoid situations when some code in external js
                // stopping events propagation, eg. returns false, and our handler will never called
                document.addEventListener('mouseover', function(event) {
                    var matchedElements = Array.from(document.querySelectorAll(triggers));
                    var clickedElement = event.target;
                    var closestMatch = clickedElement.closest(triggers);
                    if (matchedElements.includes(clickedElement) || closestMatch){
                        if (event.target.classList.contains('pys-mouse-over-' + eventId)) {
                            return true;
                        } else {
                            event.target.classList.add('pys-mouse-over-' + eventId);
                        }

                        Utils.handleTriggerFired(eventId, triggerType || 'css_mouseover');
                    }
                });


            },

            setupFormFieldEvents: function (eventId, triggers, triggerType) {
                triggers.forEach(function(trigger) {
                    let eventType = 'input';

                    if (['checkbox', 'radio', 'select'].includes(trigger.type)) {
                        eventType = 'change';
                    } else if (['text', 'email', 'tel'].includes(trigger.type)) {
                        eventType = 'blur';
                    }

                    const form = document.querySelector(trigger.form);
                    if (!form) return;

                    const field = form.querySelector(trigger.field); // search for the field ONLY within the form
                    if (!field) return;

                    field.addEventListener(eventType, function (event) {
                        Utils.handleTriggerFired(eventId, triggerType || 'form_field');
                    }, true);
                });
            },

            setupCSSClickEvents: function (eventId, triggers, triggerType, clickCount, clickTimeLimit) {
                // Non-default binding used to avoid situations when some code in external js
                // stopping events propagation, eg. returns false, and our handler will never called
                // add event to document to support dyn class
                var requiredClicks = (clickCount && clickCount > 1) ? clickCount : 1;
                var timeWindow     = (clickTimeLimit && clickTimeLimit > 0) ? clickTimeLimit : 0;
                var clickCounters  = typeof WeakMap !== 'undefined' ? new WeakMap() : null;

                document.addEventListener('click', function(event) {
                    let matchedElements = Array.from(document.querySelectorAll(triggers)),
                        clickedElement = event.target,
                        closestMatch = clickedElement.closest(triggers);

                    if (matchedElements.includes(clickedElement) || closestMatch) {
                        var target = closestMatch || clickedElement;

                        if (requiredClicks <= 1) {
                            Utils.handleTriggerFired(eventId, triggerType || 'css_click');
                            return;
                        }

                        if (!clickCounters) {
                            Utils.handleTriggerFired(eventId, triggerType || 'css_click');
                            return;
                        }

                        var now = Date.now();
                        var state = clickCounters.get(target) || { count: 0, last: 0, timer: null };

                        // When a time window is set, reset the counter if the gap exceeded it.
                        if (timeWindow > 0 && now - state.last > timeWindow) {
                            state.count = 0;
                        }
                        state.count++;
                        state.last = now;

                        if (state.timer) clearTimeout(state.timer);
                        // Schedule cleanup to avoid memory leaks.
                        // With time window: delete entry after window expires.
                        // Without: quietly clear the timer reference after a long idle period.
                        state.timer = setTimeout(function() {
                            if (clickCounters) {
                                if (timeWindow > 0) {
                                    clickCounters.delete(target);
                                } else {
                                    var s = clickCounters.get(target);
                                    if (s) { s.timer = null; clickCounters.set(target, s); }
                                }
                            }
                        }, timeWindow > 0 ? timeWindow : 60000);

                        clickCounters.set(target, state);

                        if (state.count >= requiredClicks) {
                            clickCounters.delete(target);
                            Utils.handleTriggerFired(eventId, triggerType || 'css_click');
                        }
                    }
                }, true);
            },

            setupCopyElementEvents: function (eventId, selectors) {
                var selectorList = Array.isArray(selectors) ? selectors.join(',') : selectors;
                if (!selectorList) return;

                document.addEventListener('copy', function() {
                    var selection = window.getSelection();
                    if (!selection || selection.isCollapsed) return;

                    var node = selection.focusNode;
                    var el = node ? (node.nodeType === 3 ? node.parentElement : node) : null;
                    if (!el) return;

                    try {
                        if (el.closest(selectorList)) {
                            Utils.handleTriggerFired(eventId, 'copy_element');
                        }
                    } catch (e) {}
                });
            },

            setupVideoSpeedEvents: function (eventId, config) {
                var urls      = Array.isArray(config) ? config : (config.urls || []);
                var speedRate = Array.isArray(config) ? 'any' : (config.speed_rate || 'any');
                var triggers  = Array.isArray(config) ? [] : (config.triggers || []);

                var matchesPage = function() {
                    if (!urls || urls.length === 0) return false;
                    var href = window.location.href;
                    return urls.some(function(u) {
                        return u === '*' || u === '' || href.indexOf(u) !== -1;
                    });
                };

                var matchesRate = function(prev, curr) {
                    if (speedRate === 'any') return curr !== prev;
                    if (speedRate === 'increase') return curr > prev;
                    if (speedRate === 'decrease') return curr < prev;
                    return false;
                };


                var matchesVideoId = function(videoId) {
                    if (!triggers || triggers.length === 0) return true;
                    var decId;
                    try { decId = decodeURIComponent(videoId); } catch(e) { decId = videoId; }
                    return triggers.some(function(t) {
                        if (t.rule === videoId || t.rule === String(videoId)) return true;
                        var decRule;
                        try { decRule = decodeURIComponent(t.rule); } catch(e) { decRule = t.rule; }
                        return decRule === decId;
                    });
                };

                if (!matchesPage()) return;

                // HTML5 <video> speed tracking
                document.addEventListener('ratechange', function(event) {
                    var video = event.target;
                    if (!video || video.tagName !== 'VIDEO') return;
                    var prev = video._pysSpeedRate !== undefined ? video._pysSpeedRate : 1;
                    var curr = video.playbackRate;
                    video._pysSpeedRate = curr;

                    if (matchesRate(prev, curr)) {
                        var videoId = video.id || video.src || video.currentSrc || '';
                        if (matchesVideoId(videoId)) {
                            Utils.handleTriggerFired(eventId, 'video_speed');
                        }
                    }
                }, true);
            },

            setupURLClickEvents: function () {

                if( !options.triggerEventTypes.hasOwnProperty('url_click') ) {
                    return;
                }
                // Non-default binding used to avoid situations when some code in external js
                // stopping events propagation, eg. returns false, and our handler will never called
                document.addEventListener('click', function(event) {
                    let anchor = event.target.closest('a');

                    if (anchor) {
                        var url = anchor.getAttribute('href');
                        if (url) {
                            Object.entries(options.triggerEventTypes.url_click).forEach(function ([eventId, triggers]) {
                                triggers.forEach(function (trigger) {
                                    if (Utils.compareUrl(url, trigger.value, trigger.rule)) {
                                        Utils.handleTriggerFired(eventId, 'url_click');
                                    }
                                });
                            });
                        }
                    }
                }, true);

            },

            removeUrlDomain(url) {
                if(url.indexOf("/#") > -1) {
                    url = url.substring(0, url.indexOf("/#"));
                }
                return url.replace('http://','')
                    .replace('https://','')
                    .replace('www.','')
                    .trim()
                    .replace(/^\/+/g, '')

            },

            compareUrl: function(base,url,rule){

                if(url == "*" || url == '') return true;

                base = Utils.removeUrlDomain(base)
                url = Utils.removeUrlDomain(url)

                if(rule == 'match') {
                    return url == base;
                } else {
                    return base.indexOf(url) !== -1
                }

            },

            /**
             * Evaluate the custom-event conditions the server refused to decide.
             *
             * A condition on the landing page or the traffic source depends on the
             * individual visitor, so deciding it in PHP would bake one visitor's
             * answer into HTML that a page cache serves to everybody. PHP therefore
             * ships the condition itself in the event payload and we answer it here,
             * from this visitor's own cookies. See ConditionalEvent::
             * isDeferredToFrontEnd() and CustomEvent::resolveConditions().
             *
             * PHP only attaches pendingConditions when the answer can still change
             * the outcome, so an event carrying them and failing here must not fire.
             *
             * @param event  one pixel's copy of the event; the payload is the same in all of them
             * @returns {boolean}
             */
            conditionsPass: function (event) {

                if (!event || !event.pendingConditions) return true;

                var pending = event.pendingConditions,
                    conditions = pending.conditions || [];

                if (!conditions.length) return true;

                var results = [];

                for (var i = 0; i < conditions.length; i++) {
                    results.push(Utils.checkPendingCondition(conditions[i]));
                }

                if (pending.logic === 'AND') {
                    return results.indexOf(false) === -1;
                }
                return results.indexOf(true) !== -1;
            },

            /**
             * @returns {boolean}
             */
            checkPendingCondition: function (condition) {

                var rule = condition.rule,
                    value = condition.value;

                // The PHP rule compares rtrim($base, '/') with rtrim($url, '/'), while
                // Utils.compareUrl() below compares exactly. That helper is shared with
                // trigger matching, so normalise here instead of changing it. Skipped
                // when trimming would empty the value, because compareUrl() reads an
                // empty needle as "anything matches" and PHP does not.
                var matchExact = function (base) {
                    var needle = String(value == null ? '' : value),
                        trimmed = needle.replace(/\/+$/, '');
                    if (trimmed === '') {
                        return Utils.compareUrl(base, needle, 'match');
                    }
                    return Utils.compareUrl(String(base == null ? '' : base).replace(/\/+$/, ''), trimmed, 'match');
                };

                switch (condition.type) {

                    case 'landing_page':
                        var landing = getLandingPageValue();
                        if (rule === 'param_contains' || rule === 'param_match') {
                            return Utils.compareUrlParams(landing, value, rule);
                        }
                        landing = stripUrlQuery(landing);
                        return rule === 'match' ? matchExact(landing) : Utils.compareUrl(landing, value, rule);

                    case 'source':
                        var source = getTrafficSourceValue();
                        return rule === 'match' ? matchExact(source) : Utils.compareUrl(source, value, rule);

                    case 'url_parameters':
                        // The stored rule is contains/match; PHP prefixes it before
                        // comparing — compareURLs( $value, '', 'param_' . $rule ) — so
                        // the comparison always runs against the query string, never
                        // the path. The query string of *this* request is the point:
                        // the cached HTML was built for whoever arrived first.
                        return Utils.compareUrlParams(window.location.href, value, 'param_' + rule);

                    default:
                        // A condition type this build cannot judge. PHP deferred it,
                        // so nobody has decided it — fire rather than swallow the
                        // event: a missing event is invisible in the reports, a
                        // superfluous one is not.
                        return true;
                }
            },

            /**
             * The param_match / param_contains rules of the PHP side, which apply to
             * the query string of the landing page rather than to its path.
             *
             * param_match:    any "key=value" pair in the condition matches the URL.
             * param_contains: the condition text appears in any parameter name or
             *                 value, case-insensitively.
             *
             * @returns {boolean}
             */
            compareUrlParams: function (url, value, rule) {

                value = String(value == null ? '' : value).replace(/\*+$/, '');

                if (value === '' || value === '*') return true;

                // PHP parses both sides with parse_str(), which rewrites spaces and
                // dots in parameter *names* to underscores. Mirror that, or a
                // condition on "a.b" would never meet the "a_b" the server sees.
                var normaliseKey = function (raw) {
                    return decodeURIComponent(String(raw).replace(/\+/g, ' ')).replace(/[ .]/g, '_');
                };

                var query = String(url == null ? '' : url).split('#')[0].split('?')[1] || '',
                    params = {};

                query.replace(/&amp;/g, '&').split('&').forEach(function (pair) {
                    if (!pair) return;
                    var parts = pair.split('=');
                    params[normaliseKey(parts[0])] =
                        decodeURIComponent((parts.slice(1).join('=') || '').replace(/\+/g, ' '));
                });

                if (rule === 'param_match') {
                    var wanted = value.split('&');
                    for (var i = 0; i < wanted.length; i++) {
                        var parts = wanted[i].split('='),
                            key = normaliseKey(parts[0]),
                            expected = decodeURIComponent((parts.slice(1).join('=') || '').replace(/\+/g, ' '));
                        if (params.hasOwnProperty(key) && params[key] === expected) {
                            return true;
                        }
                    }
                    return false;
                }

                var needle = value.toLowerCase();
                for (var name in params) {
                    if (!params.hasOwnProperty(name)) continue;
                    if (name.toLowerCase().indexOf(needle) !== -1) return true;
                    if (String(params[name]).toLowerCase().indexOf(needle) !== -1) return true;
                }
                return false;
            },

            setupScrollPosEvents: function (eventId, triggers, triggerType) {

                var scrollPosThresholds = {},
                    docHeight = $(document).height() - $(window).height();

                // convert % to absolute positions
                $.each(triggers, function (index, scrollPos) {

                    // convert % to pixels
                    scrollPos = docHeight * scrollPos / 100;
                    scrollPos = Math.round(scrollPos);

                    scrollPosThresholds[scrollPos] = eventId;

                });

                $(document).on("scroll",function () {

                    var scrollPos = $(window).scrollTop();

                    $.each(scrollPosThresholds, function (threshold, eventId) {

                        // position has not reached yes
                        if (scrollPos < threshold - 0.5) {
                            return true;
                        }

                        // fire event only once
                        if (eventId === null) {
                            return true;
                        } else {
                            scrollPosThresholds[threshold] = null;
                        }

                        Utils.handleTriggerFired(eventId, triggerType || 'scroll_pos');
                    });

                });

            },
            setupCommentEvents : function (eventId,triggers) {
                $('form.comment-form').on("submit",function () {
                    Utils.fireTriggerEvent(eventId);
                });
            },

            setupEmailLinkEvents: function ( events ) {

                $( document ).on( 'click', 'a', function ( event ) {
                    let anchor = event.target.closest('a');

                    if (anchor) {
                        let url = anchor.getAttribute('href');
                        if (url && (url.startsWith('mailto:') || url.startsWith('tel:'))) {

                            let sendEventIds = [],
                                disabled_for_pixels = [],
                                disabled_email_action = false;

                            $.each(events, function (eventId, trigger_group) {
                                url = url.replace('mailto:', '').replace('tel:', '');
                                trigger_group.forEach(function (triggers) {
                                    triggers.rules.forEach(function (trigger) {
                                        if (Utils.compareUrl(url, trigger.value, trigger.rule)) {
                                            sendEventIds.push(eventId);
                                            if (triggers.hasOwnProperty('disabled_email_link') && triggers.disabled_email_link) {
                                                disabled_email_action = true;
                                                if (options.triggerEvents.hasOwnProperty(eventId)) {
                                                    disabled_for_pixels.push(...Object.keys(options.triggerEvents[eventId]));
                                                }
                                            }
                                        }
                                    });
                                })
                            })

                            if (sendEventIds.length > 0) {
                                sendEventIds.forEach(function (sendEventId) {
                                    Utils.handleTriggerFired(sendEventId, 'email_link');
                                })
                            }
                            setupEmailLinks(disabled_for_pixels);
                        }
                    }
                } )
            },

            /**
             * Events
             */

            isEventInTimeWindow: function (eventName, event, prefix) {

                if(event.hasOwnProperty("hasTimeWindow") && event.hasTimeWindow) {
                    var cookieName = prefix+"_"+eventName;
                    var now = new Date().getTime();

                    if(Cookies.get(cookieName) !== undefined) {

                        var lastTimeFire = Cookies.get(cookieName);
                        var fireTime = event.timeWindow * 60*60*1000;

                        if( now - lastTimeFire > fireTime) {
                            Cookies.set(cookieName,now, { expires: event.timeWindow / 24.0, path: '/'} );
                        } else {
                            return false;
                        }
                    } else {
                        Cookies.set(cookieName,now, { expires: event.timeWindow / 24.0, path: '/'} );
                    }
                }
                return true
            },

            handleTriggerFired: function (eventId, triggerType) {
                if (options.triggerLogic && options.triggerLogic[eventId] === 'AND') {
                    var state = pysCustomEventsState[eventId];
                    if (!state || state.fired) return;
                    state.triggered[triggerType] = true;
                    if (Object.keys(state.triggered).length >= state.total) {
                        state.fired = true;
                        Utils.fireTriggerEvent(eventId);
                    }
                } else {
                    Utils.fireTriggerEvent(eventId);
                }
            },

            fireTriggerEvent: function (eventId) {

                if (!options.triggerEvents.hasOwnProperty(eventId)) {
                    return;
                }

                if (options.triggerFrequency && options.triggerFrequency[eventId] === 'once') {
                    if (pysEventFiredOnce[eventId]) return;
                    pysEventFiredOnce[eventId] = true;
                }

                var event = {};
                var events = options.triggerEvents[eventId];

                // One gate for every pixel: they all carry the same payload.
                for (var pixelSlug in events) {
                    if (!events.hasOwnProperty(pixelSlug)) continue;
                    if (!Utils.conditionsPass(events[pixelSlug])) return;
                    break;
                }

                if (events.hasOwnProperty('facebook')) {
                    event = events.facebook;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_facebook_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        Facebook.fireEvent(event.name, event);
                    }
                }

                if (events.hasOwnProperty('ga')) {
                    event = events.ga;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_ga_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        Analytics.fireEvent(event.name, event);
                    }
                }

                if (events.hasOwnProperty('google_ads')) {
                    event = events.google_ads;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_google_ads_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        GAds.fireEvent(event.name, event);
                    }
                }

                if (events.hasOwnProperty('pinterest')) {
                    event = events.pinterest;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_pinterest_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        Pinterest.fireEvent(event.name, event);;
                    }
                }

                if (events.hasOwnProperty('bing')) {
                    event = events.bing;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_bing_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        Bing.fireEvent(event.name, event);;
                    }
                }
                if (events.hasOwnProperty('tiktok')) {
                    event = events.tiktok;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_tiktok_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        TikTok.fireEvent(event.name, event);
                    }
                }
                if (events.hasOwnProperty('reddit')) {
                    event = events.reddit;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_reddit_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        Reddit.fireEvent(event.name, event);
                    }
                }


                if (events.hasOwnProperty('openai')) {
                    event = events.openai;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_openai_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        OpenAI.fireEvent(event.name, event);
                    }
                }

                if (events.hasOwnProperty('gtm')) {
                    event = events.gtm;
                    if(Utils.isEventInTimeWindow(event.name,event,"dyn_gtm_"+eventId)) {
                        event = Utils.getFormFilledData(event);
                        GTM.fireEvent(event.name, event);
                    }
                }


            },

            isFirstPurchaseFire: function ($eventName,orderId,pixel) {

                if(Cookies.get("pys_"+$eventName+"_order_id_"+pixel) == orderId) {
                    return false;
                } else {
                    Cookies.set("pys_"+$eventName+"_order_id_"+pixel, orderId, { expires: 1,path: '/' });
                }
                return true;
            },

            fireStaticEvents: function (pixel, timeout = 0) {

                Utils.refreshAddonPixels();

                if (options.staticEvents.hasOwnProperty(pixel)) {

                    $.each(options.staticEvents[pixel], function (eventId, events) {

                        //skip purchase event if this order was fired
                        if( options.woo.hasOwnProperty('woo_purchase_on_transaction') &&
                            options.woo.woo_purchase_on_transaction &&
                            (eventId === "woo_purchase" || eventId === "woo_purchase_category") ) {
                            if(!Utils.isFirstPurchaseFire(eventId,events[0].woo_order,pixel)) {
                                return;
                            }
                        }

                        if( options.edd.hasOwnProperty('edd_purchase_on_transaction') &&
                            options.edd.edd_purchase_on_transaction &&
                            (eventId === "edd_purchase" || eventId === "edd_purchase_category") ) {
                            if(!Utils.isFirstPurchaseFire(eventId,events[0].edd_order,pixel)) {
                                return;
                            }
                        }


                        $.each(events, function (index, event) {

                            event.fired = event.fired || false;

                            if (!event.fired && Utils.conditionsPass(event) && Utils.isEventInTimeWindow(event.name,event,'static_' + pixel+"_")) {
                                event = Utils.getFormFilledData(event);

                                var fired = false;

                                // Thank-you Purchase: tell the server the browser sent it.
                                // GA4 confirms from its own event_callback instead.
                                var purchaseMarker = (eventId === "woo_purchase" || eventId === "edd_purchase") &&
                                    pixel !== 'ga' && Utils.purchaseMarkerPlatforms.indexOf(pixel) !== -1 &&
                                    event.purchase_marker ? event.purchase_marker : null;

                                // fire event
                                if ( pixel === 'tiktok' ) {
                                    setTimeout(function() {
                                        getPixelBySlag(pixel).fireEvent(event.name, event);
                                        if ( purchaseMarker ) {
                                            Utils.sendPurchaseMarker(purchaseMarker, pixel);
                                        }
                                    }, timeout * 500);
                                    timeout++;
                                } else {
                                    getPixelBySlag(pixel).fireEvent(event.name, event);
                                    if ( purchaseMarker ) {
                                        Utils.sendPurchaseMarker(purchaseMarker, pixel);
                                    }
                                }

                                // prevent event double event firing
                                event.fired = fired;
                            }
                        });
                    });
                }
            },

            /**
             * Load tag's JS
             *
             * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/
             * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/custom-dims-mets
             */
            loadGoogleTag: function (id) {

                if (!gtag_loaded) {
                    let dataLayerName = this.resolveGaDataLayerName();
                    this.dataLayerName = dataLayerName;
                    (function (window, document, src) {
                        var a = document.createElement('script'),
                            m = document.getElementsByTagName('script')[0];
                        a.async = 1;
                        a.src = src;
                        m.parentNode.insertBefore(a, m);
                    })(window, document, '//www.googletagmanager.com/gtag/js?id=' + id+'&l='+this.dataLayerName);

                    window[dataLayerName] = window[dataLayerName] || [];
                    // Published only so custom client code and third-party snippets
                    // have a gtag() to call. PYS itself must never route through it:
                    // the `||` means an earlier definition (Site Kit, a theme, the
                    // GTM bootstrap) keeps ownership and would point at its own data
                    // layer. Use Utils.gtagPush() instead.
                    window.gtag = window.gtag || function gtag() {
                        window[dataLayerName].push(arguments);
                    };

                    if ( options.google_consent_mode ) {
                        let data = this.resolveConsentValues();

                        // Normally this data layer is ours alone and still empty, so a
                        // `default` is what belongs here. But the GA and GTM scopes
                        // collapse into one layer when their names resolve to the same
                        // value (gtm_dataLayer_name left at 'dataLayerPYS', or the GA
                        // layer set to "Disable name transformation"), and then the GTM
                        // <head> snippet has already written a strict `denied` default
                        // here. Repeating `default` would leave GA denied; `update` is
                        // the documented transition once a default exists.
                        this.pushConsent( dataLayerName, this.layerHasConsentDefault( dataLayerName ) ? 'update' : 'default', data );
                    }

                    Utils.gtagPush('js', new Date());
                    gtag_loaded = true;

                }

            },

            /**
             * Name of the data layer gtag.js is loaded with, see loadGoogleTag().
             * Pure, so it can be resolved before the tag is loaded.
             */
            resolveGaDataLayerName: function () {
                if ( options.hasOwnProperty( 'GATags' ) ) {
                    switch ( options.GATags.ga_datalayer_type ) {
                        case 'default':
                            return 'dataLayerPYS';
                        case 'custom':
                            return options.GATags.ga_datalayer_name;
                        default:
                            return 'dataLayer';
                    }
                }
                return this.dataLayerName || 'dataLayer';
            },

            /**
             * Name of the GTM container's data layer. Mirrors GTM::pys_wp_header_top()
             * in modules/google_gtm/gtm.php — the two must agree, or the <head> consent
             * default and the footer consent update land in different layers. `??`
             * alone is not enough: the option can be saved as an empty string, and
             * window[''] is a silent dead end.
             */
            resolveGtmDataLayerName: function () {
                var name = options.hasOwnProperty( 'gtm' ) ? options.gtm.gtm_dataLayer_name : '';
                return ( typeof name === 'string' && name.length ) ? name : 'dataLayer';
            },

            /**
             * Sends a gtag command (js/config/set/event/consent) to the GA data layer.
             *
             * Deliberately does NOT call window.gtag. That global is created with
             * `window.gtag = window.gtag || ...`, so whoever defined it first owns it:
             * if a theme, Site Kit or the GTM bootstrap got there first, our config
             * and event commands would silently land in their data layer while the
             * gtag.js instance we loaded (&l=<GA layer>) never receives a config —
             * Tag Assistant then reports "Some hits will only be sent after a config
             * command is issued". Pushing the arguments object is exactly what gtag()
             * does internally, so the payload is identical.
             */
            gtagPush: function () {
                var name = this.dataLayerName || this.resolveGaDataLayerName();
                window[ name ] = window[ name ] || [];
                window[ name ].push( arguments );
            },

            /**
             * Back-compat alias of the old GA-scope consent sender. Exposed through
             * window.pys.Utils, so custom client code may call it. New code uses
             * pushConsent() with an explicit data layer name.
             */
            loadDefaultConsent: function() {
                this.gtagPush.apply( this, arguments );
            },

            /**
             * Sends one Consent Mode command ('default' or 'update') to a named data
             * layer. The single place that writes consent commands.
             *
             * The IIFE is not decoration: gtag() pushes its own `arguments` object,
             * and gtag.js / GTM read the command by index off that object. Pushing a
             * plain array works today but is not what the tag emits, so we reproduce
             * the exact shape — same reason gtm.php builds its <head> command this way.
             */
            pushConsent: function ( layerName, command, values ) {
                if ( !layerName ) {
                    return;
                }
                window[ layerName ] = window[ layerName ] || [];
                ( function () {
                    window[ layerName ].push( arguments );
                } )( 'consent', command, values );
            },

            /**
             * Whether a Consent Mode `default` has already been written to this data
             * layer — by our own <head> snippet, by a consent plugin, or by a third
             * party (Site Kit, a theme). Decides `default` vs `update`: Consent Mode
             * documents exactly one `default` per layer, and a repeated one is not a
             * defined transition. Consent Magic reads the layer the same way
             * (cs-public.js, CS_Consent_Mode.setDefaultConsent).
             */
            layerHasConsentDefault: function ( layerName ) {
                var layer = window[ layerName ];
                if ( !layer || typeof layer.length !== 'number' ) {
                    return false;
                }
                for ( var i = 0; i < layer.length; i++ ) {
                    var item = layer[ i ];
                    // Entries pushed by other integrations are plain objects; indexing
                    // them just yields undefined.
                    if ( item && item[ 0 ] === 'consent' && item[ 1 ] === 'default' ) {
                        return true;
                    }
                }
                return false;
            },

            /**
             * The four Consent Mode signals as PYS currently resolves them. `enabled`
             * is false when consent mode is off for that signal, in which case Google's
             * absence of a value means granted anyway — say so explicitly.
             */
            resolveConsentValues: function () {
                return {
                    'analytics_storage':  options.gdpr.analytics_storage.enabled  ? options.gdpr.analytics_storage.value  : 'granted',
                    'ad_storage':         options.gdpr.ad_storage.enabled         ? options.gdpr.ad_storage.value         : 'granted',
                    'ad_user_data':       options.gdpr.ad_user_data.enabled       ? options.gdpr.ad_user_data.value       : 'granted',
                    'ad_personalization': options.gdpr.ad_personalization.enabled ? options.gdpr.ad_personalization.value : 'granted',
                };
            },

            loadGTMScript: function (id = '') {
                // Strip trailing slash to allow both "domain.com" and "domain.com/" inputs.
                const domain = ( options.gtm.gtm_container_domain ?? 'www.googletagmanager.com' ).replace( /\/$/, '' );
                const loader = options.gtm.gtm_container_identifier ?? 'gtm';
                const gtm_auth = options.gtm.gtm_auth ?? '';
                const gtm_preview = options.gtm.gtm_preview ?? '';
                const datalayer_name = this.resolveGtmDataLayerName();

                window[ datalayer_name ] = window[ datalayer_name ] || [];
                window.gtag = window.gtag || function gtag() {
                    window[ datalayer_name ].push( arguments );
                };

                // Send the consent state synchronously before the GTM script tag is
                // inserted, so it is in the dataLayer before GTM processes any events.
                this.pushGTMConsentState( datalayer_name );

                (function(w, d, s, l, i) {
                    w[l] = w[l] || [];
                    w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
                    const f = d.getElementsByTagName(s)[0];
                    const j = d.createElement(s);
                    const dl = l !== 'dataLayer' ? '&l=' + l : '';
                    j.async = true;

                    // Detect domain format: bare hostname (legacy) vs full URL / relative path (new).
                    // Legacy "www.googletagmanager.com" → prepend https:// and append .js.
                    // New format "/metrics" or "https://custom.com" → use as-is.
                    //   Identifier with extension (e.g. "gtm.js")  → file:   domain/gtm.js?id=
                    //   Identifier without extension (e.g. "g4h25o") → path: domain/g4h25o/?id=
                    const isNewFormat = domain.startsWith( 'http://' )
                        || domain.startsWith( 'https://' )
                        || domain.startsWith( '/' );

                    if ( !isNewFormat ) {
                        j.src = 'https://' + domain + '/' + loader + '.js?id=' + i + dl;
                    } else {
                        const hasExtension = loader.includes( '.' );
                        j.src = domain + '/' + loader + ( hasExtension ? '?' : '/?' ) + 'id=' + i + dl;
                    }

                    if (gtm_auth && gtm_preview) {
                        j.src += '&gtm_auth=' + gtm_auth + '&gtm_preview=' + gtm_preview + '&gtm_cookies_win=x';
                    }
                    f.parentNode.insertBefore(j, f);
                })(window, document, 'script', datalayer_name, id);

            },

            /**
             * Back-compat aliases. Both are reachable as window.pys.Utils.* and may be
             * called by custom client code, so they keep working; internally everything
             * goes through pushConsent() / pushGTMConsentState() with an explicit layer
             * name instead of the implicit this.GTMdataLayerName state.
             */
            loadDefaultGTMConsent: function() {
                window[ this.GTMdataLayerName ] = window[ this.GTMdataLayerName ] || [];
                window[ this.GTMdataLayerName ].push( arguments );
            },
            pushGTMConsentDefaults: function( datalayer_name ) {
                this.pushGTMConsentState( datalayer_name );
            },

            /**
             * Sends the GTM container's consent state, once per page load.
             *
             * Called from loadGTMScript() (PYS loads the container itself) and from
             * GTM.loadPixel() when gtm_just_data_layer is on, so the state is sent
             * whichever path runs — and only once when both do.
             *
             * Emits `update`, not a second `default`, whenever a default already sits
             * in the layer. modules/google_gtm/gtm.php writes a strict all-denied
             * default with wait_for_update:500 in <head>, before the container boots;
             * that is correct Consent Mode practice, and it is what makes PYS's own
             * prior-consent gate work — this function runs downstream of
             * Utils.consentGiven('analytics'), so nothing is granted until consent
             * actually exists. What was missing is the other half of the contract:
             * the update that resolves the wait_for_update window. A repeated
             * `default` is not a defined transition and left GTM-managed tags denied.
             */
            pushGTMConsentState: function( datalayer_name ) {
                if ( !options.google_consent_mode || gtm_consent_state_pushed ) {
                    return;
                }

                // A consent management plugin owns the transition: it issues its own
                // update from the user's live choice, while ours carries whatever the
                // cookies said when the page was rendered. Consent Magic diffs against
                // the last consent values in the layer, so a late push from us either
                // suppresses its update or overwrites the choice the user just made.
                // The <head> default already carries the CMP's resolved values.
                if ( options.consent_mode_cmp_active ) {
                    return;
                }

                gtm_consent_state_pushed = true;
                // Kept in sync for the loadDefaultGTMConsent() back-compat alias.
                this.GTMdataLayerName = datalayer_name;
                this.pushConsent(
                    datalayer_name,
                    this.layerHasConsentDefault( datalayer_name ) ? 'update' : 'default',
                    this.resolveConsentValues()
                );
            },

            /**
             * GDPR
             */

            loadPixels: function () {

                if (options.gdpr.ajax_enabled && !options.gdpr.consent_magic_integration_enabled) {

                    // retrieves actual PYS GDPR filters values which allow to avoid cache issues
                    $.get({
                        url: options.ajaxUrl,
                        dataType: 'json',
                        data: {
                            action: 'pys_get_gdpr_filters_values'
                        },
                        success: function (res) {

                            if (res.success) {

                                options.gdpr.all_disabled_by_api = res.data.all_disabled_by_api;
                                options.gdpr.facebook_disabled_by_api = res.data.facebook_disabled_by_api;
                                options.gdpr.tiktok_disabled_by_api = res.data.tiktok_disabled_by_api;
                                options.gdpr.openai_disabled_by_api = res.data.openai_disabled_by_api;
                                options.gdpr.awin_disabled_by_api = res.data.awin_disabled_by_api;
                                options.gdpr.analytics_disabled_by_api = res.data.analytics_disabled_by_api;
                                options.gdpr.google_ads_disabled_by_api = res.data.google_ads_disabled_by_api;
                                options.gdpr.pinterest_disabled_by_api = res.data.pinterest_disabled_by_api;
                                options.gdpr.bing_disabled_by_api = res.data.bing_disabled_by_api;
                                options.gdpr.reddit_disabled_by_api = res.data.reddit_disabled_by_api;

                                options.cookie.externalID_disabled_by_api = res.data.externalID_disabled_by_api;
                                options.cookie.disabled_all_cookie = res.data.disabled_all_cookie;
                                options.cookie.disabled_advanced_form_data_cookie = res.data.disabled_advanced_form_data_cookie;
                                options.cookie.disabled_landing_page_cookie = res.data.disabled_landing_page_cookie || !options.enable_lading_page_param;
                                options.cookie.disabled_first_visit_cookie = res.data.disabled_first_visit_cookie;
                                options.cookie.disabled_trafficsource_cookie = res.data.disabled_trafficsource_cookie;
                                options.cookie.disabled_utmTerms_cookie = res.data.disabled_utmTerms_cookie;
                                options.cookie.disabled_utmId_cookie = res.data.disabled_utmId_cookie;
                            }
                            loadPixels();
                        },
                        // Without an answer the values rendered into the page still hold
                        // (the same ones used when this request is switched off); waiting
                        // for it forever used to leave every pixel unloaded, silently.
                        error: function (xhr, status) {
                            if (options.debug) {
                                console.warn('[PYS] pys_get_gdpr_filters_values failed (' + status + '), using page values');
                            }
                            loadPixels();
                        }
                    });

                } else {
                    loadPixels();
                }

            },

            /**
             * productlist / select_prod_list carry the list of the clicked product
             * to the next page for GA4 / GTM: analytics data, so they follow the
             * same cookie and GDPR gates as the analytics pixels themselves.
             */
            setProductListCookie: function (name, value) {
                if (options.cookie.disabled_all_cookie
                    || options.gdpr.all_disabled_by_api
                    || options.gdpr.analytics_disabled_by_api
                    || !Utils.consentGiven('analytics')) {
                    return;
                }
                Cookies.set(name, value, { expires: 1, path: '/' });
            },

            consentGiven: function (pixel, ignoreRestrictedMode) {

                /**
                 * Cookiebot
                 */
                if (options.gdpr.cookiebot_integration_enabled && typeof Cookiebot !== 'undefined') {

                    var cookiebot_consent_category = options.gdpr['cookiebot_' + pixel + '_consent_category'];

                    if (options.gdpr[pixel + '_prior_consent_enabled']) {
                        if (Cookiebot.consented === true || Cookiebot.consent[cookiebot_consent_category]) {
                            return true;
                        }
                    } else {
                        if (Cookiebot.consent[cookiebot_consent_category]) {
                            return true;
                        }
                    }
                    return false;

                }

                /**
                 * Cookie Notice
                 */
                if (options.gdpr.cookie_notice_integration_enabled && typeof cnArgs !== 'undefined') {

                    var cn_cookie = Cookies.get(cnArgs.cookieName);

                    if (options.gdpr[pixel + '_prior_consent_enabled']) {
                        if (typeof cn_cookie === 'undefined' || cn_cookie === 'true') {
                            return true;
                        }
                    } else {
                        if (cn_cookie === 'true') {
                            return true;
                        }
                    }

                    return false;

                }

                /**
                 * Cookie Law Info
                 */

                if (options.gdpr.cookie_law_info_integration_enabled) {
                    var cli_cookie = Cookies.get('cookieyes-consent') ?? Cookies.get('wt_consent') ?? Cookies.get('viewed_cookie_policy');
                    if (options.gdpr[pixel + '_prior_consent_enabled']) {
                        if (typeof cli_cookie === 'undefined') return true;
                        if (
                            cli_cookie &&
                            (cli_cookie === Cookies.get('cookieyes-consent') || cli_cookie === Cookies.get('wt_consent'))
                        ) {
                            if (getCookieYes(getCookieYesCategory(pixel)) === 'yes') {
                                return true;
                            }
                        } else if (cli_cookie && cli_cookie === Cookies.get('viewed_cookie_policy')) {
                            if (Cookies.get('viewed_cookie_policy') === 'yes') {
                                return true;
                            }
                        }
                    } else {
                        if (
                            cli_cookie &&
                            (cli_cookie === Cookies.get('cookieyes-consent') || cli_cookie === Cookies.get('wt_consent'))
                        ) {
                            if (getCookieYes(getCookieYesCategory(pixel)) === 'yes') {
                                return true;
                            }
                        } else if (cli_cookie && cli_cookie === Cookies.get('viewed_cookie_policy')) {
                            if (Cookies.get('viewed_cookie_policy') === 'yes') {
                                return true;
                            }
                        }
                    }
                    return false;
                }

                /**
                 * ConsentMagic
                 */
                if (options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== "undefined" ) {

                    // ConsentMagic without Awin support: Awin follows the Facebook
                    // category, but Meta's LDU mode is not consent.
                    if ( pixel == 'awin' && typeof CS_Data.cs_script_cat?.awin === 'undefined' ) {
                        return Utils.consentGiven( 'facebook', true );
                    }

                    let test_prefix = CS_Data.test_prefix;
                    if ( !ignoreRestrictedMode && (
                        ( Utils.csModeEnabled( CS_Data.cs_google_consent_mode_enabled ) && ( pixel == 'analytics' || pixel == 'google_ads' ) )
                        || ( Utils.csModeEnabled( CS_Data.cs_meta_ldu_mode ) && pixel == 'facebook' )
                        || ( Utils.csModeEnabled( CS_Data.cs_reddit_ldu_mode ) && pixel == 'reddit' )
                        || ( Utils.csModeEnabled( CS_Data.cs_openai_opt_out_mode ) && pixel == 'openai' )
                        || ( Utils.csModeEnabled( CS_Data.cs_bing_consent_mode?.ad_storage?.enabled ) && pixel == 'bing' )
                    ) ) {
                        if ( Number( CS_Data.cs_cache_enabled ) === 0
                            || ( Utils.csModeEnabled( CS_Data.cs_cache_enabled ) && window.CS_Cache && window.CS_Cache.check_status ) ) {
                            return true;
                        } else {
                            return false;
                        }
                    }

                    if( pixel == 'facebook' && ( CS_Data.cs_script_cat.facebook == 0 || CS_Data.cs_script_cat.facebook == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'bing' && ( CS_Data.cs_script_cat.bing == 0 || CS_Data.cs_script_cat.bing == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'analytics' && ( CS_Data.cs_script_cat.analytics == 0 || CS_Data.cs_script_cat.analytics == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'google_ads' && ( CS_Data.cs_script_cat.gads == 0 || CS_Data.cs_script_cat.gads == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'pinterest' && ( CS_Data.cs_script_cat.pinterest == 0 || CS_Data.cs_script_cat.pinterest == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'tiktok' && ( CS_Data.cs_script_cat.tiktok == 0 || CS_Data.cs_script_cat.tiktok == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'reddit' && ( CS_Data.cs_script_cat?.reddit == 0 || CS_Data.cs_script_cat?.reddit == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'openai' && ( CS_Data.cs_script_cat?.openai == 0 || CS_Data.cs_script_cat?.openai == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    } else if( pixel == 'awin' && ( CS_Data.cs_script_cat?.awin == 0 || CS_Data.cs_script_cat?.awin == CS_Data.cs_necessary_cat_id ) ) {
                        return true;
                    }

                    let substring = "cs_enabled_cookie_term",
                        theCookies = document.cookie.split( ';' );

                    for ( let i = 1; i <= theCookies.length; i++ ) {
                        if ( theCookies[ i - 1 ].indexOf( substring ) !== -1 ) {
                            let categoryCookie = theCookies[ i - 1 ].replace( 'cs_enabled_cookie_term' + test_prefix + '_', '' );
                            categoryCookie = Number( categoryCookie.replace( /\D+/g, "" ) );
                            let cs_cookie_val = Cookies.get( 'cs_enabled_cookie_term' + test_prefix + '_' + categoryCookie );

                            if ( categoryCookie === CS_Data.cs_script_cat.facebook && pixel == 'facebook' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat.bing && pixel == 'bing' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat.analytics && pixel == 'analytics' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat.gads && pixel == 'google_ads' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat.pinterest && pixel == 'pinterest' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat.tiktok && pixel == 'tiktok' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat?.reddit && pixel == 'reddit' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat?.openai && pixel == 'openai' ) {
                                return cs_cookie_val == 'yes';
                            } else if ( categoryCookie === CS_Data.cs_script_cat?.awin && pixel == 'awin' ) {
                                return cs_cookie_val == 'yes';
                            }
                        }
                    }

                    return false;
                }


                /**
                 * Real Cookie Banner
                 */
                if (options.gdpr.real_cookie_banner_integration_enabled) {
                    var consentApi = window.consentApi;
                    if (consentApi) {
                        switch (pixel) {
                            case "analytics":
                                return consentApi.consentSync("http", "_ga", "*").cookieOptIn;
                            case "facebook":
                                return consentApi.consentSync("http", "_fbp", "*").cookieOptIn;
                            case "pinterest":
                                return consentApi.consentSync("http", "_pinterest_sess", ".pinterest.com").cookieOptIn;
                            case "bing":
                                return consentApi.consentSync("http", "_uetsid", "*").cookieOptIn;
                            case "google_ads":
                                return consentApi.consentSync("http", "1P_JAR", ".google.com").cookieOptIn;
                            case 'tiktok':
                                return consentApi.consentSync("http", "tt_webid_v2", ".tiktok.com").cookieOptIn;
                            case 'openai':
                                return consentApi.consentSync("http", "__oppref", "*").cookieOptIn;
                            case 'awin':
                                return consentApi.consentSync("http", "awc", "*").cookieOptIn;
                            default:
                                return true;
                        }
                    }
                }

                return true;

            },

            setupGdprCallbacks: function () {

                let isConcent = false;

                /**
                 * Cookiebot
                 */
                if ( options.gdpr.cookiebot_integration_enabled && typeof Cookiebot !== 'undefined' ) {
                    isConcent = true;
                    window.addEventListener( "CookiebotOnConsentReady", function () {

                        let consent = {
                            facebook: true,
                            ga: true,
                            google_ads: true,
                            tiktok: true,
                            openai: true,
                            awin: true,
                            bing: true,
                            pinterest: true,
                            gtm: true,
                        };
                        Utils.initializeVideoAPIs( options );

                        Utils.manageCookies();
                        if ( Cookiebot.consent.marketing ) {
                            Facebook.loadPixel();
                            Bing.loadPixel();
                            Pinterest.loadPixel();
                            GAds.loadPixel();
                            TikTok.loadPixel();
                            OpenAI.loadPixel();

                            consent.facebook = true;
                            consent.bing = true;
                            consent.google_ads = true;
                            consent.pinterest = true;
                            consent.tiktok = true;
                        }
                        if ( Cookiebot.consent.statistics ) {
                            Analytics.loadPixel();

                            consent.ga = true;
                            consent.gtm = true;
                        }
                        if ( !Cookiebot.consent.marketing ) {
                            Facebook.disable();
                            Pinterest.disable();
                            Bing.disable()
                            GAds.disable();
                            TikTok.disable();
                            OpenAI.disable();

                            consent.facebook = false;
                            consent.bing = false;
                            consent.google_ads = false;
                            consent.pinterest = false;
                            consent.tiktok = false;
                        }
                        if ( !Cookiebot.consent.statistics ) {
                            Analytics.disable();

                            consent.ga = false;
                            consent.gtm = false;
                        }

                        consent.awin = !!Cookiebot.consent[ options.gdpr.cookiebot_awin_consent_category || 'marketing' ];

                        Awin.syncConsent();

                        Utils.setupGDPRData( consent );
                    } );
                }

                /**
                 * Cookie Notice
                 */
                if ( options.gdpr.cookie_notice_integration_enabled ) {
                    isConcent = true;
                    $( document ).onFirst( 'click', '.cn-set-cookie', function () {

                        let consent = {};

                        if ( $( this ).data( 'cookie-set' ) === 'accept' ) {

                            Utils.initializeVideoAPIs( options );

                            Facebook.loadPixel();
                            Analytics.loadPixel();
                            GAds.loadPixel();
                            Pinterest.loadPixel();
                            Bing.loadPixel();
                            TikTok.loadPixel();
                            OpenAI.loadPixel();
                            Awin.syncConsent();

                            consent = {
                                facebook: true,
                                ga: true,
                                google_ads: true,
                                tiktok: true,
                                openai: true,
                                awin: true,
                                bing: true,
                                pinterest: true,
                                gtm: true,
                            };
                        } else {
                            Facebook.disable();
                            Analytics.disable();
                            GAds.disable();
                            Pinterest.disable();
                            Bing.disable();
                            TikTok.disable();
                            OpenAI.disable();
                            Awin.disable();

                            consent = {
                                facebook: false,
                                ga: false,
                                google_ads: false,
                                tiktok: false,
                                openai: false,
                                awin: false,
                                bing: false,
                                pinterest: false,
                                gtm: false,
                            };
                        }
                        Utils.setupGDPRData( consent );

                    } );

                    $( document ).onFirst( 'click', '.cn-revoke-cookie', function () {
                        Facebook.disable();
                        Analytics.disable();
                        GAds.disable();
                        Pinterest.disable();
                        Bing.disable();
                        TikTok.disable();
                        OpenAI.disable();
                        Awin.disable();

                        let consent = {
                            facebook: false,
                            ga: false,
                            google_ads: false,
                            tiktok: false,
                            openai: false,
                            awin: false,
                            bing: false,
                            pinterest: false,
                            gtm: false,
                        };
                        Utils.setupGDPRData( consent );

                    } );
                }

                /**
                 * Cookie Law Info
                 */
                if (options.gdpr.cookie_law_info_integration_enabled) {
                    isConcent = true;
                    let cookieYesVideoInit = false;

                    // The visitor's per-category answer, as stored by CookieYes / WebToffee.
                    const applyCookieYesConsent = function () {
                        const analytics = getCookieYes(getCookieYesCategory('analytics')) === 'yes';
                        const ads = getCookieYes(getCookieYesCategory('facebook')) === 'yes';
                        // Initial-state event (no choice yet): do not switch off pixels that run before consent.
                        const explicit = getCookieYes('action') === 'yes' || !Cookies.get('cookieyes-consent');

                        ads ? Facebook.loadPixel() : explicit && Facebook.disable();
                        analytics ? Analytics.loadPixel() : explicit && Analytics.disable();
                        ads ? GAds.loadPixel() : explicit && GAds.disable();
                        ads ? Pinterest.loadPixel() : explicit && Pinterest.disable();
                        ads ? Bing.loadPixel() : explicit && Bing.disable();
                        ads ? TikTok.loadPixel() : explicit && TikTok.disable();
                        ads ? OpenAI.loadPixel() : explicit && OpenAI.disable();
                        ads ? Reddit.loadPixel() : explicit && Reddit.disable();
                        ads ? Awin.syncConsent() : explicit && Awin.disable();

                        if (analytics) {
                            Utils.manageCookies();
                        }

                        if ((analytics || ads) && !cookieYesVideoInit) {
                            cookieYesVideoInit = true;
                            Utils.initializeVideoAPIs(options); // not safe to run twice
                        }

                        Utils.setupGDPRData({
                            facebook: ads,
                            ga: analytics,
                            google_ads: ads,
                            tiktok: ads,
                            openai: ads,
                            awin: ads,
                            bing: ads,
                            pinterest: ads,
                            gtm: analytics,
                            reddit: ads,
                        });
                    };
                    document.addEventListener('cookieyes_consent_update', applyCookieYesConsent);

                    // Older banners write their cookie after our handler, so wait for it.
                    // No CookieYes cookie afterwards means legacy mode: all or nothing.
                    const onCookieYesClick = function (legacy) {
                        setTimeout(function () {
                            if (typeof (Cookies.get('cookieyes-consent') ?? Cookies.get('wt_consent')) !== 'undefined') {
                                applyCookieYesConsent();
                            } else {
                                legacy();
                            }
                        }, 300);
                    };

                    $(document).onFirst('click', '#wt-cli-accept-all-btn,#cookie_action_close_header', function () {
                        onCookieYesClick(function () {
                            Utils.initializeVideoAPIs(options);
                            if (Cookies.get('viewed_cookie_policy') === 'yes') {
                                Utils.manageCookies();
                            }
                            Facebook.loadPixel();
                            Analytics.loadPixel();
                            GAds.loadPixel();
                            Pinterest.loadPixel();
                            Bing.loadPixel();
                            TikTok.loadPixel();
                            OpenAI.loadPixel();
                            Reddit.loadPixel();
                            Awin.syncConsent();
                            Utils.setupGDPRData({
                                facebook: true,
                                ga: true,
                                google_ads: true,
                                tiktok: true,
                                openai: true,
                                awin: true,
                                bing: true,
                                pinterest: true,
                                gtm: true,
                                reddit: true,
                            });
                        });
                    });

                    $(document).onFirst('click', '#cookie_action_close_header_reject', function () {
                        onCookieYesClick(function () {
                            Facebook.disable();
                            Analytics.disable();
                            GAds.disable();
                            Pinterest.disable();
                            Bing.disable();
                            TikTok.disable();
                            OpenAI.disable();
                            Reddit.disable();
                            Awin.disable();
                            Utils.setupGDPRData({
                                facebook: false,
                                ga: false,
                                google_ads: false,
                                tiktok: false,
                                openai: false,
                                awin: false,
                                bing: false,
                                pinterest: false,
                                gtm: false,
                                reddit: false,
                            });
                        });
                    });
                }

                /**
                 * ConsentMagic
                 */
                if ( options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== "undefined" ) {
                    isConcent = true;
                    let test_prefix = CS_Data.test_prefix,
                        cs_refresh_after_consent = false,
                        substring = "cs_enabled_cookie_term";

                    if ( CS_Data.cs_refresh_after_consent == 1 ) {
                        cs_refresh_after_consent = CS_Data.cs_refresh_after_consent;
                    }

                    let consent_actions = function () {
                        let theCookies = document.cookie.split( ';' );

                        let consent = {
                            facebook: true,
                            ga: true,
                            google_ads: true,
                            tiktok: true,
                            openai: true,
                            awin: Utils.consentGiven( 'awin' ),
                            bing: true,
                            pinterest: true,
                            gtm: true,
                            reddit: true,
                        };

                        for ( let i = 1; i <= theCookies.length; i++ ) {
                            if ( theCookies[ i - 1 ].indexOf( substring ) !== -1 ) {
                                let categoryCookie = theCookies[ i - 1 ].replace( 'cs_enabled_cookie_term' + test_prefix + '_', '' );
                                categoryCookie = Number( categoryCookie.replace( /\D+/g, "" ) );
                                let cs_cookie_val = Cookies.get( 'cs_enabled_cookie_term' + test_prefix + '_' + categoryCookie );
                                if ( cs_cookie_val == 'yes' ) {

                                    Utils.initializeVideoAPIs( options );

                                    if ( ( categoryCookie === CS_Data.cs_script_cat.facebook ) || Utils.csModeEnabled( CS_Data.cs_meta_ldu_mode ) ) {
                                        Facebook.loadPixel();
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.bing || Utils.csModeEnabled( CS_Data.cs_bing_consent_mode?.ad_storage?.enabled ) ) {
                                        Bing.loadPixel();
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.analytics || ( typeof CS_Data.cs_google_analytics_consent_mode !== "undefined" && CS_Data.cs_google_analytics_consent_mode == 1 ) ) {
                                        Analytics.loadPixel();
                                    }
                                    if ( categoryCookie === CS_Data.cs_script_cat.gads || ( typeof CS_Data.cs_google_ads_consent_mode !== "undefined" && CS_Data.cs_google_ads_consent_mode == 1 ) ) {
                                        GAds.loadPixel();
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.pinterest ) {
                                        Pinterest.loadPixel();
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.tiktok ) {
                                        TikTok.loadPixel();
                                    }

                                    if ( ( categoryCookie === CS_Data.cs_script_cat.reddit ) || Utils.csModeEnabled( CS_Data.cs_reddit_ldu_mode ) ) {
                                        Reddit.loadPixel();
                                    }

                                    if ( ( categoryCookie === CS_Data.cs_script_cat.openai ) || Utils.csModeEnabled( CS_Data.cs_openai_opt_out_mode ) ) {
                                        OpenAI.loadPixel();
                                    }
                                } else {
                                    if ( ( categoryCookie === CS_Data.cs_script_cat.facebook ) && ! Utils.csModeEnabled( CS_Data.cs_meta_ldu_mode ) ) {
                                        Facebook.disable();
                                        consent.facebook = false;
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.bing && ! Utils.csModeEnabled( CS_Data.cs_bing_consent_mode?.ad_storage?.enabled ) ) {
                                        Bing.disable();
                                        consent.bing = false;
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.analytics && ( typeof CS_Data.cs_google_analytics_consent_mode == "undefined" || CS_Data.cs_google_analytics_consent_mode == 0 ) ) {
                                        Analytics.disable();
                                        consent.ga = false;
                                        consent.gtm = false;
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.gads && ( typeof CS_Data.cs_google_ads_consent_mode == "undefined" || CS_Data.cs_google_ads_consent_mode == 0 ) ) {
                                        GAds.disable();
                                        consent.google_ads = false;
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.pinterest ) {
                                        Pinterest.disable();
                                        consent.pinterest = false;
                                    }

                                    if ( categoryCookie === CS_Data.cs_script_cat.tiktok ) {
                                        TikTok.disable();
                                        consent.tiktok = false;
                                    }

                                    if ( ( categoryCookie === CS_Data.cs_script_cat.reddit ) && ! Utils.csModeEnabled( CS_Data.cs_reddit_ldu_mode ) ) {
                                        Reddit.disable();
                                        consent.reddit = false;
                                    }

                                    if ( ( categoryCookie === CS_Data.cs_script_cat.openai ) && ! Utils.csModeEnabled( CS_Data.cs_openai_opt_out_mode ) ) {
                                        OpenAI.disable();
                                        consent.openai = false;
                                    }
                                }
                                if ( Cookies.get( 'cs_enabled_advanced_matching' ) == 'yes' ) {
                                    Facebook.loadPixel();
                                }
                            }
                        }

                        Awin.syncConsent();

                        Utils.setupGDPRData( consent );
                    }

                    if ( !cs_refresh_after_consent ) {
                        consent_actions();

                        $( document ).on( 'click', '.cs_action_btn', function ( e ) {
                            e.preventDefault();

                            let consent = {
                                facebook: true,
                                ga: true,
                                google_ads: true,
                                tiktok: true,
                                openai: true,
                                awin: true,
                                bing: true,
                                pinterest: true,
                                gtm: true,
                                reddit: true,
                            };

                            let elm = $( this ),
                                button_action = elm.attr( 'data-cs_action' );

                            if ( button_action === 'allow_all' ) {

                                Utils.initializeVideoAPIs( options );

                                Facebook.loadPixel();
                                Bing.loadPixel();
                                Analytics.loadPixel();
                                GAds.loadPixel();
                                Pinterest.loadPixel();
                                TikTok.loadPixel();
                                OpenAI.loadPixel();
                                Awin.syncConsent();
                                Reddit.loadPixel();

                                consent.facebook = true;
                                consent.bing = true;
                                consent.ga = true;
                                consent.google_ads = true;
                                consent.pinterest = true;
                                consent.tiktok = true;
                                consent.reddit = true;
                                consent.gtm = true;

                                Utils.setupGDPRData( consent );

                            } else if ( button_action === 'disable_all' ) {

                                if ( ! Utils.csModeEnabled( CS_Data.cs_meta_ldu_mode ) ) {
                                    Facebook.disable();
                                    consent.facebook = false;
                                }

                                if ( ! Utils.csModeEnabled( CS_Data.cs_bing_consent_mode?.ad_storage?.enabled ) ) {
                                    Bing.disable();
                                    consent.bing = false;
                                }

                                if ( typeof CS_Data.cs_google_analytics_consent_mode == "undefined" || CS_Data.cs_google_analytics_consent_mode == 0 ) {
                                    Analytics.disable();
                                    consent.ga = false;
                                    consent.gtm = false;
                                }

                                if ( typeof CS_Data.cs_google_ads_consent_mode == "undefined" || CS_Data.cs_google_ads_consent_mode == 0 ) {
                                    GAds.disable();
                                    consent.google_ads = false;
                                }

                                if ( ! Utils.csModeEnabled( CS_Data.cs_reddit_ldu_mode ) ) {
                                    Reddit.disable();
                                    consent.reddit = false;
                                }

                                Pinterest.disable();
                                TikTok.disable();
                                OpenAI.disable();
                                Awin.disable();

                                consent.pinterest = false;
                                consent.tiktok = false;
                                consent.openai = false;
                                consent.awin = false;

                                Utils.setupGDPRData( consent );
                            } else if ( button_action === 'cs_confirm' ) {
                                consent_actions();
                            }
                        } );
                    }
                }

                /**
                 * Real Cookie Banner
                 */
                if ( options.gdpr.real_cookie_banner_integration_enabled ) {
                    isConcent = true;
                    let consentApi = window.consentApi;
                    if ( consentApi ) {
                        consentApi.consent( "http", "_ga", "*" )
                            .then( Analytics.loadPixel.bind( Analytics ), Analytics.disable.bind( Analytics ) );
                        consentApi.consent( "http", "1P_JAR", ".google.com" )
                            .then( GAds.loadPixel.bind( GAds ), GAds.disable.bind( GAds ) );
                        consentApi.consent( "http", "_fbp", "*" )
                            .then( Facebook.loadPixel.bind( Facebook ), Facebook.disable.bind( Facebook ) );
                        consentApi.consent( "http", "_pinterest_sess", ".pinterest.com" )
                            .then( Pinterest.loadPixel.bind( Pinterest ), Pinterest.disable.bind( Pinterest ) );
                        consentApi.consent( "http", "_uetsid", "*" )
                            .then( Bing.loadPixel.bind( Bing ), Bing.disable.bind( Bing ) );
                        consentApi.consent( "http", "tt_webid_v2", ".tiktok.com" )
                            .then( TikTok.loadPixel.bind( TikTok ), TikTok.disable.bind( TikTok ) );
                        consentApi.consent( "http", "__oppref", "*" )
                            .then( OpenAI.loadPixel.bind( OpenAI ), OpenAI.disable.bind( OpenAI ) );
                        consentApi.consent( "http", "awc", "*" )
                            .then( Awin.syncConsent.bind( Awin ), Awin.disable.bind( Awin ) );

                        let consent = {
                            facebook: true,
                            ga: true,
                            google_ads: true,
                            tiktok: true,
                            openai: true,
                            awin: true,
                            bing: true,
                            pinterest: true,
                            gtm: true,
                        };

                        if (!consentApi.consentSync("http", "_ga", "*").cookieOptIn) {
                            consent.ga = false;
                            consent.gtm = false;
                        }
                        if (!consentApi.consentSync("http", "_fbp", "*").cookieOptIn) {
                            consent.facebook = false;
                        }
                        if (!consentApi.consentSync("http", "_pinterest_sess", ".pinterest.com").cookieOptIn) {
                            consent.pinterest = false;
                        }
                        if (!consentApi.consentSync("http", "_uetsid", "*").cookieOptIn) {
                            consent.bing = false;
                        }
                        if (!consentApi.consentSync("http", "1P_JAR", ".google.com").cookieOptIn) {
                            consent.google_ads = false;
                        }
                        if (!consentApi.consentSync("http", "tt_webid_v2", ".tiktok.com").cookieOptIn) {
                            consent.tiktok = false;
                        }
                        if (!consentApi.consentSync("http", "__oppref", "*").cookieOptIn) {
                            consent.openai = false;
                        }
                        if (!consentApi.consentSync("http", "awc", "*").cookieOptIn) {
                            consent.awin = false;
                        }
                        Utils.setupGDPRData( consent );

                        // load WatchVideo event APIs for Auto
                        /**
                         * Real Cookie Banner.
                         */
                        if ( options.hasOwnProperty( 'automatic' ) && options.automatic.enable_video && options.automatic.enable_youtube ) {
                            consentApi.consent( "http", "CONSENT", ".youtube.com" ).then( Utils.initYouTubeAPI );
                        }

                        if ( options.hasOwnProperty( 'automatic' ) && options.automatic.enable_video && options.automatic.enable_vimeo ) {
                            consentApi.consent( "http", "player", ".vimeo.com" ).then( Utils.initVimeoAPI );
                        }
                    }
                }

                if ( !isConcent ) {
                    Utils.initializeVideoAPIs( options );
                }
            },

            setupGDPRData: function ( consent ) {
                consent = window.btoa( JSON.stringify( consent ) );
                Cookies.set( 'pys_consent', consent, { expires: 365, path: '/', domain: cookieDomain() } );
            },

            /**
             * Enrich
             */
            isCheckoutPage: function () {
                return $('body').hasClass('woocommerce-checkout') || document.querySelector('.woocommerce-checkout') ||
                    $('body').hasClass('edd-checkout');
            },
            addCheckoutFields : function() {
                var utm = "";
                var utms = getUTMs()
                $.each(utmTerms, function (index, name) {
                    if(index > 0) {
                        utm+="|";
                    }
                    utm+=name+":"+utms[name];
                });
                var utmIdList = "";
                var utmsIds = getUTMId()
                $.each(utmId, function (index, name) {
                    if(index > 0) {
                        utmIdList+="|";
                    }
                    utmIdList+=name+":"+utmsIds[name];
                });
                var utmIdListLast = "";
                var utmsIdsLast = getUTMId(true)
                $.each(utmId, function (index, name) {
                    if(index > 0) {
                        utmIdListLast+="|";
                    }
                    utmIdListLast+=name+":"+utmsIdsLast[name];
                });


                var utmLast = "";
                var utmsLast = getUTMs(true)
                $.each(utmTerms, function (index, name) {
                    if(index > 0) {
                        utmLast+="|";
                    }
                    utmLast+=name+":"+utmsLast[name];
                });

                var dateTime = getDateTime();
                var landing = Cookies.get('pys_landing_page');
                var lastLanding = Cookies.get('last_pys_landing_page');
                var trafic = Cookies.get('pysTrafficSource');
                var lastTrafic = Cookies.get('last_pysTrafficSource');

                var $form = null;
                if($('body').hasClass('woocommerce-checkout')) {
                    $form = $("form.woocommerce-checkout");
                } else {
                    $form = $("#edd_purchase_form");
                }
                var inputs = {'pys_utm':utm,
                    'pys_utm_id':utmIdList,
                    'pys_browser_time':dateTime.join("|"),
                    'pys_landing':landing,
                    'pys_source':trafic,
                    'pys_order_type': $(".wcf-optin-form").length > 0 ? "wcf-optin" : "normal",

                    'last_pys_landing':lastLanding,
                    'last_pys_source':lastTrafic,
                    'last_pys_utm':utmLast,
                    'last_pys_utm_id':utmIdListLast,
                }

                Object.keys(inputs).forEach(function(key,index) {
                    $form.append("<input type='hidden' name='"+key+"' value='"+inputs[key]+"' /> ");
                });


            },

            /**
             * Whether we may capture what the visitor typed into a form.
             *
             * This mirrors the consent checks that already guard manageCookies()
             * further down. It is evaluated per capture rather than once at
             * bind time, so granting consent mid-page starts capture straight
             * away without having to rebind the listeners.
             *
             * With no consent-manager integration configured the answer is yes,
             * which leaves behaviour on such sites unchanged.
             */
            advancedFormDataConsentGiven: function () {

                if ( typeof options.gdpr === 'undefined' ) {
                    return true;
                }

                // Cookiebot
                if ( options.gdpr.cookiebot_integration_enabled && typeof Cookiebot !== 'undefined' ) {
                    return Cookiebot.consented === true
                        || !!Cookiebot.consent[ 'marketing' ]
                        || !!Cookiebot.consent[ 'statistics' ];
                }

                // ConsentMagic
                if ( options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== 'undefined' ) {
                    if ( CS_Data.cs_script_cat.pys == CS_Data.cs_necessary_cat_id || CS_Data.cs_script_cat.pys == 0 ) {
                        return true;
                    }
                    return Cookies.get( 'cs_enabled_cookie_term' + CS_Data.test_prefix + '_' + CS_Data.cs_script_cat.pys ) === 'yes';
                }

                // Cookie Law Info / CookieYes
                if ( options.gdpr.cookie_law_info_integration_enabled ) {
                    let cli_cookie = Cookies.get( 'cookieyes-consent' ) ?? Cookies.get( 'wt_consent' ) ?? Cookies.get( 'viewed_cookie_policy' );
                    if ( typeof cli_cookie === 'undefined' ) {
                        return false;
                    }
                    if ( cli_cookie === Cookies.get( 'cookieyes-consent' ) || cli_cookie === Cookies.get( 'wt_consent' ) ) {
                        return getCookieYes( 'analytics' ) === 'yes';
                    }
                    return cli_cookie === 'yes';
                }

                // Cookie Notice
                if ( options.gdpr.cookie_notice_integration_enabled && typeof cnArgs !== 'undefined' ) {
                    return Cookies.get( cnArgs.cookieName ) === 'true';
                }

                return true;
            },

            /**
             * js-cookie 2.1.3 builds the cookie string from a fixed list of
             * attributes - expires, path, domain, secure - so a sameSite passed
             * to Cookies.set() is silently dropped. This cookie holds what the
             * visitor typed into a form, so it is written by hand to get both
             * SameSite and Secure onto it.
             *
             * HttpOnly is not available here: Meta's and TikTok's browser pixels
             * are fed from this value, so the page has to be able to read it.
             */
            setAdvancedFormDataCookie: function ( data ) {

                let days = parseInt( options.cookie && options.cookie.advanced_form_data_expire ) || 30;
                let expires = new Date();
                expires.setTime( expires.getTime() + days * 864e5 );
                // '' means host-only, which is what every other writer here gets too.
                let scope = cookieDomain();

                let cookie = 'pys_advanced_form_data=' + encodeURIComponent( JSON.stringify( data ) )
                    + '; expires=' + expires.toUTCString()
                    + '; path=/'
                    + ( scope ? '; domain=' + scope : '' )
                    + '; samesite=lax';

                // Secure would make the cookie unwritable on a plain-HTTP site,
                // which would silently break matching on local and dev installs.
                if ( window.location.protocol === 'https:' ) {
                    cookie += '; secure';
                }

                document.cookie = cookie;

                // A host-only copy written while the domain was still unknown
                // would shadow this one: the older cookie is listed first, and
                // both js-cookie and PHP read the first match.
                if ( scope ) {
                    document.cookie = 'pys_advanced_form_data=; path=/; max-age=0';
                }
            },

            /**
             * Advanced From Data
             */
            saveAdvancedFormData: function ( email, phone, firstName, lastName, override = true ) {

                if ( !Utils.advancedFormDataConsentGiven() ) {
                    return;
                }

                if ( !options.cookie.disabled_advanced_form_data_cookie ) {
                    let data = Utils.getAdvancedFormData();
                    // Ensure data["address"] is an object

                    if ( email != null ) {
                        if ( !override ) {
                            if ( typeof data[ "email" ] === 'undefined' || !data[ "email" ] ) {
                                data[ "email" ] = email;
                            }
                        } else {
                            data[ "email" ] = email;
                        }

                        if ( typeof data[ "emails" ] === 'object' ) {
                            if ( override ) {
                                data[ "emails" ] = [ email, ...Object.values( data[ "emails" ] ) ];
                            } else {
                                data[ "emails" ] = [ ...Object.values( data[ "emails" ] ), email ];
                            }
                        } else {
                            data[ "emails" ] = [ email ];
                        }
                        data[ "emails" ] = [ ...new Set( data[ "emails" ] ) ];
                        data[ "emails" ] = data[ "emails" ].slice( 0, 3 );
                    }

                    if ( phone != null ) {
                        if ( !override ) {
                            if ( typeof data[ "phone" ] === 'undefined' || !data[ "phone" ] ) {
                                data[ "phone" ] = phone;
                            }
                        } else {
                            data[ "phone" ] = phone;
                        }

                        if ( typeof data[ "phones" ] === 'object' ) {
                            if ( override ) {
                                data[ "phones" ] = [ phone, ...Object.values( data[ "phones" ] ) ];
                            } else {
                                data[ "phones" ] = [ ...Object.values( data[ "phones" ] ), phone ];
                            }
                        } else {
                            data[ "phones" ] = [ phone ];
                        }
                        data[ "phones" ] = [ ...new Set( data[ "phones" ] ) ];
                        data[ "phones" ] = data[ "phones" ].slice( 0, 3 );
                    }

                    if ( firstName != null ) {
                        if ( !override ) {
                            if ( typeof data[ "first_name" ] === 'undefined' || !data[ "first_name" ] ) {
                                data[ "first_name" ] = firstName;
                            }
                        } else {
                            data[ "first_name" ] = firstName;
                        }

                        if ( typeof data[ "fns" ] === 'object' ) {
                            if ( override ) {
                                data[ "fns" ] = [ firstName, ...Object.values( data[ "fns" ] ) ];
                            } else {
                                data[ "fns" ] = [ ...Object.values( data[ "fns" ] ), firstName ];
                            }
                        } else {
                            data[ "fns" ] = [ firstName ];
                        }
                        data[ "fns" ] = [ ...new Set( data[ "fns" ] ) ];
                        data[ "fns" ] = data[ "fns" ].slice( 0, 2 );
                    }

                    if ( lastName != null ) {
                        if ( !override ) {
                            if ( typeof data[ "last_name" ] === 'undefined' || !data[ "last_name" ] ) {
                                data[ "last_name" ] = lastName;
                            }
                        } else {
                            data[ "last_name" ] = lastName;
                        }

                        if ( typeof data[ "lns" ] === 'object' ) {
                            if ( override ) {
                                data[ "lns" ] = [ lastName, ...Object.values( data[ "lns" ] ) ];
                            } else {
                                data[ "lns" ] = [ ...Object.values( data[ "fns" ] ), lastName ];
                            }
                        } else {
                            data[ "lns" ] = [ lastName ];
                        }
                        data[ "lns" ] = [ ...new Set( data[ "lns" ] ) ];
                        data[ "lns" ] = data[ "lns" ].slice( 0, 2 );
                    }

                    Utils.setAdvancedFormDataCookie( data );
                } else {
                    // Same cookie, same two disagreeing writers, so the same pair of
                    // deletes -- see the long note at the disabled_advanced_form_data_cookie
                    // branch in pysNormalInit(). `domain: ''` means host-only.
                    Cookies.remove( 'pys_advanced_form_data', { path: '/',domain: cookieDomain() } )
                    Cookies.remove( 'pys_advanced_form_data', { path: '/',domain: '' } )
                }
                if(GTM.isEnabled()){
                    GTM.updateEnhancedConversionData();
                }
                if(Analytics.isEnabled()){
                    Analytics.updateEnhancedConversionData();
                } else if ( GAds.isEnabled() ) {
                    GAds.updateEnhancedConversionData();
                }
                if ( Bing.isEnabled() && typeof Bing.updateEnhancedConversionData === 'function' ) {
                    Bing.updateEnhancedConversionData();
                }
            },
            getAdvancedMergeFormData: function (allways_provided_data = false) {
                const advanced = Utils.getAdvancedFormData();
                let mergedData = {},
                    limit = options.tracking_analytics.use_multiple_provided_data || allways_provided_data ? 3 : 1,
                    address_limit = options.tracking_analytics.use_multiple_provided_data || allways_provided_data ? 2 : 1;

                // These values come partly from a cookie PHP also writes, so any of them
                // can be missing, null or empty. sha256() throws on anything but a
                // string, and hashing '' would send Google the hash of nothing.
                const hash = ( value ) => ( typeof value === 'string' && value !== '' ) || typeof value === 'number'
                    ? sha256( String( value ) )
                    : '';

                if ( options.tracking_analytics.use_encoding_provided_data || allways_provided_data) {
                    mergedData.sha256_email_address = [];
                    mergedData.sha256_phone_number = [];
                    mergedData.address = [];
                    if ( options.tracking_analytics.hasOwnProperty( "userData" ) ) {
                        if ( options.tracking_analytics.userData.hasOwnProperty( "emails" ) && Object.keys( options.tracking_analytics.userData.emails ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.emails ).forEach( ( key ) => {
                                mergedData.sha256_email_address.push( hash( options.tracking_analytics.userData.emails[ key ] ) );
                            } )
                        }
                        if ( options.tracking_analytics.userData.hasOwnProperty( "phones" ) && Object.keys( options.tracking_analytics.userData.phones ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.phones ).forEach( ( key ) => {
                                mergedData.sha256_phone_number.push( hash( options.tracking_analytics.userData.phones[ key ] ) );
                            } )
                        }
                        if ( options.tracking_analytics.userData.hasOwnProperty( "addresses" ) && Object.keys( options.tracking_analytics.userData.addresses ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.addresses ).forEach( ( key ) => {
                                let address = Object.assign( {}, options.tracking_analytics.userData.addresses[ key ] );

                                if ( address.first_name ) {
                                    address.sha256_first_name = hash( address.first_name );
                                    delete address.first_name;
                                }
                                if ( address.last_name ) {
                                    address.sha256_last_name = hash( address.last_name );
                                    delete address.last_name;
                                }
                                mergedData.address.push( address );
                            } )
                        }
                    }

                    let data_persistency = options.data_persistency;

                    //emails
                    if ( advanced.emails && Object.keys( advanced.emails ).length > 0 ) {
                        Object.keys( advanced.emails ).forEach( ( key ) => {
                            if ( data_persistency === 'recent_data' ) {
                                mergedData.sha256_email_address.push( hash( advanced.emails[ key ] ) );
                            } else {
                                mergedData.sha256_email_address.unshift( hash( advanced.emails[ key ] ) );
                            }
                        } )
                    }
                    if ( advanced.email && advanced.email !== '' ) {
                        if ( data_persistency === 'recent_data' ) {
                            mergedData.sha256_email_address.push( hash( advanced.email ) );
                        } else {
                            mergedData.sha256_email_address.unshift( hash( advanced.email ) );
                        }
                    }
                    mergedData.sha256_email_address = [ ...new Set( mergedData.sha256_email_address.filter( Boolean ) ) ];
                    mergedData.sha256_email_address = mergedData.sha256_email_address.slice( 0, limit );

                    //phones
                    if ( advanced.phones && Object.keys( advanced.phones ).length > 0 ) {
                        Object.keys( advanced.phones ).forEach( ( key ) => {
                            if ( data_persistency === 'recent_data' ) {
                                mergedData.sha256_phone_number.push( hash( advanced.phones[ key ] ) );
                            } else {
                                mergedData.sha256_phone_number.unshift( hash( advanced.phones[ key ] ) );
                            }
                        } )
                    }
                    if ( advanced.phone && advanced.phone !== '' ) {
                        if ( data_persistency === 'recent_data' ) {
                            mergedData.sha256_phone_number.push( hash( advanced.phone ) );
                        } else {
                            mergedData.sha256_phone_number.unshift( hash( advanced.phone ) );
                        }
                    }
                    mergedData.sha256_phone_number = [ ...new Set( mergedData.sha256_phone_number.filter( Boolean ) ) ];
                    mergedData.sha256_phone_number = mergedData.sha256_phone_number.slice( 0, limit );

                    //first and last names
                    if ( advanced.fns && Object.keys( advanced.fns ).length > 0 ) {
                        Object.entries( advanced.fns ).forEach( ( item ) => {
                            if ( mergedData.address.length < address_limit ) {
                                let first_name = item[ 1 ];
                                let last_name = ( advanced.lns && Object.keys( advanced.lns ).length > 0 ) ? ( advanced.lns[ item[ 0 ] ] ? advanced.lns[ item[ 0 ] ] : advanced.lns[ 0 ] ) : '';
                                let address = {
                                    sha256_first_name: hash( first_name ),
                                    sha256_last_name: hash( last_name ),
                                    // Add other address properties here if they exist in advanced
                                };
                                if ( address.sha256_first_name || address.sha256_last_name ) {
                                    mergedData.address.push( address );
                                }
                            }
                        } )
                    }

                    if ( advanced.first_name || advanced.last_name ) {
                        if ( mergedData.address.length < address_limit ) {
                            let address = {
                                sha256_first_name: hash( advanced.first_name ),
                                sha256_last_name: hash( advanced.last_name ),
                                // Add other address properties here if they exist in advanced
                            };
                            if ( address.sha256_first_name || address.sha256_last_name ) {
                                mergedData.address.push( address );
                            }
                        }
                    }
                } else {
                    mergedData.email = [];
                    mergedData.phone_number = [];
                    mergedData.address = [];
                    if ( options.tracking_analytics.hasOwnProperty( "userData" ) ) {
                        if ( options.tracking_analytics.userData.hasOwnProperty( "emails" ) && Object.keys( options.tracking_analytics.userData.emails ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.emails ).forEach( ( key ) => {
                                mergedData.email.push( options.tracking_analytics.userData.emails[ key ] );
                            } )
                        }
                        if ( options.tracking_analytics.userData.hasOwnProperty( "phones" ) && Object.keys( options.tracking_analytics.userData.phones ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.phones ).forEach( ( key ) => {
                                mergedData.phone_number.push( options.tracking_analytics.userData.phones[ key ] );
                            } )
                        }
                        if ( options.tracking_analytics.userData.hasOwnProperty( "addresses" ) && Object.keys( options.tracking_analytics.userData.addresses ).length > 0 ) {
                            Object.keys( options.tracking_analytics.userData.addresses ).forEach( ( key ) => {
                                mergedData.address.push( options.tracking_analytics.userData.addresses[ key ] );
                            } )
                        }
                    }

                    let data_persistency = options.data_persistency;

                    //emails
                    if ( advanced.emails && Object.keys( advanced.emails ).length > 0 ) {
                        Object.keys( advanced.emails ).forEach( ( key ) => {
                            if ( data_persistency === 'recent_data' ) {
                                mergedData.email.push( advanced.emails[ key ] );
                            } else {
                                mergedData.email.unshift( advanced.emails[ key ] );
                            }
                        } )
                    }
                    if ( advanced.email && advanced.email !== '' ) {
                        if ( data_persistency === 'recent_data' ) {
                            mergedData.email.push( advanced.email );
                        } else {
                            mergedData.email.unshift( advanced.email );
                        }
                    }
                    mergedData.email = [ ...new Set( mergedData.email ) ];
                    mergedData.email = mergedData.email.slice( 0, limit );

                    //phones
                    if ( advanced.phones && Object.keys( advanced.phones ).length > 0 ) {
                        Object.keys( advanced.phones ).forEach( ( key ) => {
                            if ( data_persistency === 'recent_data' ) {
                                mergedData.phone_number.push( advanced.phones[ key ] );
                            } else {
                                mergedData.phone_number.unshift( advanced.phones[ key ] );
                            }
                        } )
                    }
                    if ( advanced.phone && advanced.phone !== '' ) {
                        if ( data_persistency === 'recent_data' ) {
                            mergedData.phone_number.push( advanced.phone );
                        } else {
                            mergedData.phone_number.unshift( advanced.phone );
                        }
                    }
                    mergedData.phone_number = [ ...new Set( mergedData.phone_number ) ];
                    mergedData.phone_number = mergedData.phone_number.slice( 0, limit );

                    //first and last names
                    if ( advanced.fns && Object.keys( advanced.fns ).length > 0 ) {
                        Object.entries( advanced.fns ).forEach( ( item ) => {
                            if ( mergedData.address.length < address_limit ) {
                                let first_name = item[ 1 ];
                                let last_name = ( advanced.lns && Object.keys( advanced.lns ).length > 0 ) ? ( advanced.lns[ item[ 0 ] ] ? advanced.lns[ item[ 0 ] ] : advanced.lns[ 0 ] ) : '';
                                let address = {
                                    first_name: first_name || '',
                                    last_name: last_name || '',
                                    // Add other address properties here if they exist in advanced
                                };
                                mergedData.address.push( address );
                            }
                        } )
                    }

                    if ( advanced.first_name || advanced.last_name ) {
                        if ( mergedData.address.length < address_limit ) {
                            let address = {
                                first_name: advanced.first_name || '',
                                last_name: advanced.last_name || '',
                                // Add other address properties here if they exist in advanced
                            };
                            mergedData.address.push( address );
                        }
                    }
                }

                Utils.removeEmptyProperties( mergedData );
                return mergedData;
            },
            removeEmptyProperties : function(obj) {

                if (obj.hasOwnProperty('address')) {
                    // Iterate over each array in 'address'
                    for (let i = 0; i < obj['address'].length; i++) {
                        let address1 = obj['address'][i];

                        // Compare with every other array in 'address'
                        for (let j = i + 1; j < obj['address'].length; j++) {
                            let address2 = obj['address'][j];

                            // If duplicate properties are found, remove them from address2
                            for (let prop in address1) {
                                if (address1[prop] === address2[prop]) {
                                    delete address2[prop];
                                }
                            }
                        }
                    }
                }

                for (let key in obj) {
                    if (obj[key] === null || obj[key] === undefined || obj[key] === '') {
                        delete obj[key];
                    } else if (Array.isArray(obj[key])) {
                        obj[key] = [...new Set(obj[key])]; // Remove duplicates from the array
                        obj[key] = obj[key].filter(item => item !== null && item !== undefined && item !== '');
                        // Process objects inside arrays
                        obj[key] = obj[key].map(item => {
                            if (item === null) {
                                return; // Skip null elements
                            } else if (Array.isArray(item)) {
                                return this.removeEmptyProperties(item);
                            } else if (typeof item === 'object') {
                                let cleanedItem = this.removeEmptyProperties(item);
                                if (Object.keys(cleanedItem).length > 0) {
                                    return cleanedItem;
                                }
                            } else {
                                return item;
                            }
                        });
                        // Remove empty objects and null values from the array
                        obj[key] = obj[key].filter(item => item !== undefined && !(typeof item === 'object' && Object.keys(item).length === 0));
                        if (obj[key].length === 0) {
                            delete obj[key];
                        }
                    } else if (typeof obj[key] === 'object') {
                        this.removeEmptyProperties(obj[key]);
                        if (Object.keys(obj[key]).length === 0) {
                            delete obj[key];
                        }
                    }
                }
                return obj;
            },
            getAdvancedFormData: function () {
                let dataStr = Cookies.get("pys_advanced_form_data");
                if(dataStr === undefined) {
                    return {'first_name':"",'last_name':"",'email':"",'phone':"",'fns':[],'lns':[],'emails':[],'phones':[]};
                } else {
                    return JSON.parse(dataStr);
                }
            },

            /**
             * Advanced Matching that the server is no longer allowed to render.
             *
             * Page HTML can be served out of a shared cache, so the server
             * leaves the visitor's own email, phone and name out of pysOptions.
             * The values are on this device in pys_advanced_form_data, so the
             * browser puts them back just before each pixel initialises.
             * Normalisation mirrors the PHP side field for field -- if one
             * moves, both move.
             */
            AdvancedMatching: {

                normalizeEmail: function (value) {
                    if (typeof value !== 'string') {
                        return '';
                    }
                    var email = value.trim().toLowerCase();
                    if (email.length === 0 || email.length > 254) {
                        return '';
                    }
                    return /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/.test(email) ? email : '';
                },

                normalizePhone: function (value) {
                    if (typeof value !== 'string') {
                        return '';
                    }
                    var digits = value.replace(/[^0-9]/g, '');
                    return digits.length > 0 ? digits : '';
                },

                normalizeName: function (value) {
                    if (typeof value !== 'string' || value.length > 1024) {
                        return '';
                    }
                    return value.trim().toLowerCase();
                },

                /**
                 * The identity this device carries, normalised and possibly
                 * all-empty. Never throws when the cookie is absent or corrupt.
                 */
                cookieIdentity: function () {
                    var data;
                    try {
                        data = Utils.getAdvancedFormData() || {};
                    } catch (e) {
                        data = {};
                    }
                    return {
                        email: this.normalizeEmail(data.email || ''),
                        phone: this.normalizePhone(data.phone || ''),
                        first_name: this.normalizeName(data.first_name || ''),
                        last_name: this.normalizeName(data.last_name || '')
                    };
                },

                /**
                 * @param {object} target      The pixel's advanced matching object, edited in place.
                 * @param {object} mapping     {targetKey: {field, hash}}
                 * @param {object} identity    Optional; defaults to cookieIdentity().
                 * @param {string} persistency Optional; defaults to options.data_persistency.
                 */
                merge: function (target, mapping, identity, persistency) {

                    if (!target || !mapping) {
                        return target;
                    }

                    identity = identity || this.cookieIdentity();

                    if (typeof persistency === 'undefined') {
                        persistency = typeof options !== 'undefined' ? options.data_persistency : '';
                    }

                    var keepData = persistency === 'keep_data';

                    Object.keys(mapping).forEach(function (targetKey) {

                        var rule = mapping[targetKey];
                        var value = identity[rule.field];

                        if (typeof value !== 'string' || value.length === 0) {
                            return;
                        }

                        var hasServerValue = typeof target[targetKey] === 'string'
                            && target[targetKey].length > 0;

                        if (hasServerValue && !keepData) {
                            return;
                        }

                        if (rule.hash) {
                            if (typeof sha256 !== 'function') {
                                return;
                            }
                            target[targetKey] = sha256(value);
                        } else {
                            target[targetKey] = value;
                        }
                    });

                    return target;
                }
            },

            getFormFilledData: function ( event ) {
                // First, resolve static/dynamic parameters
                if (event.params && Object.keys(event.params).length > 0) {
                    Object.entries(event.params).forEach(([key, value]) => {
                        // Resolve parameter value (static or dynamic)
                        const resolvedValue = resolveParamValue(value, key);
                        if (resolvedValue !== null) {
                            event.params[key] = resolvedValue;
                        }
                        else {
                            delete event.params[key];
                        }
                    });
                }

                // Then, handle dynamic fields from cookies (existing logic)

                if ( Object.keys(options.track_dynamic_fields).length > 0 && Object.keys(event.params).length > 0 ) {
                    Object.entries(event.params).forEach((item) => {

                        if ( options.track_dynamic_fields.hasOwnProperty(item[0]) ) {
                            let fieldData = Cookies.get('pys_dyn_field_' + item[1] );

                            if(fieldData !== undefined && fieldData !== '') {
                                event.params[item[0]] = fieldData;
                            } else {
                                delete event.params[item[0]];
                            }
                        }
                    })
                }
                return event;
            },

            registerGadsPhoneConversion( conversion_id ) {
                // Ads phone call conversion
                if ( options.triggerEventTypes.hasOwnProperty( 'gads_phone_conversion' ) ) {
                    Object.entries( options.triggerEventTypes.gads_phone_conversion ).forEach( function ( [ trigger_id, data ] ) {
                        if ( data.enabled && Object.entries( data.numbers ).length > 0 ) {

                            let allowed_pixels = [];
                            Object.entries( options.triggerEvents[ trigger_id ] ).forEach( function ( [ pixel, pixel_data ] ) {
                                if ( pixel !== 'google_ads' ) {
                                    return;
                                }

                                allowed_pixels.push( ...pixel_data.conversion_ids );
                            } )

                            if ( !allowed_pixels.includes( conversion_id ) ) {
                                return;
                            }

                            data.numbers.forEach( function ( pair ) {
                                if ( !pair.number || !pair.label ) {
                                    return;
                                }

                                let phoneCb = function () {
                                    Utils.fireTriggerEvent( trigger_id )
                                };

                                Utils.gtagPush( 'config', conversion_id + '/' + pair.label, {
                                    phone_conversion_number: pair.number,
                                    phone_conversion_callback: phoneCb
                                } );
                            } )
                        }
                    } );
                }
            }
        }


    }(options);

    var TikTok = function (options) {

        var initialized = false;

        // TikTok appends its click id to the ad landing page URL. Unlike Meta's
        // fbc it is sent to the Events API raw, with no 'tt.1.<timestamp>.'
        // style prefix, so no formatting is applied here.
        var TTCLID_COOKIE = 'pys_ttclid';

        // Click id seen on this page load, kept so a brand new ad click beats a
        // cookie left over from an earlier one. Mirrors the same memo in
        // TikTokServer, and means the URL is only ever read from storeTtclid(),
        // behind the consent check in loadPixel().
        var freshTtclid = '';

        // Persist the click id so it is still around at checkout, which is where
        // it matters most for match rate. Deliberately writes our own cookie and
        // never TikTok's: the format of theirs is theirs to change.
        var storeTtclid = function () {
            var ttclid = getUrlParameter('ttclid');

            if (!ttclid) {
                return;
            }

            freshTtclid = ttclid;

            // options.cookie arrives asynchronously (dynamic-options REST, for
            // cached pages) and loadPixel usually runs first. Absent config is
            // "not disabled", the same reading reportCookieDomain uses —
            // requiring it to be present meant the click id was never
            // persisted at all, on every page load.
            if (options.cookie && options.cookie.disabled_all_cookie) {
                return;
            }

            Cookies.set(TTCLID_COOKIE, ttclid, {
                // TikTok asks for a TTL of 28 days or more; PHP twin:
                // ttclidCookieLifetime(). The fallback covers a page cached
                // before the option existed.
                expires: parseInt(options.tt_cookie_duration) || 90,
                path: '/',
                domain: cookieDomain()
            });
        };

        // Read the click id the same way PHP does: this page load's value first,
        // then the cookie the TikTok SDK writes itself, then ours.
        var getTtclid = function () {
            // The SDK's own cookie is `<ttclid>.<ms timestamp>` — its storage
            // format, not the click id. PHP twin: getTtclidFromCookie().
            var sdk = Cookies.get('ttclid');

            if (sdk) {
                sdk = sdk.replace(/\.\d{13}$/, '');
            }

            return freshTtclid
                || sdk
                || Cookies.get(TTCLID_COOKIE)
                || '';
        };

        function fireEvent(name, event) {

            if(typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name,'tiktok')) {
                return;
            }

            var data = event.params;

            var ids = event.pixelIds.filter(function (pixelId) {
                return !Utils.hideMatchingPixel(pixelId, 'tiktok');
            })
            var params = {};
            Utils.copyProperties(data, params);

            params.eventID = Utils.generateUniqueId(event);

            if(ids.length > 0){
                TikTok.fireEventAPI(name, event, params);
            }
            ids.forEach(function(pixelId){
                if (options.debug) {
                    console.log('[TikTok] ' + name, params,"pixel_id",pixelId);
                }

                ttq.instance(pixelId).track(name,params)

            });

            var customEvent = new CustomEvent('tiktok_event_sent', {
                detail: {
                    eventName: name,
                    params: params,
                    pixel_ids: ids
                }
            });
            window.dispatchEvent(customEvent);
        }

        return {
            tag: function() {
                return "tiktok";
            },
            isEnabled: function () {
                return options.hasOwnProperty('tiktok');
            },
            getHidePixel: function(){
                if(this.isEnabled() && options.tiktok.hasOwnProperty('hide_pixels'))
                {
                    return options.tiktok.hide_pixels;
                }
                return [];
            },
            disable: function () {
                initialized = false;
            },

            loadPixel:function () {
                if (initialized || !this.isEnabled() || !Utils.consentGiven('tiktok')) {
                    return;
                }

                // Same first-visit hold as Facebook.loadPixel(): TikTok's
                // advanced matching carries external_id too.
                if (Utils.holdForIdentity(function () { TikTok.loadPixel(); })) {
                    return;
                }
                for (var i = 0; i < options.tiktok.pixelIds.length; i++) {
                    var trackingId = options.tiktok.pixelIds[i];
                    if (!Utils.hideMatchingPixel(trackingId, 'tiktok')) {
                        !function (w, d, t) {
                            w.TiktokAnalyticsObject=t;
                            var ttq=w[t]=w[t]||[];
                            ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"];
                            ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};
                            for(var i=0;i<ttq.methods.length;i++)
                                ttq.setAndDefer(ttq,ttq.methods[i]);
                            ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e};
                            ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};

                            //ttq.load('C60QSCQRVDG9JAKNPK2G');
                            //ttq.page();
                        }(window, document, 'ttq');
                        break;
                    }
                }

                // Consent for TikTok is confirmed by the guard above, so the
                // click id may be persisted now.
                storeTtclid();

                var ids = options.tiktok.pixelIds.filter(function (pixelId) {
                    return !Utils.hideMatchingPixel(pixelId, 'tiktok');
                })
                ids.forEach(function (pixelId) {

                    ttq.load(pixelId);
                    ttq.page();
                    let advancedMatching = {};

                    if (options.tiktok.hasOwnProperty('advanced_matching')) {
                        advancedMatching = Object.assign({}, options.tiktok.advanced_matching || {});
                    }

                    // The server leaves the visitor's own email and phone out of
                    // the page so a shared cache cannot replay them. TikTok hashes
                    // the same way on both sides.
                    Utils.AdvancedMatching.merge(advancedMatching, {
                        sha256_email:        { field: 'email', hash: true },
                        sha256_phone_number: { field: 'phone', hash: true }
                    });

                    if (!advancedMatching.hasOwnProperty("external_id")) {
                        if (Cookies.get('pbid')) {
                            advancedMatching["external_id"] = Cookies.get('pbid');
                        }
                    } else if (advancedMatching.external_id != Cookies.get('pbid')) {
                        advancedMatching["external_id"] = Cookies.get('pbid') ? Cookies.get('pbid') : advancedMatching.external_id;
                    }

                    if (Object.keys(advancedMatching).length > 0) {
                        ttq.instance(pixelId).identify(advancedMatching)
                    }
                });
                initialized = true;

                if (options.staticEvents.hasOwnProperty('tiktok')) {
                    var timeout = 1;
                    setTimeout(function (timeout) {
                        Utils.fireStaticEvents('tiktok', timeout);
                    }, 1500, timeout)
                }
            },

            fireEvent: function (name, data) {
                if (!initialized || !this.isEnabled()) {
                    return false;
                }
                data.delay = data.delay || 0;

                if (data.delay === 0) {
                    fireEvent(name, data);
                } else {
                    setTimeout(function (name, params) {
                        fireEvent(name, params);
                    }, data.delay * 1000, name, data);
                }
                return true;
            },

            fireEventAPI: function (name, event, params) {

                var ids = event.pixelIds.filter(function (pixelId) {
                    return !Utils.hideMatchingPixel(pixelId, 'tiktok');
                })
                var notCachedEventsIds = new Array();
                var isAddToCartFromJs =  options.woo.hasOwnProperty("addToCartCatchMethod")
                    && options.woo.addToCartCatchMethod === "add_cart_js";
                if(!isAddToCartFromJs) {
                    notCachedEventsIds.push('woo_add_to_cart_on_button_click')
                }

                if(options.tiktok.serverApiEnabled) {
                    if(!notCachedEventsIds.includes(event.e_id)) {

                        var isApiDisabled = options.gdpr.all_disabled_by_api ||
                            options.gdpr.tiktok_disabled_by_api ||
                            options.gdpr.cookiebot_integration_enabled ||
                            options.gdpr.cookie_notice_integration_enabled ||
                            options.gdpr.consent_magic_integration_enabled ||
                            options.gdpr.cookie_law_info_integration_enabled;
                        // Update eventID

                        // send event from server if they were block by gdpr or need send with delay
                        if( options.ajaxForServerEvent || isApiDisabled || event.delay > 0 || event.type !== "static" ){

                            // Fallback for the case where the landing page was
                            // served from a cache and no cookie ever reached
                            // PHP. The click id goes into a copy of the params:
                            // this same object is handed to ttq.track(), and the
                            // browser pixel reads the click id by itself.
                            var apiParams = {};
                            Utils.copyProperties(params, apiParams);

                            var ttclid = getTtclid();
                            if (ttclid) {
                                apiParams.ttclid = ttclid;
                            }

                            var json = {
                                action: 'pys_tiktok_api_event',
                                pixel: TikTok.tag(),
                                event: name,
                                event_slug: event.e_id,
                                ids: ids,
                                data:apiParams,
                                url:window.location.href,
                                event_id:params.eventID,
                                ajax_event:options.ajax_event
                            };

                            let delay = 0;
                            try {
                                if (sessionStorage) {
                                    Object.keys(sessionStorage)
                                        .filter(key => key.startsWith('wc_fragments_'))
                                        .forEach((key) => {
                                            let value = sessionStorage.getItem(key);
                                            if (event.e_id === 'woo_add_to_cart_on_button_click') {
                                                delay = 2000;
                                            }
                                        });
                                }
                            } catch (error) {
                                console.error('sessionStorage is not accessible:', error);
                            }


                            if(event.hasOwnProperty('woo_order')) {
                                json['woo_order'] = event.woo_order;
                            }

                            if(event.hasOwnProperty('edd_order')) {
                                json['edd_order'] = event.edd_order;
                            }

                            // Forward the order key so the server can bind the
                            // purchase event to its specific order (RestPurchaseGuard).
                            if(event.hasOwnProperty('order_key') && event.order_key) {
                                json['order_key'] = event.order_key;
                            }
                            if (event.e_id === "automatic_event_internal_link" || event.e_id === "automatic_event_outbound_link" || name == 'PageView') {
                                delay = delay === 0 ? 500 : delay;
                                setTimeout(() => Utils.sendServerAjaxRequest(options.ajaxUrl, json), delay);
                            } else if (event.type != 'static') {
                                setTimeout(() => Utils.sendServerAjaxRequest(options.ajaxUrl, json), delay);
                            }

                            if ( ( event.type == 'static' && options.ajaxForServerStaticEvent ) || ( event.hasOwnProperty( 'ajaxFire' ) && event.ajaxFire ) ) {
                                setTimeout( () => Utils.sendServerAjaxRequest( options.ajaxUrl, json ), delay );
                            }
                        }
                    }
                }
            },

            onClickEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {

                window.pysWooProductData = window.pysWooProductData || {};
                if (!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                // The click handler passes the parent id from input[name="add-to-cart"];
                // the selected variation lives in its own hidden input. Without this swap
                // TikTok reported the parent while facebook, ga, google_ads and gtm all
                // reported the variation, even though wooVariableAsSimple was off.
                if (product_type === Utils.PRODUCT_VARIABLE && !options.tiktok.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty(this.tag())) {

                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                        Utils.copyProperties(window.pysWooProductData[product_id][this.tag()]['params'], event.params);

                        // maybe customize value option
                        if (options.woo.addToCartOnButtonValueEnabled && options.woo.addToCartOnButtonValueOption !== 'global') {

                            if (product_type === Utils.PRODUCT_BUNDLE) {
                                var data = $(".bundle_form .bundle_data").data("bundle_form_data");
                                var items_sum = getBundlePriceOnSingleProduct(data);
                                event.params.value = (parseFloat(data.base_price) + items_sum) * qty;
                            } else {
                                event.params.value = event.params.value * qty;
                            }
                        }

                        event.params.quantity = qty;

                        this.fireEvent(event.name, event);

                    }
                }
            },

            onWooAddToCartOnButtonEvent: function (product_id) {
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty(this.tag())) {
                        var productData = window.pysWooProductData[product_id][this.tag()]
                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()])

                        Utils.copyProperties(productData['params'], event.params)
                        event.pixelIds = productData['pixelIds'];
                        this.fireEvent(event.name, event);
                    }
                }
            },

            onEddAddToCartOnButtonEvent : function (download_id, price_index, qty) {
                if(!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()]);


                if (window.pysEddProductData && window.pysEddProductData.hasOwnProperty(download_id)) {

                    var index;

                    if (price_index) {
                        index = download_id + '_' + price_index;
                    } else {
                        index = download_id;
                    }

                    if (window.pysEddProductData[download_id].hasOwnProperty(index)) {
                        if (window.pysEddProductData[download_id][index].hasOwnProperty(this.tag())) {

                            Utils.copyProperties(window.pysEddProductData[download_id][index][this.tag()].params, event.params);
                            this.fireEvent(event.name,event);

                        }
                    }

                }
            },

            onPageScroll: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },

            onWatchVideo: function (event) {
                if (initialized && this.isEnabled() && !event.fired) {
                    this.fireEvent(event.name, event);
                }
            },

            onCommentEvent: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },

            onAdSenseEvent: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },

            onTime: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
        }
    }(options);

    var OpenAI = function (options) {

        let initialized = false,
			sentIdentity = null,
            identityWaitTimer = null,
            identityWaitExpired = false;

        function visiblePixelIds(ids) {
            return (ids || []).filter(function (pixelId) {
                return !Utils.hideMatchingPixel(pixelId, 'openai');
            });
        }
        /**
         * Is the pixel in OpenAI's restricted mode?
         */
        function optOutMode() {

            if ( options.openai && options.openai.opt_out ) {
                return true;
            }

            return !! ( options.gdpr
                && options.gdpr.consent_magic_integration_enabled
                && typeof CS_Data !== 'undefined'
                && Utils.csModeEnabled( CS_Data.cs_openai_opt_out_mode ) );
        }


		const SDK_DATA_FIELDS = {
            contents: ['type', 'amount', 'currency', 'contents'],
            custom: ['type', 'plan_id', 'amount', 'currency', 'contents'],
            customer_action: ['type', 'amount', 'currency'],
            plan_enrollment: ['type', 'plan_id', 'amount', 'currency', 'contents']
        };

        const SDK_ITEM_FIELDS = ['id', 'name', 'content_type', 'quantity', 'amount', 'currency'];

        function sdkInteger(value) {
            let number = typeof value === 'string' ? Number(value.trim()) : value;

            return typeof number === 'number' && isFinite(number) ? Math.round(number) : null;
        }

        function sdkCurrency(value) {
            return typeof value === 'string' && /^[A-Za-z]{3}$/.test(value) ? value : null;
        }

        function sdkText(value) {
            if (typeof value === 'string') {
                return value === '' ? null : value;
            }

            return typeof value === 'number' && isFinite(value) ? String(value) : null;
        }

        /**
         * One contents[] item, with only the keys the SDK documents.
         *
         * @param item              the item as configured or collected
         * @param eventHasCurrency  true when data.currency is set: an item amount
         *                          needs a currency, its own or the event's
         */
        function sdkSafeItem(item, eventHasCurrency) {

            if (!item || typeof item !== 'object' || Array.isArray(item)) {
                return null;
            }

            let safe = {};

            SDK_ITEM_FIELDS.forEach(function (field) {
                if (item[field] === undefined || item[field] === null || item[field] === '') {
                    return;
                }

                if (field === 'quantity' || field === 'amount') {
                    let number = sdkInteger(item[field]);

                    if (number !== null) {
                        safe[field] = number;
                    }

                    return;
                }

                if (field === 'currency') {
                    let currency = sdkCurrency(item.currency);

                    if (currency !== null) {
                        safe.currency = currency;
                    }

                    return;
                }

                let text = sdkText(item[field]);

                if (text !== null) {
                    safe[field] = text;
                }
            });

            if (safe.hasOwnProperty('amount') && !safe.hasOwnProperty('currency') && !eventHasCurrency) {
                delete safe.amount;
            }

            return Object.keys(safe).length ? safe : null;
        }

        /**
         * The event data, with only the fields the SDK documents for its shape.
         */
        function sdkSafeData(data) {

            if (!data || typeof data !== 'object') {
                return {};
            }

            let allowed = SDK_DATA_FIELDS[data.type];

            if (!allowed) {
                return data;
            }

            let safe = {};

            allowed.forEach(function (field) {
                if (data[field] !== undefined && data[field] !== null && data[field] !== '') {
                    safe[field] = data[field];
                }
            });

            if (safe.hasOwnProperty('plan_id')) {
                let planId = sdkText(safe.plan_id);

                if (planId === null) {
                    delete safe.plan_id;
                } else {
                    safe.plan_id = planId;
                }
            }

            if (safe.hasOwnProperty('currency')) {
                let currency = sdkCurrency(safe.currency);

                if (currency === null) {
                    delete safe.currency;
                } else {
                    safe.currency = currency;
                }
            }

            if (safe.hasOwnProperty('amount')) {
                let amount = sdkInteger(safe.amount);

                // The SDK refuses an amount with no currency beside it.
                if (amount === null || !safe.hasOwnProperty('currency')) {
                    delete safe.amount;
                } else {
                    safe.amount = amount;
                }
            }

            if (safe.hasOwnProperty('contents')) {
                let items = Array.isArray(safe.contents)
                    ? safe.contents
                        .map(function (item) { return sdkSafeItem(item, safe.hasOwnProperty('currency')); })
                        .filter(function (item) { return item !== null; })
                    : [];

                if (items.length) {
                    safe.contents = items;
                } else {
                    delete safe.contents;
                }
            }

            return safe;
        }

        function fireEvent(name, event) {

            if (typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name, 'openai')) {
                return;
            }

            if (typeof window.oaiq !== 'function') {
                return;
            }

            let ids = visiblePixelIds(event.pixelIds);

            if (ids.length === 0) {
                return;
            }

            let data = (event.params && event.params.data) ? Utils.clone(event.params.data) : {};

            let eventOptions = {},
                eventId = Utils.generateUniqueId(event);

            if (eventId) {
                eventOptions.event_id = eventId;
            }

            if (event.params && event.params.custom_event_name) {
                eventOptions.custom_event_name = event.params.custom_event_name;
            }

            OpenAI.fireEventAPI(name, event, data, eventId, ids);

            let browserData = sdkSafeData(data);

            if (optOutMode()) {
                eventOptions.opt_out = true;
            }

            if (options.debug) {
                console.log('[OpenAI] ' + name, browserData, eventOptions, 'pixel_ids', ids);
            }

            ids.forEach(function (pixelId) {
                oaiq('measureSingle', pixelId, name, browserData, eventOptions);
            });

            let customEvent = new CustomEvent('openai_event_sent', {
                detail: {
                    eventName: name,
                    data: data,
                    options: eventOptions,
                    pixel_ids: ids
                }
            });
            window.dispatchEvent(customEvent);
        }

        /**
         * True while the visitor's identity is still in flight.
         */
        function identityPending() {
            return ! identityWaitExpired
                && ! options.dynamicDataApplied
                && !! options.dynamicDataUrl;
        }


        const OPENAI_USER_FIELDS = [
            'email_sha256',
            'phone_number_sha256',
            'external_id_sha256',
            'first_name_sha256',
            'last_name_sha256',
            'country',
            'city',
            'region',
            'postal_code'
        ];

        /**
         * OpenAI normalises more aggressively than the other pixels: the phone
         * is reduced to its national digit form (leading +, 00 and zeros
         * stripped, then length-validated), and names lose every punctuation
         * and whitespace character. Mirrors pys_openai_normalize_* in
         * modules/openai/function_helpers.php.
         */
        function openaiCookieIdentity() {

            let raw;

            try {
                raw = Utils.getAdvancedFormData() || {};
            } catch (e) {
                raw = {};
            }

            let phone = typeof raw.phone === 'string'
                ? raw.phone.trim().replace(/[\s().-]+/g, '')
                : '';

            if (!/^\+?[0-9]+$/.test(phone) || phone.indexOf('+0') === 0) {
                phone = '';
            } else {
                let international = phone.indexOf('+') === 0 || phone.indexOf('00') === 0;
                let national = phone.replace(/^\+?0*/, '');

                if (international && national.indexOf('1') === 0 && national.length !== 11) {
                    national = '';
                }

                phone = /^[1-9][0-9]{7,14}$/.test(national) ? national : '';
            }

            let normalizeName = function (value) {
                if (typeof value !== 'string' || value.length > 1024) {
                    return '';
                }
                let stripped = value.replace(/[!-\/:-@\[-`{-~\s]+/g, '').toLowerCase();
                return /\D/u.test(stripped) ? stripped : '';
            };

            return {
                email: Utils.AdvancedMatching.normalizeEmail(raw.email || ''),
                phone: phone,
                first_name: normalizeName(raw.first_name || ''),
                last_name: normalizeName(raw.last_name || '')
            };
        }

        /**
         * The identity to hand the SDK, built from whatever is known right now.
         */
        function buildAdvancedMatchingUser() {

            let user = {};

            if (options.openai.hasOwnProperty('advanced_matching')) {

                let matching = options.openai.advanced_matching;

                OPENAI_USER_FIELDS.forEach(function (field) {
                    let value = matching[field];

                    if (typeof value === 'string' && value.length > 0) {
                        user[field] = value;
                    }
                });
            }

            Utils.AdvancedMatching.merge(user, {
                email_sha256:        { field: 'email',      hash: true },
                phone_number_sha256: { field: 'phone',      hash: true },
                first_name_sha256:   { field: 'first_name', hash: true },
                last_name_sha256:    { field: 'last_name',  hash: true }
            }, openaiCookieIdentity());

            let externalIdAllowed = options.send_external_id
                && ! ( options.gdpr && options.gdpr.externalID_disabled_by_api )
                && ! ( options.cookie
                    && ( options.cookie.disabled_all_cookie
                        || options.cookie.externalID_disabled_by_api ) );

            if (!user.hasOwnProperty('external_id_sha256')
                && externalIdAllowed
                && typeof sha256 === 'function'
                && Cookies.get('pbid')) {
                user.external_id_sha256 = sha256(Cookies.get('pbid'));
            }

            return user;
        }

        return {
            tag: function () {
                return "openai";
            },

            fireEventAPI: function (name, event, data, eventId, ids) {

                if (!this.isEnabled() || !options.openai.serverApiEnabled) {
                    return;
                }

                let notCachedEventsIds = [],
                    isAddToCartFromJs = options.hasOwnProperty('woo')
                    && options.woo.hasOwnProperty('addToCartCatchMethod')
                    && options.woo.addToCartCatchMethod === 'add_cart_js';

                if (!isAddToCartFromJs) {
                    notCachedEventsIds.push('woo_add_to_cart_on_button_click');
                }

                if (notCachedEventsIds.indexOf(event.e_id) !== -1) {
                    return;
                }

                let isApiDisabled = options.gdpr.all_disabled_by_api ||
                    options.gdpr.openai_disabled_by_api ||
                    options.gdpr.cookiebot_integration_enabled ||
                    options.gdpr.cookie_notice_integration_enabled ||
                    options.gdpr.consent_magic_integration_enabled ||
                    options.gdpr.cookie_law_info_integration_enabled;

                let forcedToBrowser = ( event.hasOwnProperty( 'ajaxFire' ) && event.ajaxFire )
                    || isApiDisabled
                    || event.delay > 0;

                if (event.type === "static" && !forcedToBrowser
                    && !(options.ajaxForServerEvent && options.ajaxForServerStaticEvent)) {
                    return;
                }

                if (!(options.ajaxForServerEvent || forcedToBrowser || event.type !== "static")) {
                    return;
                }

                let params = {data: data};

                if (event.params && event.params.custom_event_name) {
                    params.custom_event_name = event.params.custom_event_name;
                }

                let json = {
                    action: 'pys_openai_api_event',
                    pixel: OpenAI.tag(),
                    event: name,
                    event_slug: event.e_id,
                    ids: ids,
                    data: params,
                    url: window.location.href,
                    event_id: eventId,
                    ajax_event: options.ajax_event
                };

                if (event.hasOwnProperty('woo_order')) {
                    json['woo_order'] = event.woo_order;
                }

                if (event.hasOwnProperty('edd_order')) {
                    json['edd_order'] = event.edd_order;
                }

                if (event.hasOwnProperty('order_key') && event.order_key) {
                    json['order_key'] = event.order_key;
                }

                var delay = 0;

                if (name === 'page_viewed') {
                    delay = 500;
                }

                setTimeout(function () {
                    Utils.sendServerAjaxRequest(options.ajaxUrl, json);
                }, delay);
            },

            isEnabled: function () {
                return options.hasOwnProperty('openai');
            },
            getHidePixel: function () {
                if (this.isEnabled() && options.openai.hasOwnProperty('hide_pixels')) {
                    return options.openai.hide_pixels;
                }
                return [];
            },
            disable: function () {
                initialized = false;

                if (typeof window.oaiq === 'function') {
                    oaiq('consent', false);
                }
            },

            loadPixel: function () {

                if (initialized || !this.isEnabled() || !Utils.consentGiven('openai')) {
                    return;
                }

                let ids = visiblePixelIds(options.openai.pixelIds);

                if (ids.length === 0) {
                    return;
                }

                if (identityPending()) {

                    if (identityWaitTimer === null) {
                        identityWaitTimer = setTimeout(function () {
                            identityWaitExpired = true;

                            if (window.pys && window.pys.OpenAI) {
                                window.pys.OpenAI.loadPixel();
                            }
                        }, 3000);
                    }

                    return;
                }

                if (identityWaitTimer !== null) {
                    clearTimeout(identityWaitTimer);
                    identityWaitTimer = null;
                }

                !function (w, d, s, u) {
                    if (w.oaiq) return;
                    var q = function () {
                        q.q.push(arguments);
                    };
                    q.q = [];
                    w.oaiq = q;
                    var js = d.createElement(s);
                    js.async = true;
                    js.src = u;
                    var f = d.getElementsByTagName(s)[0];
                    f.parentNode.insertBefore(js, f);
                }(window, document, 'script', 'https://bzrcdn.openai.com/sdk/oaiq.min.js');

                let user = buildAdvancedMatchingUser();

                if (Object.keys(user).length > 0) {
                    sentIdentity = JSON.stringify(user);
                }

                ids.forEach(function (pixelId) {
                    let initOptions = {
                        pixelId: pixelId
                    };

                    if (options.openai.debug) {
                        initOptions.debug = true;
                    }

                    if (Object.keys(user).length > 0) {
                        initOptions.user = user;
                    }

                    oaiq('init', initOptions);
                });

				oaiq('consent', true);

                initialized = true;

                if (options.staticEvents.hasOwnProperty('openai')) {
                    Utils.fireStaticEvents('openai');
                }
            },

            refreshAdvancedMatching: function () {

                if (!initialized || !this.isEnabled() || typeof window.oaiq !== 'function') {
                    return;
                }

                let user = buildAdvancedMatchingUser();

                if (Object.keys(user).length === 0) {
                    return;
                }

                let identity = JSON.stringify(user);

                if (identity === sentIdentity) {
                    return;
                }

                sentIdentity = identity;

                (options.openai.pixelIds || []).forEach(function (pixelId) {
                    oaiq('init', {pixelId: pixelId, user: user});
                });
            },

            fireEvent: function (name, data) {
                if (!initialized || !this.isEnabled()) {
                    return false;
                }
                data.delay = data.delay || 0;

                if (data.delay === 0) {
                    fireEvent(name, data);
                } else {
                    setTimeout(function (name, params) {
                        fireEvent(name, params);
                    }, data.delay * 1000, name, data);
                }
                return true;
            },

            onClickEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAddToCartOnButtonEvent: function (product_id) {
                if (!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag())) {
                    return;
                }
                if (!window.pysWooProductData || !window.pysWooProductData.hasOwnProperty(product_id)) {
                    return;
                }
                if (!window.pysWooProductData[product_id].hasOwnProperty(this.tag())) {
                    return;
                }

                var productData = window.pysWooProductData[product_id][this.tag()];
                var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                Utils.copyProperties(productData['params'], event.params);

                if (productData.hasOwnProperty('pixelIds')) {
                    event.pixelIds = productData['pixelIds'];
                }

                this.fireEvent(event.name, event);
            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {
                if (!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag())) {
                    return;
                }
                // The click handler passes the parent id from input[name="add-to-cart"];
                // the selected variation lives in its own hidden input. Without this swap
                // OpenAI reported the parent while facebook, ga, google_ads and gtm all
                // reported the variation, even though wooVariableAsSimple was off.
                if (product_type === Utils.PRODUCT_VARIABLE && !options.openai.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }
                if (!window.pysWooProductData || !window.pysWooProductData.hasOwnProperty(product_id)) {
                    return;
                }
                if (!window.pysWooProductData[product_id].hasOwnProperty(this.tag())) {
                    return;
                }

                var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                Utils.copyProperties(window.pysWooProductData[product_id][this.tag()]['params'], event.params);

                // The server priced one unit; scale the quantity and the money that
                // depends on it. Amounts are already integer minor units, so the
                // multiplication stays integral. A global value is a fixed number
                // per event and is left alone.
                if (qty && event.params && event.params.data) {
                    var data = event.params.data;

                    if (Array.isArray(data.contents)) {
                        data.contents.forEach(function (item) {
                            item.quantity = qty;
                        });
                    }

                    if (typeof data.amount === 'number'
                        && options.woo.addToCartOnButtonValueEnabled
                        && options.woo.addToCartOnButtonValueOption !== 'global') {
                        data.amount = Math.round(data.amount * qty);
                    }
                }

                this.fireEvent(event.name, event);
            },

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {
                if (!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag())) {
                    return;
                }
                if (!window.pysEddProductData || !window.pysEddProductData.hasOwnProperty(download_id)) {
                    return;
                }

                var index = price_index ? download_id + '_' + price_index : download_id;

                if (!window.pysEddProductData[download_id].hasOwnProperty(index)) {
                    return;
                }
                if (!window.pysEddProductData[download_id][index].hasOwnProperty(this.tag())) {
                    return;
                }

                var event = Utils.clone(options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()]);

                Utils.copyProperties(window.pysEddProductData[download_id][index][this.tag()].params, event.params);

                // Same as the Woo handler: the server priced one unit.
                if (qty && event.params && event.params.data) {
                    var data = event.params.data;

                    if (Array.isArray(data.contents)) {
                        data.contents.forEach(function (item) {
                            item.quantity = qty;
                        });
                    }

                    if (typeof data.amount === 'number'
                        && options.edd.addToCartOnButtonValueEnabled
                        && options.edd.addToCartOnButtonValueOption !== 'global') {
                        data.amount = Math.round(data.amount * qty);
                    }
                }

                this.fireEvent(event.name, event);
            },
        }
    }(options);

    var Awin = function (options) {

        let initialized = false,
            sentConsent = null,
            clickHandedOver = false;

        /**
         * The server keeps the click in HttpOnly cookies, but it saw this page
         * before the visitor consented. Hand it the landing parameters once
         * consent is there; the cookies come back as response headers.
         */
        function handClickToServer() {
            if (clickHandedOver || !options.ajaxUrl || typeof window.fetch !== 'function') {
                return;
            }

            let query;

            try {
                query = new URLSearchParams(window.location.search || '');
            } catch (e) {
                return;
            }

            let awc = query.get('awc'),
                source = query.get('source');

            if (!awc && !source) {
                return;
            }

            clickHandedOver = true;

            let body = new URLSearchParams();
            body.append('action', 'pys_awin_click');

            if (awc) {
                body.append('awc', awc);
            }
            if (source) {
                body.append('source', source);
            }
            if (query.get('sn')) {
                body.append('sn', query.get('sn'));
            }

            // Let the consent plugin store the choice this request has to carry.
            window.setTimeout(function () {
                window.fetch(options.ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    keepalive: true,
                    body: body
                }).catch(function () {
                });
            }, 300);
        }

        /**
         * The visitor's consent as Awin should hear it.
         */
        function hasConsent() {
            if (options.gdpr && (options.gdpr.all_disabled_by_api || options.gdpr.awin_disabled_by_api)) {
                return false;
            }

            return !!Utils.consentGiven('awin');
        }

        function tracking() {
            // Never reset the object: that would wipe a consent state set before us.
            window.AWIN = window.AWIN || {};
            window.AWIN.Tracking = window.AWIN.Tracking || {};

            return window.AWIN.Tracking;
        }

        function setConsent(consent) {
            let awinTracking = tracking();

            // The MasterTag re-runs the whole tracking, the sale included, on
            // every status call, so only a real change may reach it.
            if (sentConsent === consent) {
                return;
            }

            sentConsent = consent;

            // The status call is ignored while the flag is still undefined.
            awinTracking.AdvertiserConsent = consent;

            if (awinTracking.Consent && typeof awinTracking.Consent.setAdvertiserConsentStatus === 'function') {
                awinTracking.Consent.setAdvertiserConsentStatus(consent);
            }
        }

        function masterTagOnPage() {
            return !!document.querySelector('script[src*="dwin1.com/"]');
        }

        function appendMasterTag() {
            if (masterTagOnPage()) {
                return;
            }

            let script = document.createElement('script');
            script.setAttribute('defer', 'defer');
            script.type = 'text/javascript';
            script.src = 'https://www.dwin1.com/' + encodeURIComponent(options.awin.advertiserId) + '.js';

            (document.body || document.documentElement).appendChild(script);
        }

        function encoded(value) {
            return encodeURIComponent(value === undefined || value === null ? '' : String(value));
        }

        /**
         * AWIN.Tracking.Sale, declared before the MasterTag reads it.
         */
        function declareSale(sale) {
            let awinTracking = tracking();

            // Another integration already reports this page's sale.
            if (awinTracking.Sale && awinTracking.Sale.orderRef) {
                return false;
            }

            let amount = sale.amount !== undefined ? String(sale.amount) : '0.00';
            let custom = [];

            // Empty values are dropped server-side, so the list may have gaps.
            if (sale.custom && typeof sale.custom === 'object') {
                let keys = Object.keys(sale.custom).map(Number).filter(function (key) {
                    return !isNaN(key);
                });
                let last = keys.length ? Math.max.apply(null, keys) : -1;

                for (let i = 0; i <= last; i++) {
                    custom.push(encoded(sale.custom[i]));
                }
            }

            let declared = {
                amount: amount,
                channel: sale.channel || 'aw',
                orderRef: encoded(sale.orderRef),
                parts: sale.parts || ('DEFAULT:' + amount),
                currency: sale.currency || '',
                voucher: encoded(sale.voucher),
                test: String(sale.test) === '1' ? '1' : '0'
            };

            if (sale.customerAcquisition === 'NEW' || sale.customerAcquisition === 'RETURNING') {
                declared.customerAcquisition = sale.customerAcquisition;
            }

            if (custom.length) {
                declared.custom = custom;
            }

            // The click kept on the server; the MasterTag sends it as cks
            // instead of reading its own cookie, which may be gone by now.
            if (typeof sale.cks === 'string' && /\d+_\d+_.+/.test(sale.cks)) {
                declared.click = sale.cks;
            }

            awinTracking.Sale = declared;

            if (options.debug) {
                console.log('[Awin] Sale', declared, 'plt', sale.plt || [], 'advertiser_id', options.awin.advertiserId);
            }

            // The MasterTag ran before us: ask it to process the sale now.
            if (typeof awinTracking.run === 'function') {
                awinTracking.run();
            }

            window.dispatchEvent(new CustomEvent('awin_event_sent', {
                detail: {
                    eventName: 'Sale',
                    data: declared,
                    pixel_ids: [options.awin.advertiserId]
                }
            }));

            return true;
        }

        return {
            tag: function () {
                return "awin";
            },

            isEnabled: function () {
                return options.hasOwnProperty('awin') && !!options.awin.advertiserId;
            },

            getHidePixel: function () {
                return [];
            },

            disable: function () {
                if (initialized) {
                    setConsent(false);
                }
            },

            /**
             * Consent plugins store the visitor's choice in their own click
             * handler, which may run after ours; decide once it is stored.
             */
            syncConsent: function () {
                let self = this;

                [0, 1000].forEach(function (delay) {
                    window.setTimeout(function () {
                        self.loadPixel();
                    }, delay);
                });
            },

            loadPixel: function () {

                if (!this.isEnabled() || options.awin.excluded) {
                    return;
                }

                let consent = hasConsent();

                if (consent) {
                    handClickToServer();
                }

                if (initialized) {
                    setConsent(consent);
                    return;
                }

                if (!consent && !options.awin.loadBeforeConsent) {
                    return;
                }

                initialized = true;
                setConsent(consent);

                // The sale must exist before the MasterTag loads.
                if (options.staticEvents.hasOwnProperty('awin')) {
                    Utils.fireStaticEvents('awin');
                }

                appendMasterTag();
            },

            fireEvent: function (name, data) {
                if (!initialized || !this.isEnabled()) {
                    return false;
                }

                if (name !== 'Sale' || !data.params || !data.params.sale) {
                    return false;
                }

                return declareSale(data.params.sale);
            },

            // Awin tracks the sale only; the core may still call these.
            onWatchVideo: function () {
            },
            onCommentEvent: function () {
            },
            onFormEvent: function () {
            },
            onDownloadEvent: function () {
            },
            onAdSenseEvent: function () {
            },
            onPageScroll: function () {
            },
            onTime: function () {
            },
            onWooCheckoutProgressStep: function () {
            }
        };
    }(options);

    var Facebook = function (options) {

        var defaultEventTypes = [
            'PageView',
            'ViewContent',
            'Search',
            'AddToCart',
            'AddToWishlist',
            'InitiateCheckout',
            'AddPaymentInfo',
            'Purchase',
            'Lead',

            'Subscribe',
            'CustomizeProduct',
            'FindLocation',
            'StartTrial',
            'SubmitApplication',
            'Schedule',
            'Contact',
            'Donate'
        ];

        var notCachedEventsIds = new Array();
        var isAddToCartFromJs =  options.woo.hasOwnProperty("addToCartCatchMethod")
            && options.woo.addToCartCatchMethod === "add_cart_js";
        if(!isAddToCartFromJs) {
            notCachedEventsIds.push('woo_add_to_cart_on_button_click')
        }

        var initialized = false;

        /**
         * The `version.subdomainIndex.` prefix Meta's format calls for.
         * subdomainIndex is how many labels the cookie's domain has below
         * the public suffix (com=0, example.com=1, www.example.com=2), so it
         * must track cookieDomain()/probeCookieDomain() rather than a
         * hardcoded `fb.1.`. Only new values are affected — an existing
         * cookie is returned untouched.
         */
        var fbValuePrefix = function (){
            var resolved = cookieDomain();
            var scope = resolved ? String(resolved).replace(/^\./, '') : '';
            if (!scope) {
                try { scope = String(location.hostname || ''); } catch (e) { scope = ''; }
            }
            var dots = scope ? scope.split('.').length - 1 : 0;
            return 'fb.' + dots + '.' + Date.now() + '.';
        };
        // Meta's keep-or-replace rule for an _fbp the browser already holds,
        // as ParamBuilder 1.3.2 applies it: four dot-separated parts are kept
        // as they are, a fifth only if it is a valid appendix token. Nothing is
        // appended. PHP twins: pys_fb_valid_appendix() / pys_fbp_is_valid() in
        // includes/functions-fb-cookies.php.
        var pysFbValidAppendix = function (suffix) {
            suffix = String(suffix);
            var tokens = ['AQ', 'Ag', 'Aw', 'BA', 'BQ', 'Bg'];

            if (suffix.length === 2) {
                return tokens.indexOf(suffix) !== -1;
            }
            if (suffix.length !== 8 || !/^[A-Za-z0-9_-]+$/.test(suffix)) {
                return false;
            }

            var decoded;
            try {
                decoded = atob(suffix.replace(/-/g, '+').replace(/_/g, '/'));
            } catch (e) {
                return false;
            }

            return decoded.length === 6
                && decoded.charCodeAt(0) === 1
                && decoded.charCodeAt(1) >= 1
                && decoded.charCodeAt(1) <= tokens.length;
        };
        var pysFbpIsValid = function (v) {
            if (!v) return false;
            var p = String(v).split('.');
            if (p.length === 4) return true;
            if (p.length === 5) return pysFbValidAppendix(p[4]);
            return false;
        };
        var genereateFbp = function (){
            var existing = Cookies.get('_fbp');
            return pysFbpIsValid(existing) ? existing : fbValuePrefix()+Math.floor(Math.random() * 2147483648);
        };
        var genereateFbc = function (){
            return getUrlParameter('fbclid') ? fbValuePrefix()+getUrlParameter('fbclid') : ''
        };

        // The click id inside an _fbc value: segment 4 of
        // fb.<subdomain_index>.<creation_time>.<fbclid>[.<appendix>], indexed
        // from the front so an appendix is never taken for the click id.
        // PHP twin: pys_fbc_click_id() in includes/functions-fb-cookies.php.
        var fbcClickId = function (value) {
            var parts = String(value || '').split('.');

            return parts.length >= 4 && parts[0] === 'fb' ? parts[3] : '';
        };

        var configuredPixels = new Array();
        function fireEvent(name, event) {


            if(typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name,'facebook')) {
                return;
            }

            var data = event.params;
            var ids = event.pixelIds.filter(function (pixelId) {
                return !Utils.hideMatchingPixel(pixelId, 'facebook');
            });

            var actionType = defaultEventTypes.includes(name) ? 'trackSingle' : 'trackSingleCustom';

            var params = {};

            Utils.copyProperties(data, params);
            Utils.copyProperties(Utils.getRequestParams(), params);
            Utils.copyProperties(Utils.getRequestParams(), data);

            params = Facebook.filterParams(params);


            // sendEventId is true when the token-based Conversion API is on OR
            // when Meta-Enabled CAPI is on for at least one of the pixels on the
            // page: in both cases Meta receives a second, API-side copy of this
            // event and dedupes it by eventID. Only the token-based API needs an
            // actual request from us, so the hook/AJAX branches below stay gated
            // on serverApiEnabled.
            if(options.facebook.sendEventId) {
                if(options.facebook.serverApiEnabled && event.e_id === "woo_remove_from_cart" ) {
                    Facebook.updateEventId(event.name);
                    event.eventID = Facebook.getEventId(event.name);
                } else if(!notCachedEventsIds.includes(event.e_id)) {
                    var isApiDisabled = options.gdpr.all_disabled_by_api ||
                        options.gdpr.facebook_disabled_by_api ||
                        options.gdpr.cookiebot_integration_enabled ||
                        options.gdpr.cookie_notice_integration_enabled ||
                        options.gdpr.consent_magic_integration_enabled ||
                        options.gdpr.cookie_law_info_integration_enabled;
                    // Update eventID

                    event.eventID = Utils.generateUniqueId(event);

                    if(pysFbpIsValid(Cookies.get('_fbp'))){
                        params._fbp = Cookies.get('_fbp');
                    }
                    if(Cookies.get('_fbc')){
                        params._fbc = Cookies.get('_fbc');
                    }
                    // send event from server if they was bloc by gdpr or need send with delay
                    if( options.facebook.serverApiEnabled && ( options.ajaxForServerEvent || isApiDisabled ) ){
                        var json = {
                            action: 'pys_api_event',
                            pixel: 'facebook',
                            event: name,
                            event_slug: event.e_id,
                            ids: ids,
                            data:params,
                            url:window.location.href,
                            eventID:event.eventID,
                            ajax_event:options.ajax_event
                        };

                        if(event.hasOwnProperty('woo_order')) {
                            json['woo_order'] = event.woo_order;
                        }

                        if(event.hasOwnProperty('edd_order')) {
                            json['edd_order'] = event.edd_order;
                        }

                        // Forward the order key so the server can bind the
                        // purchase event to its specific order (RestPurchaseGuard).
                        if(event.hasOwnProperty('order_key') && event.order_key) {
                            json['order_key'] = event.order_key;
                        }

                        if (pageReferrer) {
                            json.referrer_url = pageReferrer;
                        }

                        let delay = 0;
                        try {
                            if (sessionStorage) {
                                Object.keys(sessionStorage)
                                    .filter(key => key.startsWith('wc_fragments_'))
                                    .forEach((key) => {
                                        let value = sessionStorage.getItem(key);
                                        if (event.e_id === 'woo_add_to_cart_on_button_click') {
                                            delay = 2000;
                                        }
                                    });
                            }
                        } catch (error) {
                            console.error('sessionStorage is not accessible:', error);
                        }

                        if (event.e_id === "automatic_event_internal_link" || event.e_id === "automatic_event_outbound_link") {
                            delay = delay === 0 ? 500 : delay;
                            setTimeout(() => Utils.sendServerAjaxRequest(options.ajaxUrl, json), delay);
                        } else if (event.type != 'static') {
                            setTimeout(() => Utils.sendServerAjaxRequest(options.ajaxUrl, json), delay);
                        }

                        if ( ( event.type == 'static' && options.ajaxForServerStaticEvent ) || ( event.hasOwnProperty( 'ajaxFire' ) && event.ajaxFire ) ) {
                            setTimeout( () => Utils.sendServerAjaxRequest( options.ajaxUrl, json ), delay );
                        }
                    }

                    if( options.facebook.serverApiEnabled && event.e_id !== "automatic_event_signup" && name == "CompleteRegistration" && options.facebook.wooCRSendFromServer ) {
                        return;
                    }
                }

            }
            delete params._fbp;
            delete params._fbc;
            if (options.debug) {
                console.log('[Facebook] ' + name, params,"pixel_ids",ids,"eventID",event.eventID);
            }
            // fire event for each pixel id
            ids.forEach(function (pixelId) {
                // add eventID for deduplicate events @see https://developers.facebook.com/docs/marketing-api/conversions-api/deduplicate-pixel-and-server-events/
                var args = {};
                if(options.facebook.sendEventId && event.hasOwnProperty('eventID')) {
                    args.eventID = event.eventID;
                }
                Facebook.maybeInitPixel(pixelId);
                fbq(actionType,pixelId, name, params,args);
            });
            var customEvent = new CustomEvent('facebook_event_sent', {
                detail: {
                    eventName: name,
                    params: params,
                    pixel_ids: ids
                }
            });
            window.dispatchEvent(customEvent);
        }

        /**
         * Public API
         */
        return {
            tag: function() {
                return "facebook";
            },
            isEnabled: function () {
                return options.hasOwnProperty('facebook');
            },
            getHidePixel: function(){
                if(this.isEnabled() && options.facebook.hasOwnProperty('hide_pixels'))
                {
                    return options.facebook.hide_pixels;
                }
                return [];
            },
            initEventIdCookies: function (key) {
                var ids = {};
                ids[key] = pys_generate_token(36)
                Cookies.set('pys_fb_event_id', JSON.stringify(ids), {path: '/',domain: cookieDomain()});
            },

            updateEventId:function(key) {
                var cooData = Cookies.get("pys_fb_event_id")
                if(cooData === undefined) {
                    this.initEventIdCookies(key);
                } else {
                    var data = JSON.parse(cooData);
                    data[key] = pys_generate_token(36);
                    Cookies.set('pys_fb_event_id', JSON.stringify(data), {path: '/',domain: cookieDomain()} );
                }
            },

            getEventId:function (key) {
                var data = Cookies.get("pys_fb_event_id");
                if(data === undefined) {
                    this.initEventIdCookies(key);
                    data = Cookies.get("pys_fb_event_id");
                }
                return JSON.parse(data)[key];
            },

            disable: function () {
                initialized = false;
            },

            filterParams: function (params) {
                var filteredParams = {};

                if (options.facebook.hasOwnProperty('enabled_medical') && options.facebook.enabled_medical && options.facebook.hasOwnProperty('do_not_track_medical_param')) {
                    // Remove empty strings from the array
                    options.facebook.do_not_track_medical_param = options.facebook.do_not_track_medical_param.filter(Boolean);
                    for (const key in params) {
                        if (Array.isArray(options.facebook.do_not_track_medical_param)) {
                            if (!options.facebook.do_not_track_medical_param.includes(key)) {
                                filteredParams[key] = params[key];
                            }
                        }
                    }
                }
                else {
                    Utils.copyProperties(params, filteredParams);
                }
                return filteredParams;
            },

            /**
             * Load pixel's JS
             */
            loadPixel: function () {
                if (initialized || !this.isEnabled() || !Utils.consentGiven('facebook')) {
                    return;
                }

                // First visit: wait (briefly) for this browser's external_id, so
                // the very first PageView is not sent under the inline value.
                if (Utils.holdForIdentity(function () { Facebook.loadPixel(); })) {
                    return;
                }

                ! function (f, b, e, v, n, t, s) {
                    if (f.fbq) return;
                    n = f.fbq = function () {
                        n.callMethod ?
                            n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                    };
                    if (!f._fbq) f._fbq = n;
                    n.push = n;
                    n.loaded = !0;
                    n.version = '2.0';
                    n.agent = 'dvpixelyoursite';
                    n.queue = [];
                    t = b.createElement(e);
                    t.async = !0;
                    t.src = v;
                    s = b.getElementsByTagName(e)[0];
                    s.parentNode.insertBefore(t, s)
                }(window,
                    document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
                // Report the cookie domain here too, not just from
                // manageCookies(): this runs under the `facebook` pixel's own
                // consent, which can differ from and outlast the `pys`
                // script's consent (e.g. under ConsentMagic's separate
                // category assignments), so PHP might otherwise never learn
                // the scope for a visitor who only accepted this pixel.
                //
                // `pys_cd` only ever appears here alongside a cookie we are
                // already writing at that scope, so it can never be the first
                // cookie a visitor receives. disabled_all_cookie is still
                // honoured, matching the call in manageCookies().
                if (!options.cookie || !options.cookie.disabled_all_cookie) {
                    reportCookieDomain(cookieDomain());
                }

                // Meta's cookies keep their own lifetime: cookie_duration is the
                // "First Visit" attribution window and defaults to 7 days, which
                // would mint a new browser identity every week. PHP twin:
                // pys_fb_cookie_lifetime(). The fallback covers a page cached
                // before the option existed.
                let expires = parseInt(options.fb_cookie_duration) || 90;
                if(!pysFbpIsValid(Cookies.get('_fbp'))) {
                    Cookies.set('_fbp',genereateFbp(),  { expires: expires,path: '/',domain: cookieDomain() });
                }

                // A new click replaces the stored value, so a returning visitor
                // is reported under the ad they just clicked. The same click id
                // does not: rewriting would move creation_time and tell Meta the
                // click just happened. PHP twin: pys_fbc_needs_refresh().
                var urlFbclid = getUrlParameter('fbclid');

                if (urlFbclid && fbcClickId(Cookies.get('_fbc')) !== urlFbclid) {
                    Cookies.set('_fbc',genereateFbc(),  { expires: expires,path: '/',domain: cookieDomain() });
                }

                // Now that Facebook consent is confirmed, mirror the session
                // entry referrer (if any) into the session cookie so PHP can
                // use it as a fallback for orphan server-only events.
                getOrInitSessionEntryReferrer(true);

                // Refresh the per-page event referrer cookie so checkout
                // hooks can snapshot the buyer's prior page.
                writeEventReferrerCookie();

                var ids = options.facebook.pixelIds.filter(function (pixelId) {
                    return !Utils.hideMatchingPixel(pixelId, 'facebook');
                });
                // initialize default pixel
                ids.forEach(function (pixelId) {
                    Facebook.maybeInitPixel(pixelId);
                });
                initialized = true;

                Utils.fireStaticEvents('facebook');

            },
            advancedMatching: function () {
                if(options.facebook.advancedMatchingEnabled) {
                    let advancedMatching = {};
                    if(Object.keys(options.facebook.advancedMatching).length > 0) {
                        advancedMatching = options.facebook.advancedMatching;
                    }

                    Utils.AdvancedMatching.merge(advancedMatching, {
                        em: { field: 'email',      hash: false },
                        ph: { field: 'phone',      hash: false },
                        fn: { field: 'first_name', hash: false },
                        ln: { field: 'last_name',  hash: false }
                    });

                    if(!advancedMatching.hasOwnProperty("external_id")){
                        if (Cookies.get('pbid')) {
                            advancedMatching["external_id"] = Cookies.get('pbid');
                        }
                    }
                    else if(advancedMatching.hasOwnProperty("external_id") && advancedMatching.external_id != Cookies.get('pbid'))
                    {
                        advancedMatching["external_id"] = Cookies.get('pbid') ? Cookies.get('pbid') : advancedMatching.external_id;
                    }

                    if(Object.keys(advancedMatching).length > 0) {
                        return advancedMatching;
                    }
                }
                return false
            },
            maybeInitPixel: function(pixelId) {

                if(configuredPixels.includes(pixelId)) return;

                if (options.facebook.removeMetadata || Utils.hideMatchingPixel(pixelId, this.tag())) {
                    fbq('set', 'autoConfig', false, pixelId);
                }
                let advancedMatching = Facebook.advancedMatching();

                let lduMode = +options.facebook.meta_ldu === 1;

                // On a cached page only CS_Data is refreshed for the current visitor
                if ( options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== 'undefined'
                    && typeof CS_Data.cs_meta_ldu_mode !== 'undefined' ) {
                    lduMode = Utils.csModeEnabled( CS_Data.cs_meta_ldu_mode );
                }

                if ( lduMode ) {
                    fbq( 'dataProcessingOptions', [ 'LDU' ], 0, 0 );
                }

                // Meta-Enabled Conversion API: let Meta build its own API events
                // out of this pixel's data. Must run right before init, and the
                // opt-in is per pixel id.
                if (Utils.isMetaEnabledCapiPixel(pixelId)) {
                    fbq('optinMetaEnabledCapi', pixelId);
                }

                if (options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== "undefined") {
                    if(!advancedMatching) {
                        fbq('init', pixelId);
                    } else {
                        var test_prefix = CS_Data.test_prefix;
                        var cs_advanced_matching = Cookies.get('cs_enabled_advanced_matching'+test_prefix);
                        if (jQuery('#cs_enabled_advanced_matching'+test_prefix).length > 0) {
                            if (cs_advanced_matching == 'yes') {
                                fbq('init', pixelId, advancedMatching);
                            } else {
                                fbq('init', pixelId);
                            }
                        } else {
                            fbq('init', pixelId, advancedMatching);
                        }
                    }
                } else {
                    if(!advancedMatching) {
                        fbq('init', pixelId);
                    }  else {
                        fbq('init', pixelId, advancedMatching);
                    }
                }
                configuredPixels.push(pixelId);
            },

            fireEvent: function (name, data) {

                if (!initialized || !this.isEnabled()) {
                    return false;
                }

                data.delay = data.delay || 0;
                data.params = data.params || {};

                if (data.delay === 0) {

                    fireEvent(name, data);

                } else {

                    setTimeout(function (name, params) {
                        fireEvent(name, params);
                    }, data.delay * 1000, name, data);

                }

                return true;

            },

            onAdSenseEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onClickEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWatchVideo: function (event) {
                this.fireEvent(event.name, event);
            },

            onCommentEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onFormEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onDownloadEvent: function (event) {
                this.fireEvent(event.name, event);

            },


            onWooAddToCartOnButtonEvent: function (product_id) {

                window.pysWooProductData = window.pysWooProductData || {};
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('facebook')) {

                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()])

                        Utils.copyProperties(window.pysWooProductData[product_id]['facebook']['params'], event.params)
                        event.pixelIds = window.pysWooProductData[product_id]['facebook']['pixelIds'];
                        this.fireEvent(event.name, event);
                    }
                }
            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {

                window.pysWooProductData = window.pysWooProductData || {};
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                if (product_type === Utils.PRODUCT_VARIABLE && !options.facebook.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('facebook')) {

                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click.facebook);


                        Utils.copyProperties(window.pysWooProductData[product_id]['facebook']['params'], event.params);

                        var groupValue = 0;
                        if(product_type === Utils.PRODUCT_GROUPED ) {
                            $form.find(".woocommerce-grouped-product-list .qty").each(function(index){
                                var childId = $(this).attr('name').replaceAll("quantity[","").replaceAll("]","");
                                var quantity = parseInt($(this).val());
                                if(isNaN(quantity)) {
                                    quantity = 0;
                                }
                                var childItem = window.pysWooProductData[product_id]['facebook'].grouped[childId];

                                if(quantity == 0) {
                                    event.params.content_ids.forEach(function(el,index,array) {
                                        if(el == childItem.content_id) {
                                            array.splice(index, 1);
                                        }
                                    });
                                }

                                if(event.params.hasOwnProperty('contents')) {
                                    event.params.contents.forEach(function(el,index,array) {
                                        if(el.id == childItem.content_id) {
                                            if(quantity > 0){
                                                el.quantity = quantity;
                                            } else {
                                                array.splice(index, 1);
                                            }
                                        }
                                    });
                                }


                                groupValue += childItem.price * quantity;
                            });
                            if(groupValue == 0) return; // skip if no items selected
                        }



                        // maybe customize value option
                        if (options.woo.addToCartOnButtonValueEnabled && options.woo.addToCartOnButtonValueOption !== 'global') {

                            if(product_type === Utils.PRODUCT_GROUPED) {
                                event.params.value = groupValue;
                            } else if(product_type === Utils.PRODUCT_BUNDLE) {
                                var data = $(".bundle_form .bundle_data").data("bundle_form_data");
                                var items_sum = getBundlePriceOnSingleProduct(data);
                                event.params.value = (parseFloat(data.base_price) + items_sum )* qty;
                            } else {
                                event.params.value = event.params.value * qty;
                            }
                        }

                        // only when non Facebook for WooCommerce logic used
                        if (event.params.hasOwnProperty('contents') && product_type !== Utils.PRODUCT_GROUPED) {
                            event.params.contents[0].quantity = qty;

                        }

                        var event_name = is_external ? options.woo.affiliateEventName : event.name;

                        this.fireEvent(event_name, event);

                    }
                }

            },

            onWooRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAffiliateEvent: function (product_id) {
                if(!options.dynamicEvents.woo_affiliate.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.woo_affiliate[this.tag()]);


                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('facebook')) {

                        Utils.copyProperties(window.pysWooProductData[product_id][this.tag()].params, event.params)
                        this.fireEvent(options.woo.affiliateEventName, event);

                    }
                }

            },

            onWooPayPalEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {
                if(!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()]);

                if (window.pysEddProductData && window.pysEddProductData.hasOwnProperty(download_id)) {

                    var index;

                    if (price_index) {
                        index = download_id + '_' + price_index;
                    } else {
                        index = download_id;
                    }

                    if (window.pysEddProductData[download_id].hasOwnProperty(index)) {
                        if (window.pysEddProductData[download_id][index].hasOwnProperty('facebook')) {

                            Utils.copyProperties(window.pysEddProductData[download_id][index]['facebook']["params"], event.params)

                            // maybe customize value option
                            if (options.edd.addToCartOnButtonValueEnabled && options.edd.addToCartOnButtonValueOption !== 'global') {
                                event.params.value = event.params.value * qty;
                            }

                            // update contents qty param
                            var contents = event.params.contents;
                            contents[0].quantity = qty;
                            event.params.contents = contents;

                            this.fireEvent(event.name,event);

                        }
                    }

                }

            },

            onEddRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },
            onPageScroll: function (event) {
                this.fireEvent(event.name, event);
            },
            onTime: function (event) {
                this.fireEvent(event.name, event);
            },
        };

    }(options);

    /**
     * One config per Google Ads conversion ID, with Enhanced Conversions and the
     * cross-domain linker in that same call. Called by whichever of the GA4 and
     * Ads loaders runs first: every AW config sends a remarketing hit, so a bare
     * config followed by an EC one counted the page view twice.
     */
    function configureGoogleAdsIds(ids) {
        var ecIds = options.google_ads.enhanced_conversion_ids;
        if (!Array.isArray(ecIds)) {
            // Options from a page cached before enhanced_conversion_ids existed:
            // index_N is the position in the unfiltered conversion_ids.
            var markers = options.google_ads.enhanced_conversion;
            markers = Array.isArray(markers) ? markers : (markers && typeof markers === 'object' ? Object.values(markers) : []);
            ecIds = options.google_ads.conversion_ids.filter(function (id, index) {
                return markers.indexOf('index_' + index) !== -1;
            });
        }

        ids.forEach(function (conversion_id) {
            var config = {};

            if (ecIds.indexOf(conversion_id) !== -1) {
                config.allow_enhanced_conversions = true;
            }

            // Cross-Domain tracking
            if (options.google_ads.crossDomainEnabled) {
                config.linker = {
                    accept_incoming: options.google_ads.crossDomainAcceptIncoming,
                    domains: options.google_ads.crossDomainDomains
                };
            }

            Utils.gtagPush('config', conversion_id, config);

            Utils.registerGadsPhoneConversion(conversion_id);
        });
    }

    var Analytics = function (options) {

        var initialized = false;

        /**
         * Fires event
         *
         * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/sending-data
         * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/events
         * @link: https://developers.google.com/gtagjs/reference/event
         * @link: https://developers.google.com/gtagjs/reference/parameter
         *
         * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/custom-dims-mets
         *
         * @param name
         * @param data
         */
        function fireEvent(name, event) {
            if(typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name,'ga')) {
                return;
            }

            var eventParams = event.params;
            var valuesArray = Object.values(event.trackingIds);
            var ids = valuesArray.filter(function (pixelId) {
                return loadTags.some(loadTag => pixelId.startsWith(loadTag)) && !Utils.hideMatchingPixel(pixelId, 'ga') && !Utils.hideMatchingPixel(pixelId, 'google_ads');
            })

            // Generate unique event_id for deduplication
            eventParams.event_id = Utils.generateUniqueId(event);
            event.eventID = Utils.generateUniqueId(event);

            Utils.copyProperties(Utils.getRequestParams(), eventParams);

            var copyParams = Utils.copyProperties(eventParams, {}); // copy params because mapParamsTov4 can modify it
            var params = mapParamsTov4(ids,name,copyParams)

            var _fireEvent = function (tracking_ids,name,params) {

                // Firing without a destination would park the hit inside gtag.js
                // instead of sending it. Skip, but keep the reason visible: an
                // empty list means the event's trackingIds and the tags actually
                // configured on this page went out of sync.
                if (!Utils.hasSendToTarget(tracking_ids)) {
                    if (options.debug) {
                        console.warn('[Google Analytics] ' + name + ' skipped: no tracking ID left after filtering', {
                            eventTrackingIds: Object.values(event.trackingIds),
                            loadedTags: loadTags
                        });
                    }
                    return;
                }

                params['send_to'] = tracking_ids;

                // Thank-you Purchase: GA4 is the one pixel that confirms from its own
                // callback, which gtag runs once the hit went out (or timed out).
                if ((event.e_id === 'woo_purchase' || event.e_id === 'edd_purchase') && event.purchase_marker) {
                    var purchaseMarker = event.purchase_marker;
                    params.event_callback = function () {
                        Utils.sendPurchaseMarker(purchaseMarker, 'ga');
                    };
                }

                if (options.debug) {
                    console.log('[Google Analytics #' + tracking_ids + '] ' + name, params);
                }

                // Send via gtag
                Utils.gtagPush('event', name, params);

                var customEvent = new CustomEvent('gtag_event_sent', {
                    detail: {
                        eventName: name,
                        params: params,
                        pixel_ids: tracking_ids
                    }
                });
                window.dispatchEvent(customEvent);
            };


            delete params.analytics_storage;
            delete params.ad_storage;
            delete params.ad_user_data;
            delete params.ad_personalization;

            if(options.hasOwnProperty('google_ads')){
                var conversion_event_name = event.e_id;
                switch ( conversion_event_name ) {
                    case "woo_add_to_cart_on_cart_page":
                    case "woo_add_to_cart_on_checkout_page":
                    case "woo_add_to_cart_on_button_click":
                        conversion_event_name = 'woo_add_to_cart';
                        break;
                    case "edd_add_to_cart_on_cart_page":
                    case "edd_add_to_cart_on_checkout_page":
                    case "edd_add_to_cart_on_button_click":
                        conversion_event_name = 'edd_add_to_cart';
                        break;
                    case "automatic_event_adsense":
                    case "automatic_event_comment":
                    case "automatic_event_download":
                    case "automatic_event_email_link":
                    case "automatic_event_form":
                    case "automatic_event_internal_link":
                    case "automatic_event_outbound_link":
                    case "automatic_event_scroll":
                    case "automatic_event_tel_link":
                    case "automatic_event_time_on_page":
                    case "automatic_event_video":
                        conversion_event_name = 'automatic_event';
                        break;
                }

                if (conversion_event_name !== 'automatic_event') {
                    // We replace the event name for the settings key if it is woo_view_item_list
                    const trackEventName = conversion_event_name === 'woo_view_item_list'
                        ? 'woo_view_category'
                        : conversion_event_name;

                    if (typeof options.google_ads[trackEventName + '_conversion_track'] !== 'undefined') {
                        const conversionTrack = options.google_ads[trackEventName + '_conversion_track'];

                        if (conversionTrack === 'conversion') {
                            ids = ids.map(id => id.split('/')[0]);
                        }
                    }
                }
            }


            _fireEvent(ids, name, params);
            if(event.hasOwnProperty('unify') && event.unify){
                isTrackEventForGA.push(name);
            }
        }

        function normalizeEventName(eventName) {

            var matches = {
                ViewContent: 'view_item',
                AddToCart: 'add_to_cart',
                AddToWishList: 'add_to_wishlist',
                InitiateCheckout: 'begin_checkout',
                Purchase: 'purchase',
                Lead: 'generate_lead',
                CompleteRegistration: 'sign_up',
                AddPaymentInfo: 'set_checkout_option'
            };

            return matches.hasOwnProperty(eventName) ? matches[eventName] : eventName;

        }

        function mapParamsTov4(tag,name,param) {
            //GA4 automatically collects a number of parameters for all events
            var hasGA4Tag = false;

            // end
            if (Array.isArray(tag)) {
                hasGA4Tag = tag.some(function (element) {
                    return isv4(element);
                });
            } else if(isv4(tag)) {
                // tag is a string and matches GA4
                hasGA4Tag = true;
            }
            if(hasGA4Tag) {
                delete param.event_category;
                delete param.event_label;
                delete param.ecomm_prodid;
                delete param.ecomm_pagetype;
                delete param.ecomm_totalvalue;
                if(name === 'search') {
                    param['search'] = param.search_term;
                    delete param.search_term;
                    delete param.dynx_itemid;
                    delete param.dynx_pagetype;
                    delete param.dynx_totalvalue;
                }
            }
            return param;
        }

        function isv4(tag) {
            return tag.indexOf('G') === 0;
        }

        /**
         * Public API
         */
        return {
            tag: function() {
                return "ga";
            },
            isEnabled: function () {
                return options.hasOwnProperty('ga');
            },
            getHidePixel: function(){
                if(this.isEnabled() && options.ga.hasOwnProperty('hide_pixels'))
                {
                    return options.ga.hide_pixels;
                }
                return [];
            },
            disable: function () {
                initialized = false;
            },
            updateEnhancedConversionData : function () {
                if (!initialized || !this.isEnabled()) {
                    return;
                }
                if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable) {
                    var advanced = Utils.getAdvancedMergeFormData();
                    if (Object.keys(advanced).length > 0) {
                        Utils.gtagPush('set', 'user_data', advanced);
                    }
                }
            },
            loadPixel: function () {
                if (initialized || !this.isEnabled() || !Utils.consentGiven('analytics')) {
                    return;
                }


                for (var i = 0; i < options.ga.trackingIds.length; i++) {
                    var trackingId = options.ga.trackingIds[i];
                    if (!Utils.hideMatchingPixel(trackingId, 'ga')) {
                        Utils.loadGoogleTag(trackingId);
                        break;
                    }
                }


                if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable){
                    var advanced = Utils.getAdvancedMergeFormData();
                    if(Object.keys(advanced).length > 0){
                        Utils.gtagPush('set', 'user_data', advanced);
                    }
                }

                var config = {};

                if(options.user_id && options.user_id != 0) {
                    config.user_id = options.user_id;
                }
                config.url_passthrough = options.ga.url_passthrough;
                // Cross-Domain tracking
                if (options.ga.crossDomainEnabled) {
                    config.linker = {
                        accept_incoming: options.ga.crossDomainAcceptIncoming,
                        domains: options.ga.crossDomainDomains
                    };
                }

                var ids = options.ga.trackingIds.filter(function (pixelId) {
                    return !Utils.hideMatchingPixel(pixelId, 'ga');
                });
                loadTags.push(...ids);
                ids.forEach(function (trackingId,index) {

                    var obj = options.ga.isDebugEnabled;
                    var searchValue = "index_"+index;
                    var config_for_tag = Object.assign({}, config);
                    config_for_tag.debug_mode = false;
                    config_for_tag.send_page_view = !options.ga.custom_page_view_event;
                    for (var key in obj) {
                        if (obj[key] === searchValue) {
                            config_for_tag.debug_mode = true;
                            break;
                        }
                    }
                    if(!config_for_tag.debug_mode)
                    {
                        delete config_for_tag.debug_mode;
                    }

                    if(isv4(trackingId)) {
                        if(options.ga.disableAdvertisingPersonalization) {
                            config_for_tag.allow_ad_personalization_signals = false
                        }
                    }
                    if(options.ga.hasOwnProperty('additionalConfig')){
                        if(options.ga.additionalConfig.hasOwnProperty(trackingId) && options.ga.additionalConfig[trackingId]){
                            config_for_tag.first_party_collection = options.ga.additionalConfig[trackingId].first_party_collection;
                        }

                    }
                    if(options.ga.hasOwnProperty('serverContainerUrls')){
                        if(options.ga.serverContainerUrls.hasOwnProperty(trackingId) && options.ga.serverContainerUrls[trackingId].enable_server_container != false){
                            if(options.ga.serverContainerUrls[trackingId].server_container_url != ''){
                                config_for_tag.server_container_url = options.ga.serverContainerUrls[trackingId].server_container_url;
                            }
                            if(options.ga.serverContainerUrls[trackingId].transport_url != ''){
                                config_for_tag.transport_url = options.ga.serverContainerUrls[trackingId].transport_url;
                            }
                        }
                    }
                    if (options.gdpr.cookiebot_integration_enabled && typeof Cookiebot !== 'undefined') {
                        var cookiebot_consent_category = options.gdpr['cookiebot_analytics_consent_category'];
                        if (options.gdpr['analytics_prior_consent_enabled']) {
                            if (Cookiebot.consented === true && Cookiebot.consent[cookiebot_consent_category]) {
                                Utils.gtagPush('config', trackingId, config_for_tag);
                            }
                        } else {
                            if (Cookiebot.consent[cookiebot_consent_category]) {
                                Utils.gtagPush('config', trackingId, config_for_tag);
                            }
                        }
                    }
                    else
                    {
                        Utils.gtagPush('config', trackingId, config_for_tag);
                    }
                });
                if(!isAdsLoad && GAds.isEnabled() && options.google_ads.conversion_ids.length > 0 && Utils.consentGiven('google_ads')) {
                    for (var i = 0; i < options.google_ads.conversion_ids.length; i++) {
                        var trackingId = options.google_ads.conversion_ids[i];
                        if (!Utils.hideMatchingPixel(trackingId, 'google_ads')) {
                            Utils.loadGoogleTag(trackingId);
                            break;
                        }
                    }
                    var ids = options.google_ads.conversion_ids.filter(function (pixelId) {
                        return !Utils.hideMatchingPixel(pixelId, 'google_ads');
                    });
                    loadTags.push(...ids);
                    configureGoogleAdsIds(ids);
                    isAdsLoad = true;
                }

                initialized = true;

                Utils.fireStaticEvents('ga');
                $( document).trigger( "analytics_initialized")
            },

            fireEvent: function (name, data) {

                if (!initialized || !this.isEnabled()) {
                    return false;
                }

                data.delay = data.delay || 0;
                data.params = data.params || {};

                if (data.delay === 0) {

                    fireEvent(name, data);

                } else {

                    setTimeout(function (name, params) {
                        fireEvent(name, params);
                    }, data.delay * 1000, name, data);

                }

                return true;

            },

            onAdSenseEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onClickEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWatchVideo: function (event) {
                if(!event.hasOwnProperty("youtube_disabled")
                    || !event.youtube_disabled
                    || event.params.video_type !== "youtube") {
                    this.fireEvent(event.name, event);
                }
            },

            onCommentEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onFormEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onDownloadEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onWooAddToCartOnButtonEvent: function (product_id, prod_info = null) {
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('ga')) {
                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);
                        Utils.copyProperties(window.pysWooProductData[product_id]['ga'].params, event.params)
                        event.trackingIds = window.pysWooProductData[product_id]['ga']['trackingIds'];
                        if(prod_info)
                        {
                            if(prod_info['pys_list_name_productlist_id'])
                            {
                                event.params.items[0]['item_list_id'] = prod_info['pys_list_name_productlist_id']
                            }
                            if(prod_info['pys_list_name_productlist_name'])
                            {
                                event.params.items[0]['item_list_name'] =prod_info['pys_list_name_productlist_name']
                            }
                        }
                        this.fireEvent(event.name, event);
                    }
                }

            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form, prod_info) {

                window.pysWooProductData = window.pysWooProductData || {};

                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                if (product_type === Utils.PRODUCT_VARIABLE && !options.ga.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('ga')) {

                        Utils.copyProperties(window.pysWooProductData[product_id]['ga'].params, event.params);


                        if(product_type === Utils.PRODUCT_GROUPED ) {
                            var groupValue = 0;
                            $form.find(".woocommerce-grouped-product-list .qty").each(function(index){
                                var childId = $(this).attr('name').replaceAll("quantity[","").replaceAll("]","");
                                var quantity = parseInt($(this).val());
                                if(isNaN(quantity)) {
                                    quantity = 0;
                                }
                                var childItem = window.pysWooProductData[product_id]['ga'].grouped[childId];
                                event.params.items.forEach(function(el,index,array) {
                                    if(el.id == childItem.content_id) {
                                        if(quantity > 0){
                                            el.quantity = quantity;
                                            el.price = childItem.price;
                                        } else {
                                            array.splice(index, 1);
                                        }
                                    }
                                });
                                groupValue += childItem.price * quantity;
                            });

                            if(options.woo.addToCartOnButtonValueEnabled &&
                                options.woo.addToCartOnButtonValueOption !== 'global' &&
                                event.params.hasOwnProperty('value')) {
                                event.params.value = groupValue;
                            }

                            if(groupValue == 0) return; // skip if no items selected
                        } else {
                            // update items qty param
                            event.params.items[0].quantity = qty;
                        }

                        // maybe customize value option
                        if (options.woo.addToCartOnButtonValueEnabled &&
                            options.woo.addToCartOnButtonValueOption !== 'global' &&
                            product_type !== Utils.PRODUCT_GROUPED)
                        {
                            if(event.params.hasOwnProperty('value')) {
                                event.params.value = event.params.items[0].price * qty;
                            }
                        }

                        if(prod_info)
                        {
                            if(prod_info['pys_list_name_productlist_id'])
                            {
                                event.params.items[0]['item_list_id'] = prod_info['pys_list_name_productlist_id']
                            }
                            if(prod_info['pys_list_name_productlist_name'])
                            {
                                event.params.items[0]['item_list_name'] =prod_info['pys_list_name_productlist_name']
                            }
                        }

                        var eventName = is_external ? options.woo.affiliateEventName : event.name;
                        eventName = normalizeEventName(eventName);

                        this.fireEvent(eventName, event);

                    }
                }

            },

            onWooCheckoutProgressStep: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooSelectContent: function (event) {
                const select_prod_list = {};

                if (event.params.items[0].item_list_name !== undefined) {
                    select_prod_list.list_name = event.params.items[0].item_list_name;
                }

                if (event.params.items[0].item_list_id !== undefined) {
                    select_prod_list.list_id = event.params.items[0].item_list_id;
                }
                const url = new URL(window.location.href);
                select_prod_list.url = url.origin + url.pathname;
                Utils.setProductListCookie('select_prod_list', JSON.stringify(select_prod_list));
                this.fireEvent(event.name, event);
            },

            onWooRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAffiliateEvent: function (product_id) {
                if(!options.dynamicEvents.woo_affiliate.hasOwnProperty(this.tag()))
                    return;
                var event = options.dynamicEvents.woo_affiliate[this.tag()];

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('ga')) {

                        event = Utils.clone(event );
                        Utils.copyProperties(window.pysWooProductData[product_id][this.tag()], event.params)
                        this.fireEvent(normalizeEventName(options.woo.affiliateEventName), event);

                    }
                }

            },

            onWooPayPalEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {
                if(!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()]);


                if (window.pysEddProductData && window.pysEddProductData.hasOwnProperty(download_id)) {

                    var index;

                    if (price_index) {
                        index = download_id + '_' + price_index;
                    } else {
                        index = download_id;
                    }

                    if (window.pysEddProductData[download_id].hasOwnProperty(index)) {
                        if (window.pysEddProductData[download_id][index].hasOwnProperty('ga')) {

                            Utils.copyProperties(window.pysEddProductData[download_id][index]['ga'].params, event.params);

                            // update items qty param
                            event.params.items[0].quantity = qty;

                            this.fireEvent(event.name,event);

                        }
                    }

                }

            },

            onEddRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onPageScroll: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
            onTime: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
        };

    }(options);

    var GAds = function (options) {

        var initialized = false;
        /**
         * Fires event
         *
         * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/sending-data
         * @link: https://developers.google.com/analytics/devguides/collection/gtagjs/events
         * @link: https://developers.google.com/gtagjs/reference/event
         * @link: https://developers.google.com/gtagjs/reference/parameter
         */
        function fireEvent(name, data) {
            if(typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name,'google_ads')) {
                return;
            }
            var _params = Utils.copyProperties(data.params,{});

            _params.event_id = Utils.generateUniqueId(data);

            var ids = data.ids.filter(function (pixelId) {
                return !Utils.hideMatchingPixel(pixelId, 'google_ads');
            });

            var conversionIds = data.hasOwnProperty('conversion_ids') ? data.conversion_ids.filter(function (conversion_id) {
                return !Utils.hideMatchingPixel(conversion_id, 'google_ads');
            }) : [];
            var conversion_labels = data.hasOwnProperty('conversion_labels') ? data.conversion_labels.filter(function (conversion_label) {
                conversion_id = conversion_label.split('/')[0];
                return !Utils.hideMatchingPixel(conversion_id, 'google_ads');
            }) : [];

            Utils.copyProperties(Utils.getRequestParams(), _params);
            var _fireEvent = function (conversion_id,event_name) {

                // Same rule as in the Analytics module: no destination means the
                // hit is parked inside gtag.js, not sent. Reaching here with an
                // empty list means every configured conversion ID was filtered
                // out (hidden pixel, or the conversionIds fallback was empty).
                if (!Utils.hasSendToTarget(conversion_id)) {
                    if (options.debug) {
                        console.warn('[Google Ads] ' + event_name + ' skipped: no conversion ID left after filtering', {
                            ids: data.ids,
                            conversionIds: data.conversion_ids,
                            conversionLabels: data.conversion_labels
                        });
                    }
                    return;
                }

                params = Utils.copyProperties(_params, { send_to: conversion_id });

                if("conversion" === event_name) {
                    delete params.items;
                    delete params.ecomm_pagetype;
                    delete params.ecomm_prodid;
                    delete params.ecomm_totalvalue;
                }

                if (options.debug) {
                    console.log('[Google Ads #' + conversion_id + '] ' + event_name, params);
                }
                Utils.gtagPush('event', event_name, params);
                var customEvent = new CustomEvent('gtag_event_sent', {
                    detail: {
                        eventName: event_name,
                        params: params,
                        pixel_ids: conversion_id
                    }
                });
                window.dispatchEvent(customEvent);

            };


            if ( conversion_labels.length > 0 ) {
                ids = conversion_labels;
                if ( !isTrackEventForGA.includes( name ) ) {
                    _fireEvent( ids, name );
                }
            } else {
                var conversion_event_name = data.e_id;
                switch ( conversion_event_name ) {
                    case "woo_add_to_cart_on_cart_page":
                    case "woo_add_to_cart_on_checkout_page":
                    case "woo_add_to_cart_on_button_click":
                        conversion_event_name = 'woo_add_to_cart';
                        break;
                    case "edd_add_to_cart_on_cart_page":
                    case "edd_add_to_cart_on_checkout_page":
                    case "edd_add_to_cart_on_button_click":
                        conversion_event_name = 'edd_add_to_cart';
                        break;
                    case "automatic_event_adsense":
                    case "automatic_event_comment":
                    case "automatic_event_download":
                    case "automatic_event_email_link":
                    case "automatic_event_form":
                    case "automatic_event_internal_link":
                    case "automatic_event_outbound_link":
                    case "automatic_event_scroll":
                    case "automatic_event_tel_link":
                    case "automatic_event_time_on_page":
                    case "automatic_event_video":
                        conversion_event_name = 'automatic_event';
                        break;
                }

                if (ids.length) {
                    if (conversion_event_name !== 'automatic_event' && options.hasOwnProperty('google_ads')) {
                        // In the same way, we determine the correct name for the settings key.
                        const trackEventName = conversion_event_name === 'woo_view_item_list'
                            ? 'woo_view_category'
                            : conversion_event_name;

                        const conversionTrack = options.google_ads[trackEventName + '_conversion_track'];

                        if (conversionTrack === 'conversion') {
                            _fireEvent(ids, "conversion");
                            ids = conversionIds;
                        }
                    }
                } else {
                    ids = conversionIds;
                }

                if ( !isTrackEventForGA.includes( name ) ) {
                    _fireEvent( ids, name );
                }
            }
        }

        function normalizeEventName(eventName) {

            var matches = {
                ViewContent: 'view_item',
                AddToCart: 'add_to_cart',
                AddToWishList: 'add_to_wishlist',
                InitiateCheckout: 'begin_checkout',
                Purchase: 'purchase',
                Lead: 'generate_lead',
                CompleteRegistration: 'sign_up',
                AddPaymentInfo: 'set_checkout_option'
            };

            return matches.hasOwnProperty(eventName) ? matches[eventName] : eventName;

        }

        /**
         * Public API
         */
        return {
            tag: function() {
                return "google_ads";
            },
            isEnabled: function () {
                return options.hasOwnProperty('google_ads');
            },
            getHidePixel: function(){
                if(this.isEnabled() && options.google_ads.hasOwnProperty('hide_pixels'))
                {
                    return options.google_ads.hide_pixels;
                }
                return [];
            },
            disable: function () {
                initialized = false;
            },

            updateEnhancedConversionData : function () {

                if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable){
                    var advanced = Utils.getAdvancedMergeFormData()
                    Utils.gtagPush('set', 'user_data', advanced);
                }
            },

            loadPixel: function () {

                if (initialized || !this.isEnabled() || !Utils.consentGiven('google_ads')) {
                    return;
                }
                if(!isAdsLoad && options.google_ads.conversion_ids.length > 0){
                    for (var i = 0; i < options.google_ads.conversion_ids.length; i++) {
                        var trackingId = options.google_ads.conversion_ids[i];
                        if (!Utils.hideMatchingPixel(trackingId, 'google_ads')) {
                            Utils.loadGoogleTag(trackingId);
                            break;
                        }
                    }

                    var ids = options.google_ads.conversion_ids.filter(function (pixelId) {
                        return !Utils.hideMatchingPixel(pixelId, 'google_ads');
                    });
                    loadTags.push(...ids);
                    configureGoogleAdsIds(ids);

                    if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable){
                        var advanced = Utils.getAdvancedMergeFormData()
                        Utils.gtagPush('set', 'user_data', advanced);
                    }
                    isAdsLoad = true;
                }

                initialized = true;

                Utils.fireStaticEvents('google_ads');

            },

            fireEvent: function (name, data) {

                if (!initialized || !this.isEnabled()) {
                    return false;
                }

                data.delay = data.delay || 0;
                data.params = data.params || {};
                data.ids = data.ids || [];
                data.conversion_labels = data.conversion_labels || [];

                if (data.delay === 0) {
                    fireEvent(name, data);
                } else {
                    setTimeout(function (name, data) {
                        fireEvent(name, data);
                    }, data.delay * 1000, name, data);
                }

                return true;

            },

            onAdSenseEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onClickEvent: function (action, params) {
                //disabled
            },

            onWatchVideo: function (event) {
                this.fireEvent(event.name, event);
            },

            onCommentEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onFormEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onDownloadEvent: function (event) {
                this.fireEvent(event.name, event);
            },




            onWooAddToCartOnButtonEvent: function (product_id) {

                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('google_ads')) {

                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()])
                        Utils.copyProperties(window.pysWooProductData[product_id]['google_ads']['params'].params, event.params)
                        event["ids"] = window.pysWooProductData[product_id]['google_ads']['ids']
                        event["conversion_labels"] = window.pysWooProductData[product_id]['google_ads']['conversion_labels']
                        this.fireEvent(event.name, event);
                    }
                }

            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form) {

                window.pysWooProductData = window.pysWooProductData || {};
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                if (product_type === Utils.PRODUCT_VARIABLE && !options.google_ads.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('google_ads')) {

                        Utils.copyProperties(window.pysWooProductData[product_id]['google_ads']["params"], event.params);
                        event["ids"] = window.pysWooProductData[product_id]['google_ads']['ids']
                        event["conversion_labels"] = window.pysWooProductData[product_id]['google_ads']['conversion_labels']

                        var groupValue = 0;
                        if(product_type === Utils.PRODUCT_GROUPED ) {
                            $form.find(".woocommerce-grouped-product-list .qty").each(function(index){
                                var childId = $(this).attr('name').replaceAll("quantity[","").replaceAll("]","");
                                var quantity = parseInt($(this).val());
                                if(isNaN(quantity)) {
                                    quantity = 0;
                                }

                                var childItem = window.pysWooProductData[product_id]['google_ads'].grouped[childId];

                                if(options.woo.addToCartOnButtonValueEnabled &&
                                    options.woo.addToCartOnButtonValueOption !== 'global') {

                                    event.params.items.forEach(function(el,index,array) {
                                        if(el.id == childItem.content_id) {
                                            if(quantity > 0){
                                                el.quantity = quantity;
                                                el.price = childItem.price;
                                            } else {
                                                array.splice(index, 1);
                                            }
                                        }
                                    });
                                }
                                groupValue += childItem.price * quantity;
                            });
                            if(groupValue == 0) return;
                            event.params.value = groupValue;
                        } else {
                            // update items qty param
                            event.params.items[0].quantity = qty;
                        }



                        // maybe customize value option
                        if (options.woo.addToCartOnButtonValueEnabled &&
                            options.woo.addToCartOnButtonValueOption !== 'global' &&
                            product_type !== Utils.PRODUCT_GROUPED) {
                            event.params.value =  event.params.value * qty;
                        }



                        var eventName = is_external ? options.woo.affiliateEventName : event.name;
                        eventName = normalizeEventName(eventName);

                        this.fireEvent(eventName, event);

                    }
                }

            },

            onWooRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAffiliateEvent: function (product_id) {
                if(!options.dynamicEvents.woo_affiliate.hasOwnProperty(this.tag()))
                    return;
                var event = options.dynamicEvents.woo_affiliate[this.tag()];

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('google_ads')) {

                        event = Utils.clone(event)
                        Utils.copyProperties(window.pysWooProductData[product_id][this.tag()], event.params)
                        this.fireEvent(normalizeEventName(options.woo.affiliateEventName), event);

                    }
                }

            },

            onWooPayPalEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {
                if(!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()];


                if (window.pysEddProductData && window.pysEddProductData.hasOwnProperty(download_id)) {

                    var index;

                    if (price_index) {
                        index = download_id + '_' + price_index;
                    } else {
                        index = download_id;
                    }

                    if (window.pysEddProductData[download_id].hasOwnProperty(index)) {
                        if (window.pysEddProductData[download_id][index].hasOwnProperty('google_ads')) {

                            event = Utils.clone(event)
                            Utils.copyProperties(window.pysEddProductData[download_id][index]['google_ads']['params'], event.params);
                            event.ids = window.pysEddProductData[download_id][index]['google_ads']['ids']
                            // update items qty param
                            //params.items[0].quantity = qty;

                            this.fireEvent(event.name, event);

                        }
                    }

                }

            },

            onEddRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },
            onPageScroll: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
            onTime: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
        };

    }(options);

    var GTM = function (options) {

        var initialized = false;

        var datalayer_name = 'dataLayer';
        /*
         * @param name
         * @param data
         */
        function fireEvent(name, event) {
            if(typeof window.pys_disable_event_filter === "function" && window.pys_disable_event_filter(name,'gtm')) {
                return;
            }


            var eventParams = event.params;
            var data = event.params;
            var valuesArray = Object.values(event.trackingIds);
            var ids = valuesArray.filter(function (pixelId) {
                return !Utils.hideMatchingPixel(pixelId, 'gtm');
            })
            Utils.copyProperties(Utils.getRequestParams(), eventParams);
            var _fireEvent = function (tracking_id,name,params, event=null) {

                var eventData = {};
                var ContainerCodeHasTag = !options.gtm.gtm_just_data_layer && tracking_id.length > 0;
                if(ContainerCodeHasTag) {
                    params['send_to'] = tracking_id;
                }
                else if(!options.gtm.gtm_just_data_layer){
                    return
                }

                if (params.hasOwnProperty('ecommerce')) {
                    eventData.ecommerce = params.ecommerce;
                    delete params.ecommerce;
                }

                var automatedParams = { ...params };
                [params['manualName'], 'manualName', 'triggerType'].forEach(key => delete automatedParams[key]);
                if(event && (!event.hasOwnProperty('hasAutoParam') || (event.hasOwnProperty('hasAutoParam') && event.hasAutoParam))) {
                    eventData.automatedParameters = automatedParams;
                }

// Move custom parameters to eventData

                if (params.hasOwnProperty(params['manualName'])) {
                    eventData[params['manualName']] = params[params['manualName']];
                    delete params[params['manualName']];
                }

                ['manualName','triggerType'].forEach(key => {
                    if (params.hasOwnProperty(key)) {
                        eventData[key] = params[key];
                        delete params[key];
                    }
                });

                eventData.manualDataLayer = Utils.resolveGtmDataLayerName();

                eventData.event = name;

                if (options.debug) {
                    if (ContainerCodeHasTag){
                        console.log('[Google GTM #' + tracking_id + '] ' + name, eventData);
                    }
                    else {
                        console.log('[Google GTM push to "'+datalayer_name+'"] ' + name, eventData);
                    }
                }
                window[datalayer_name].push(eventData);

                var customEvent = new CustomEvent('gtm_event_sent', {
                    detail: {
                        eventName: name,
                        params: eventData,
                        pixel_ids: tracking_id
                    }
                });
                window.dispatchEvent(customEvent);

            };

            var copyParams = Utils.copyProperties(eventParams, {}); // copy params because mapParamsToGTM can modify it

            var params = mapParamsToGTM(ids,name,copyParams)

            params.event_id = Utils.generateUniqueId(event);

            _fireEvent(ids, name, params, event);
        }

        function normalizeEventName(eventName) {

            var matches = {
                ViewContent: 'view_item',
                AddToCart: 'add_to_cart',
                AddToWishList: 'add_to_wishlist',
                InitiateCheckout: 'begin_checkout',
                Purchase: 'purchase',
                Lead: 'generate_lead',
                CompleteRegistration: 'sign_up',
                AddPaymentInfo: 'set_checkout_option'
            };

            return matches.hasOwnProperty(eventName) ? matches[eventName] : eventName;

        }

        function mapParamsToGTM(tag,name,param) {
            var hasGTM = false;

            // end
            if (Array.isArray(tag)) {
                hasGTM = tag.some(function (element) {
                    return isGTM(element);
                });
            } else if(isGTM(tag)) {
                hasGTM = true;
            }
            if(hasGTM) {
                delete param.event_category;
                delete param.event_label;

                delete param.analytics_storage;
                delete param.ad_storage;
                delete param.ad_user_data;
                delete param.ad_personalization;

                if(name === 'search') {
                    param['search'] = param.search_term;
                    delete param.search_term;
                    delete param.dynx_itemid;
                    delete param.dynx_pagetype;
                    delete param.dynx_totalvalue;
                }
            }
            return param;
        }

        function isGTM(tag) {
            return tag.indexOf('GTM') === 0;
        }
        /**
         * Public API
         */
        return {
            tag: function() {
                return "gtm";
            },
            isEnabled: function () {
                return options.hasOwnProperty('gtm');
            },
            getHidePixel: function(){
                if(this.isEnabled() && options.gtm.hasOwnProperty('hide_pixels'))
                {
                    return options.gtm.hide_pixels;
                }
                return [];
            },
            disable: function () {
                initialized = false;
            },
            updateEnhancedConversionData : function () {
                if (!initialized || !this.isEnabled()) {
                    return;
                }
                if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable) {
                    var advanced = Utils.getAdvancedMergeFormData(true);
                    if (Object.keys(advanced).length > 0) {
                        window[datalayer_name].push({'user_data' : advanced});
                    }
                }
            },
            loadPixel: function () {

                if (initialized || !this.isEnabled() || !Utils.consentGiven('analytics')) {
                    return;
                }
                datalayer_name = Utils.resolveGtmDataLayerName();

                for (var i = 0; i < options.gtm.trackingIds.length; i++) {
                    var trackingId = options.gtm.trackingIds[i];
                    if (!Utils.hideMatchingPixel(trackingId, 'gtm') && !options.gtm.gtm_just_data_layer) {
                        console.log('[PYS] Google Tag Manager container code loaded');
                        Utils.loadGTMScript(trackingId);
                        break;
                    }
                }

                if(options.gtm.gtm_just_data_layer) {
                    console.warn && console.warn("[PYS] Google Tag Manager container code placement set to OFF !!!");
                    console.warn && console.warn("[PYS] Data layer codes are active but GTM container must be loaded using custom coding !!!");
                    // Send the consent state even when GTM script loading is handled
                    // externally: gtm_just_data_layer with tracking IDs configured skips
                    // loadGTMScript() entirely. When trackingIds is empty, loadGTMScript()
                    // below runs too and would reach this again — pushGTMConsentState()
                    // is idempotent per page load, so the container still sees one command.
                    Utils.pushGTMConsentState( datalayer_name );
                    if(options.gtm.trackingIds.length == 0){
                        Utils.loadGTMScript();
                    }
                }

                if(options.hasOwnProperty("tracking_analytics") && options.tracking_analytics.hasOwnProperty("userDataEnable") && options.tracking_analytics.userDataEnable){
                    var advanced = Utils.getAdvancedMergeFormData(true);
                    if(Object.keys(advanced).length > 0){
                        window[datalayer_name].push({'user_data' : advanced});
                    }
                }


                var config = {};

                if(options.user_id && options.user_id != 0) {
                    config.user_id = options.user_id;
                }

                // Cross-Domain tracking

                var ids = options.gtm.trackingIds.filter(function (pixelId) {
                    return !Utils.hideMatchingPixel(pixelId, 'gtm');
                });


                initialized = true;

                Utils.fireStaticEvents('gtm');
            },

            fireEvent: function (name, data) {

                if (!initialized || !this.isEnabled()) {
                    return false;
                }

                data.delay = data.delay || 0;
                data.params = data.params || {};

                if (data.delay === 0) {

                    fireEvent(name, data);

                } else {

                    setTimeout(function (name, params) {
                        fireEvent(name, params);
                    }, data.delay * 1000, name, data);

                }

                return true;

            },

            onAdSenseEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onClickEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWatchVideo: function (event) {
                if(!event.hasOwnProperty("youtube_disabled")
                    || !event.youtube_disabled
                    || event.params.video_type !== "youtube") {
                    this.fireEvent(event.name, event);
                }
            },

            onCommentEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onFormEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onDownloadEvent: function (event) {

                this.fireEvent(event.name, event);

            },

            onWooAddToCartOnButtonEvent: function (product_id, prod_info = null) {
                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('gtm')) {
                        var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);
                        Utils.copyProperties(window.pysWooProductData[product_id]['gtm'].params, event.params)
                        event.trackingIds = window.pysWooProductData[product_id]['gtm']['trackingIds'];


                        if(prod_info)
                        {
                            item = event.params.hasOwnProperty('ecommerce') ? event.params.ecommerce.items[0] : event.params.items[0];

                            if(prod_info['pys_list_name_productlist_id'])
                            {
                                item['item_list_id'] = prod_info['pys_list_name_productlist_id']
                            }
                            if(prod_info['pys_list_name_productlist_name'])
                            {
                                item['item_list_name'] =prod_info['pys_list_name_productlist_name']
                            }
                        }
                        this.fireEvent(event.name, event);
                    }
                }

            },

            onWooAddToCartOnSingleEvent: function (product_id, qty, product_type, is_external, $form, prod_info) {
                window.pysWooProductData = window.pysWooProductData || {};

                if(!options.dynamicEvents.woo_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.woo_add_to_cart_on_button_click[this.tag()]);

                if (product_type === Utils.PRODUCT_VARIABLE && !options.gtm.wooVariableAsSimple) {
                    product_id = parseInt($form.find('input[name="variation_id"]').val());
                }

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('gtm')) {

                        Utils.copyProperties(window.pysWooProductData[product_id]['gtm'].params, event.params);

                        params = event.params.hasOwnProperty('ecommerce') ? event.params.ecommerce : event.params;

                        if(product_type === Utils.PRODUCT_GROUPED ) {
                            var groupValue = 0;
                            $form.find(".woocommerce-grouped-product-list .qty").each(function(index){
                                var childId = $(this).attr('name').replaceAll("quantity[","").replaceAll("]","");
                                var quantity = parseInt($(this).val());
                                if(isNaN(quantity)) {
                                    quantity = 0;
                                }
                                var childItem = window.pysWooProductData[product_id]['gtm'].grouped[childId];

                                params.items.forEach(function(el,index,array) {
                                    if(el.id == childItem.content_id) {
                                        if(quantity > 0){
                                            el.quantity = quantity;
                                            el.price = childItem.price;
                                        } else {
                                            array.splice(index, 1);
                                        }
                                    }
                                });
                                groupValue += childItem.price * quantity;
                            });



                            if(options.woo.addToCartOnButtonValueEnabled &&
                                options.woo.addToCartOnButtonValueOption !== 'global' &&
                                params.hasOwnProperty('value')) {
                                params.value = groupValue;
                            }

                            if(groupValue == 0) return; // skip if no items selected
                        } else {
                            // update items qty param
                            params.items[0].quantity = qty;
                        }

                        // maybe customize value option
                        if (options.woo.addToCartOnButtonValueEnabled &&
                            options.woo.addToCartOnButtonValueOption !== 'global' &&
                            product_type !== Utils.PRODUCT_GROUPED)
                        {
                            if(params.hasOwnProperty('value')) {
                                params.value = params.items[0].price * qty;
                            }
                        }

                        if(prod_info)
                        {
                            if(prod_info['pys_list_name_productlist_id'])
                            {
                                params.items[0]['item_list_id'] = prod_info['pys_list_name_productlist_id']
                            }
                            if(prod_info['pys_list_name_productlist_name'])
                            {
                                params.items[0]['item_list_name'] =prod_info['pys_list_name_productlist_name']
                            }
                        }

                        var eventName = is_external ? options.woo.affiliateEventName : event.name;
                        eventName = normalizeEventName(eventName);

                        this.fireEvent(eventName, event);

                    }
                }

            },

            onWooCheckoutProgressStep: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooSelectContent: function (event) {
                const select_prod_list = {};

                if (event.params.items[0].item_list_name !== undefined) {
                    select_prod_list.list_name = event.params.items[0].item_list_name;
                }

                if (event.params.items[0].item_list_id !== undefined) {
                    select_prod_list.list_id = event.params.items[0].item_list_id;
                }
                const url = new URL(window.location.href);
                select_prod_list.url = url.origin + url.pathname;
                Utils.setProductListCookie('select_prod_list', JSON.stringify(select_prod_list));
                this.fireEvent(event.name, event);
            },

            onWooRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onWooAffiliateEvent: function (product_id) {
                if(!options.dynamicEvents.woo_affiliate.hasOwnProperty(this.tag()))
                    return;
                var event = options.dynamicEvents.woo_affiliate[this.tag()];

                if (window.pysWooProductData.hasOwnProperty(product_id)) {
                    if (window.pysWooProductData[product_id].hasOwnProperty('gtm')) {

                        event = Utils.clone(event );
                        Utils.copyProperties(window.pysWooProductData[product_id][this.tag()], event.params)
                        this.fireEvent(normalizeEventName(options.woo.affiliateEventName), event);

                    }
                }

            },

            onWooPayPalEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onEddAddToCartOnButtonEvent: function (download_id, price_index, qty) {
                if(!options.dynamicEvents.edd_add_to_cart_on_button_click.hasOwnProperty(this.tag()))
                    return;
                var event = Utils.clone(options.dynamicEvents.edd_add_to_cart_on_button_click[this.tag()]);


                if (window.pysEddProductData && window.pysEddProductData.hasOwnProperty(download_id)) {

                    var index;

                    if (price_index) {
                        index = download_id + '_' + price_index;
                    } else {
                        index = download_id;
                    }

                    if (window.pysEddProductData[download_id].hasOwnProperty(index)) {
                        if (window.pysEddProductData[download_id][index].hasOwnProperty('gtm')) {

                            Utils.copyProperties(window.pysEddProductData[download_id][index]['gtm'].params, event.params);
                            item = event.params.hasOwnProperty('ecommerce') ? event.params.ecommerce.items[0] : event.params.items[0];
                            // update items qty param
                            item.quantity = qty;

                            this.fireEvent(event.name,event);

                        }
                    }

                }

            },

            onEddRemoveFromCartEvent: function (event) {
                this.fireEvent(event.name, event);
            },

            onPageScroll: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
            onTime: function (event) {
                if (initialized && this.isEnabled()) {
                    this.fireEvent(event.name, event);
                }
            },
        };

    }(options);

    var getPixelBySlag = function getPixelBySlag(slug) {
        switch (slug) {
            case "facebook": return window.pys.Facebook;
            case "ga": return window.pys.Analytics;
            case "gtm": return window.pys.GTM;
            case "google_ads": return window.pys.GAds;
            case "bing": return window.pys.Bing;
            case "pinterest": return window.pys.Pinterest;
            case "tiktok": return window.pys.TikTok;
            case "openai": return window.pys.OpenAI;
            case "awin": return window.pys.Awin;
            case "reddit": return window.pys.Reddit;
        }
    }

    window.pys = window.pys || {};
    window.pys.Facebook = Facebook;
    window.pys.Analytics = Analytics;
    window.pys.GAds = GAds;
    window.pys.GTM = GTM;
    window.pys.Utils = Utils;
    window.pys.TikTok = TikTok;
    window.pys.OpenAI = OpenAI;
    window.pys.Awin = Awin;
    window.pys.getPixelBySlag = getPixelBySlag;

    // Allow external scripts (e.g. generatePixelCode fragments) to refresh
    // the uniqueId cache for a given event key, so that each new add_to_cart
    // action gets a fresh shared ID across all pixels.
    window.pys.setEventUniqueId = function(idKey, newId) {
        uniqueId[idKey] = newId;
    };

    window.pys.fireAjaxTriggerEvent = function(slug, eventData) {
        var pixel = getPixelBySlag(slug);
        if (!pixel) return;

        // Extract the eventId the same way PHP does (custom_event_post_id takes priority over e_id).
        var eventId = (eventData.custom_event_post_id || eventData.e_id) || null;
        // Mirror fireTriggerEvent: respect "once per page" frequency setting.
        if (eventId && options.triggerFrequency && options.triggerFrequency[eventId] === 'once') {
            if (pysEventFiredOnce[eventId]) return;
            pysEventFiredOnce[eventId] = true;
        }

        // Mirror fireTriggerEvent: respect the time-window setting (data already in eventData).
        if (!Utils.isEventInTimeWindow(eventData.name, eventData, 'ajax_' + slug)) return;

        pixel.fireEvent(eventData.name, eventData);
    };

    // Export getPixelBySlag globally for backward compatibility
    window.getPixelBySlag = getPixelBySlag;

    function pysNormalInit() {

        if($("#pys_late_event").length > 0) {
            var dirAttr = $("#pys_late_event").attr("dir");
            if (dirAttr) {
                try {
                    var events = JSON.parse(dirAttr);
                } catch (e) {
                    console.warn("Invalid JSON in pys_late_event dir attribute:", e);
                }
            } else {
                console.warn("pys_late_event dir attribute is undefined or empty");
            }
            if (events) {
                for (var platform in events) {
                    if (events.hasOwnProperty(platform)) {
                        var platformEvents = events[platform];
                        platformEvents.forEach(function (event) {
                            var eventData = {};
                            eventData[event.e_id] = [event];
                            if (options.staticEvents.hasOwnProperty(platform)) {
                                Object.assign(options.staticEvents[platform], eventData);
                            } else {
                                options.staticEvents[platform] = eventData;
                            }
                        });
                    }
                }
            }
        }

        var Pinterest = Utils.setupPinterestObject();
        var Bing = Utils.setupBingObject();
        var Reddit = Utils.setupRedditObject();
        if(options.hasOwnProperty('cookie'))
        {
            if(options.cookie.externalID_disabled_by_api || options.cookie.disabled_all_cookie)
            {
                Cookies.remove('pbid', { path: '/',domain: cookieDomain() })
            }
            if(options.cookie.disabled_advanced_form_data_cookie || options.cookie.disabled_all_cookie)
            {
                // Removed twice on purpose: PHP writes this cookie host-only
                // until pys_cd is reported (or permanently, on a site whose
                // front end never reaches manageCookies()), while this script
                // writes/deletes it at cookieDomain(). A host-only cookie and
                // a domain-scoped one of the same name are separate jar
                // entries, and a delete only matches the scope it names — so
                // both scopes are cleared rather than guessed at.
                // `domain: ''` is deliberate: js-cookie 2.1.3 treats a falsy
                // Domain as "omit the attribute" (host-only delete), so it's
                // written explicitly rather than left off.
                Cookies.remove('pys_advanced_form_data', { path: '/',domain: cookieDomain() })
                Cookies.remove('pys_advanced_form_data', { path: '/',domain: '' })
            }

            if(options.cookie.disabled_landing_page_cookie || !options.enable_lading_page_param || options.cookie.disabled_all_cookie)
            {
                Cookies.remove('pys_landing_page', { path: '/',domain: cookieDomain() })
                Cookies.remove('last_pys_landing_page', { path: '/',domain: cookieDomain() })
            }
            if(options.cookie.disabled_trafficsource_cookie || options.cookie.disabled_all_cookie)
            {
                Cookies.remove('pysTrafficSource', { path: '/',domain: cookieDomain() })
                Cookies.remove('last_pysTrafficSource', { path: '/',domain: cookieDomain() })
            }
            if(options.cookie.disabled_first_visit_cookie || options.cookie.disabled_all_cookie)
            {
                Cookies.remove('pys_first_visit', { path: '/',domain: cookieDomain() })

            }
            if(options.cookie.disabled_utmTerms_cookie || options.cookie.disabled_all_cookie)
            {
                $.each(Utils.utmTerms, function (index, name) {
                    Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                });
                $.each(Utils.utmTerms, function (index, name) {
                    Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                });
            }
            if(options.cookie.disabled_utmId_cookie || options.cookie.disabled_all_cookie)
            {
                $.each(Utils.utmId,function(index,name) {
                    Cookies.remove('pys_' + name, { path: '/',domain: cookieDomain() })
                })
                $.each(Utils.utmId,function(index,name) {
                    Cookies.remove('last_pys_' + name, { path: '/',domain: cookieDomain() })
                });
            }
        }

        // Exactly one manageCookies() per init, and under a consent
        // integration only once consent is on record. The old fall-through
        // ran it a second time under CookieYes, racing two pbid requests, and
        // ran it before any consent when no CookieYes cookie existed yet.
        // external_id itself does not depend on this: the visitor key is
        // computed server-side without a cookie.
        var cookiesManaged = false;

        if (options.gdpr.cookie_law_info_integration_enabled) {
            var cli_cookie = Cookies.get('cookieyes-consent') ?? Cookies.get('wt_consent') ?? Cookies.get('viewed_cookie_policy');

            if (typeof cli_cookie !== 'undefined') {
                if (cli_cookie === Cookies.get('cookieyes-consent') || cli_cookie === Cookies.get('wt_consent')) {
                    if (getCookieYes('analytics') === 'yes') {
                        Utils.manageCookies();
                        cookiesManaged = true;
                    }
                } else if (cli_cookie === Cookies.get('viewed_cookie_policy') && cli_cookie == 'yes') {
                    Utils.manageCookies();
                    cookiesManaged = true;
                }
            }
        }

        if ( ! cookiesManaged ) {
            if ( options.gdpr.consent_magic_integration_enabled && typeof CS_Data !== "undefined" ) {
                if ( CS_Data.cs_script_cat.pys == CS_Data.cs_necessary_cat_id || CS_Data.cs_script_cat.pys == 0 ) {
                    Utils.manageCookies();
                } else if ( Cookies.get( 'cs_enabled_cookie_term' + CS_Data.test_prefix + '_' + CS_Data.cs_script_cat.pys ) == 'yes' ) {
                    Utils.manageCookies();
                }
            } else if ( ! options.gdpr.cookie_law_info_integration_enabled ) {
                Utils.manageCookies();
            }
        }

        Utils.initializeRequestParams();
        Utils.setupGdprCallbacks();

        if ( options.enable_auto_save_advance_matching ) {
            let override = options.data_persistency == 'recent_data';
            // Setup Advanced Form Data
            if ( options.advance_matching_form.enable_advance_matching_forms ) {

                // Handle Email fields
                $( document ).on( "blur", "input[type='email']", function () {
                    // SECURITY: Ignore fields located inside the Authorize.Net payment block
                    if ( $( this ).closest('.payment_method_anet').length > 0 ) return;

                    let email = $( this ).val().trim().toLowerCase();
                    if ( Utils.validateEmail( email ) ) {
                        Utils.saveAdvancedFormData( email, null, null, null, override );
                    }
                } )

                // Handle Telephone fields (This is where Credit Card numbers were being captured)
                $( document ).on( "blur", "input[type='tel']", function () {
                    // SECURITY: Ignore fields located inside the Authorize.Net payment block
                    if ( $( this ).closest('.payment_method_anet').length > 0 ) return;

                    let phone = $( this ).val().trim().replace( /\D/g, "" );
                    if ( phone.length > 5 ) {
                        Utils.saveAdvancedFormData( null, phone, null, null, override );
                    }
                } )

                // Handle Text fields
                $( document ).on( "blur", "input[type='text']", function () {
                    // SECURITY: Ignore fields located inside the Authorize.Net payment block
                    if ( $( this ).closest('.payment_method_anet').length > 0 ) return;

                    let name;
                    if ( $( this ).attr( "name" ) && $( this ).attr( "name" ) != '' ) {
                        name = $( this ).attr( "name" ).trim()
                    }
                    if ( name && options.advance_matching_form.advance_matching_fn_names.includes( name ) ) {
                        let value = $( this ).val().trim();
                        if ( value.length > 0 ) {
                            Utils.saveAdvancedFormData( null, null, value, null, override );
                        }
                    }
                    if ( name && options.advance_matching_form.advance_matching_ln_names.includes( name ) ) {
                        let value = $( this ).val().trim();
                        if ( value.length > 0 ) {
                            Utils.saveAdvancedFormData( null, null, null, value, override );
                        }
                    }
                    if ( name && options.advance_matching_form.advance_matching_tel_names.includes( name ) ) {
                        let value = $( this ).val().trim();
                        if ( value.length > 0 ) {
                            Utils.saveAdvancedFormData( null, value, null, null, override );
                        }
                    }
                    if ( name && options.advance_matching_form.advance_matching_em_names.includes( name ) ) {
                        let email = $( this ).val().trim().toLowerCase();

                        if ( Utils.validateEmail( email ) ) {
                            Utils.saveAdvancedFormData( email, null, null, null, false );
                        }
                    }
                } )
            }

            //Setup Advanced Url Data
            if ( Object.keys( options.advance_matching_url ).length > 0 && options.advance_matching_url.enable_advance_matching_url ) {
                const url_params = new URLSearchParams( window.location.search );
                url_params.forEach( ( value, key ) => {
                    if ( options.advance_matching_url.advance_matching_fn_names.includes( key ) ) {
                        Utils.saveAdvancedFormData( null, null, value.trim(), null, override );
                    }

                    if ( options.advance_matching_url.advance_matching_ln_names.includes( key ) ) {
                        Utils.saveAdvancedFormData( null, null, null, value.trim(), override );
                    }

                    if ( options.advance_matching_url.advance_matching_tel_names.includes( key ) ) {
                        Utils.saveAdvancedFormData( null, value.trim(), null, null, override );
                    }

                    if ( options.advance_matching_url.advance_matching_em_names.includes( key ) ) {
                        let email = value.trim().toLowerCase()
                        if ( Utils.validateEmail( email ) ) {
                            Utils.saveAdvancedFormData( email, null, null, null, override );
                        }
                    }
                } );
            }
        }

        // setup Click Event
        if (
            options.dynamicEvents.hasOwnProperty("automatic_event_internal_link") ||
            options.dynamicEvents.hasOwnProperty("automatic_event_outbound_link") ||
            options.dynamicEvents.hasOwnProperty("automatic_event_tel_link") ||
            options.dynamicEvents.hasOwnProperty("automatic_event_email_link") ||
            options.dynamicEvents.hasOwnProperty("automatic_event_download")
        ) {

            $(document).onFirst('click', 'a, button, input[type="button"], input[type="submit"]', function (e) {

                var $elem = $(this);


                // Download
                if(options.dynamicEvents.hasOwnProperty("automatic_event_download")) {
                    var isFired = false;
                    if ($elem.is('a')) {
                        var href = $elem.attr('href');
                        if (typeof href !== "string") {
                            return;
                        }
                        href = href.trim();
                        var extension = Utils.getLinkExtension(href);
                        var track_download = false;

                        if (extension.length > 0) {

                            if(options.dynamicEvents.hasOwnProperty("automatic_event_download") ) {
                                var pixels = Object.keys(options.dynamicEvents.automatic_event_download);
                                for (var i = 0; i < pixels.length; i++) {
                                    var event = Utils.clone(options.dynamicEvents.automatic_event_download[pixels[i]]);
                                    var extensions = event.extensions;
                                    if (extensions.includes(extension)) {

                                        if(pixels[i] == "tiktok" || pixels[i] == "reddit") {
                                            getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                                        } else {
                                            if (options.enable_remove_download_url_param) {
                                                href = stripUrlQuery(href);
                                            }
                                            event.params.download_url = href;
                                            event.params.download_type = extension;
                                            event.params.download_name = Utils.getLinkFilename(href);
                                            getPixelBySlag(pixels[i]).onDownloadEvent(event);
                                        }

                                        isFired = true;
                                    }
                                }
                            }
                        }
                    }
                    if(isFired) { // prevent duplicate events on the same element
                        return;
                    }
                }


                if (!e.hasOwnProperty('originalEvent')) {
                    return;
                }
                if($elem.hasClass("add_to_cart_button") ||
                    $elem.hasClass("single_add_to_cart_button") ) { // add_to_cart_button fire in woo
                    return;
                }

                if(options.dynamicEvents.hasOwnProperty("wcf_add_to_cart_on_next_step_click")
                    && $elem.hasClass("wcf-next-step-link")) {
                    return;// add_to_cart_button fire in woo cf
                }
                if(options.dynamicEvents.hasOwnProperty("wcf_add_to_cart_on_bump_click")
                    && $elem.hasClass("wcf-bump-order-cb")) {
                    return;// add_to_cart_button fire in woo cf
                }

                if($elem.hasClass("remove_from_cart_button") ) { // cancel remove from cart
                    return;
                }
                if($elem.hasClass("remove") ) { // cancel remove from cart
                    if($elem.parents('.cart_item').length || $elem.parents('.mini_cart_item').length)
                        return;
                }
                if($elem.attr("name") == "update_cart" || $elem.attr("name") == "apply_coupon") { // cancel update  cart or coupon button
                    return;
                }


                if ($elem.hasClass('pys_block')) {
                    return; // avoiding fake double clicks from Affiliate event
                }
                var text = "";
                var target_url = "";
                var linkType = "Internal Click";

                if ($elem.is('a')) {
                    var href = $elem.attr('href');

                    // fixes #112
                    if (typeof href !== "string") {
                        return;
                    }
                    href = href.trim();

                    text = $elem.contents().filter(function() {
                        return this.nodeType === 3; // Filter text nodes only
                    }).text().trim();
                    if(options.enable_remove_target_url_param) {
                        target_url = stripUrlQuery(href);
                    } else {
                        target_url = href
                    }


                    //Email Event
                    if ( href.startsWith( 'mailto:' ) ) {
                        if ( options.triggerEventTypes.hasOwnProperty( "email_link" ) ) {
                            return;
                        } else {
                            setupEmailLinks();
                        }

                        return; // not fire next
                    }

                    // Phone
                    if (href.startsWith('tel:')) {
                        if(options.dynamicEvents.hasOwnProperty("automatic_event_tel_link")) {
                            var pixels = Object.keys(options.dynamicEvents.automatic_event_tel_link);
                            for(var i = 0;i<pixels.length;i++) {
                                var event = Utils.clone(options.dynamicEvents.automatic_event_tel_link[pixels[i]]);
                                if ( pixels[i] !== 'tiktok' && pixels[i] !== 'reddit') {
                                    Utils.copyProperties(Utils.getRequestParams(), event.params);
                                }
                                getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                            }
                        }
                        return; // not fire next
                    }

                    if (href.startsWith('http')) {
                        // link type
                        var host = $elem.context != undefined ? $elem.context.host : $elem[0].host;
                        if (document.location.host != host) {
                            linkType = 'External Click';
                        }
                    }
                } else if ($elem.is('button')) {
                    if( $elem.hasClass("forminator-button-submit")) {
                        //disable duplicate events
                        return;
                    }
                    text = $elem.contents().filter(function() {
                        return this.nodeType === 3; // Filter text nodes only
                    }).text().trim();
                } else if ($elem.is('input[type="button"]')) {
                    text = $elem.val();
                } else if ($elem.is('input[type="submit"]')) {
                    if ( $elem.parents("form.comment-form")) {
                        //disable duplicate events
                        return;
                    }
                    if ($elem.parents("form")) {
                        //disable duplicate events
                        return;
                    }
                    text = $elem.val();
                } else {
                    return;
                }



                text = Utils.filterEmails(text);


                if( linkType === "Internal Click"
                    && options.dynamicEvents.hasOwnProperty("automatic_event_internal_link")
                ) {
                    var pixels = Object.keys(options.dynamicEvents.automatic_event_internal_link);

                    for(var i = 0;i<pixels.length;i++) {
                        var event = Utils.clone(options.dynamicEvents.automatic_event_internal_link[pixels[i]]);

                        if(pixels[i] !== "tiktok" && pixels[i] !== "reddit") { // TT and reddit don't support custom parameters
                            event.params["text"] = text;
                            if(target_url){
                                event.params["target_url"] = target_url;
                            }
                            Utils.copyProperties(Utils.getRequestParams(), event.params);
                        }


                        getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                    }
                }

                if( linkType === "External Click"
                    && options.dynamicEvents.hasOwnProperty("automatic_event_outbound_link")
                ) {
                    var pixels = Object.keys(options.dynamicEvents.automatic_event_outbound_link);

                    for(var i = 0;i<pixels.length;i++) {
                        var event = Utils.clone(options.dynamicEvents.automatic_event_outbound_link[pixels[i]]);

                        if(pixels[i] !== "tiktok" && pixels[i] !== "reddit") { // TT and reddit don't support custom parameters
                            event.params["text"] = text;
                            if(target_url){
                                event.params["target_url"] = target_url;
                            }
                            Utils.copyProperties(Utils.getRequestParams(), event.params);
                        }


                        getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                    }
                }




            });

        }

        // setup AdSense Event
        if (options.dynamicEvents.hasOwnProperty("automatic_event_adsense")) {

            var isOverGoogleAd = false;

            $(document)
                .on('mouseover', 'ins iframe', function () { //class adsbygoogle adsbygoogle-noablate ??
                    isOverGoogleAd = true;
                })
                .on('mouseout', 'iframe', function () {
                    isOverGoogleAd = false;
                });

            $(window)
                .on( "blur",function () {
                    if (isOverGoogleAd) {
                        if(options.dynamicEvents.hasOwnProperty("automatic_event_adsense")) {
                            var pixels = Object.keys(options.dynamicEvents.automatic_event_adsense);
                            for (var i = 0; i < pixels.length; i++) {
                                var event = Utils.clone(options.dynamicEvents.automatic_event_adsense[pixels[i]]);
                                if ( pixels[i] !== 'tiktok' && pixels[i] !== 'reddit') {
                                    Utils.copyProperties(Utils.getRequestParams(), event.params);
                                }
                                getPixelBySlag(pixels[i]).onAdSenseEvent(event);
                            }
                        }

                        $.each(options.triggerEventTypes, function (triggerType, events) {
                            $.each(events, function (eventId, triggers) {
                                switch (triggerType) {
                                    case 'ad_sense_click':
                                        Utils.handleTriggerFired(eventId, triggerType);
                                        break;
                                }
                            });
                        });
                    }
                })
                .trigger("focus");

        }

        //setup adsense for custom events
        var dynamicAdsenseEventsTriggers = 0
        $.each(options.triggerEventTypes, function (triggerType, events) {
            if(triggerType == "ad_sense_click") {
                dynamicAdsenseEventsTriggers++;
            }
        });
        if (dynamicAdsenseEventsTriggers > 0) {

            var isOverGoogleAd = false;

            $(document)
                .on('mouseover', 'ins > ins > iframe', function () {
                    isOverGoogleAd = true;
                })
                .on('mouseout', 'iframe', function () {
                    isOverGoogleAd = false;
                });

            $(window)
                .on( "blur",function () {
                    if (isOverGoogleAd) {

                        $.each(options.triggerEventTypes, function (triggerType, events) {
                            $.each(events, function (eventId, triggers) {
                                switch (triggerType) {
                                    case 'ad_sense_click':
                                        Utils.handleTriggerFired(eventId, triggerType);
                                        break;
                                }
                            });
                        });
                    }
                })
                .trigger("focus");

        }


        // page scroll event
        if (options.dynamicEvents.hasOwnProperty("automatic_event_scroll")
        ) {

            var singlePageScroll = function () {


                var docHeight = $(document).height() - $(window).height();
                var isFired = false;

                if (options.dynamicEvents.hasOwnProperty("automatic_event_scroll")) {
                    var pixels = Object.keys(options.dynamicEvents.automatic_event_scroll);
                    for(var i = 0;i<pixels.length;i++) {
                        var event = Utils.clone(options.dynamicEvents.automatic_event_scroll[pixels[i]]);
                        var scroll = Math.round(docHeight * event.scroll_percent / 100)// convert % to absolute positions

                        if(scroll < $(window).scrollTop()) {
                            if ( pixels[i] !== 'tiktok' && pixels[i] !== 'reddit') {
                                Utils.copyProperties(Utils.getRequestParams(), event.params);
                            }
                            getPixelBySlag(pixels[i]).onPageScroll(event);
                            isFired = true
                        }
                    }
                }
                if(isFired) {
                    $(document).off("scroll",singlePageScroll);
                }
            }
            $(document).on("scroll",singlePageScroll);
        }


        if (options.dynamicEvents.hasOwnProperty("automatic_event_time_on_page")) {
            var pixels = Object.keys(options.dynamicEvents.automatic_event_time_on_page);
            var time = options.dynamicEvents.automatic_event_time_on_page[pixels[0]].time_on_page; // the same for all pixel
            setTimeout(function(){
                for(var i = 0;i<pixels.length;i++) {
                    var event = Utils.clone(options.dynamicEvents.automatic_event_time_on_page[pixels[i]]);
                    if ( pixels[i] !== 'tiktok' && pixels[i] !== 'reddit') {
                        Utils.copyProperties(Utils.getRequestParams(), event.params);
                    }
                    getPixelBySlag(pixels[i]).onTime(event);
                }
            },time*1000);
        }

        // setup Dynamic events

        $.each(options.triggerEventTypes, function (triggerType, events) {

            $.each(events, function (eventId, triggers) {
                switch (triggerType) {
                    case 'url_click':
                        //@see: Utils.setupURLClickEvents()
                        break;

                    case 'css_click':
                        var cssTriggerData  = Array.isArray(triggers) ? { selectors: triggers, click_count: 1, click_time_limit: 0 } : triggers;
                        var cssSelectors    = cssTriggerData.selectors || triggers;
                        var cssClickCount   = cssTriggerData.click_count || 1;
                        var cssTimeLimit    = parseInt(cssTriggerData.click_time_limit, 10) || 0;
                        Utils.setupCSSClickEvents(eventId, cssSelectors, triggerType, cssClickCount, cssTimeLimit);
                        break;

                    case 'css_mouseover':
                        Utils.setupMouseOverClickEvents(eventId, triggers, triggerType);
                        break;

                    case 'scroll_pos':
                        Utils.setupScrollPosEvents(eventId, triggers, triggerType);
                        break;
                    case 'comment':
                        Utils.setupCommentEvents(eventId, triggers);
                        break;
                    case 'video_view':
                        //@see: Utils.checkYouTubeCompletion() and Utils.addYouTubeEvents()
                        break;

                    case 'form_field':
                        Utils.setupFormFieldEvents(eventId, triggers, triggerType);
                        break;

                    case 'copy_element':
                        Utils.setupCopyElementEvents(eventId, triggers);
                        break;

                    case 'video_speed':
                        Utils.setupVideoSpeedEvents(eventId, triggers);
                        break;
                }

            });

            if ( triggerType == "email_link" ) {
                Utils.setupEmailLinkEvents( events )
            }

        });

        // Global RageClick tracking
        if (options.dynamicEvents.hasOwnProperty('automatic_event_rage_click')) {
            (function() {
                var RAGE_THRESHOLD = Math.max(2, parseInt(options.rage_click_threshold, 10) || 3);
                // rage_click_time_limit from admin in seconds; allow floats (e.g. 1.5); minimum 0.5s.
                var RAGE_TIMEOUT   = Math.max(0.5, parseFloat(options.rage_click_time_limit) || 2) * 1000;
                var rageMap        = typeof WeakMap !== 'undefined' ? new WeakMap() : null;

                if (!rageMap) return;

                // Expanded interactive selector — includes developer-marked elements.
                var INTERACTIVE_SELECTOR =
                    'button, a, input, select, textarea, label, ' +
                    '[role="button"], [role="link"], [onclick], [tabindex], [data-track], [data-testid]';

                // Walk up to the nearest meaningful interactive ancestor.
                // Returns null when none found — non-interactive clicks are silently ignored.
                // Note: having an id alone does NOT make an element interactive
                // (e.g. div#comments, div#reviews are structural, not clickable).
                function findClickTarget(el) {
                    while (el && el !== document.body) {
                        if (el.matches && el.matches(INTERACTIVE_SELECTOR)) {
                            return el;
                        }
                        el = el.parentElement;
                    }
                    return null;
                }

                // Build a breadcrumb path: up to 3 DOM nodes ending at el.
                // Example: "nav#menu > ul.links > button.cta"
                function buildElementPath(el, depth) {
                    depth = depth || 3;
                    var parts = [];
                    var cur = el;
                    while (cur && cur !== document.body && parts.length < depth) {
                        var tag = cur.tagName ? cur.tagName.toLowerCase() : '';
                        var id  = cur.id ? '#' + cur.id : '';
                        var rawCls = cur.className && typeof cur.className === 'string'
                            ? cur.className
                            : (cur.className && cur.className.baseVal ? cur.className.baseVal : '');
                        var cls = rawCls ? '.' + rawCls.trim().split(/\s+/).slice(0, 2).join('.') : '';
                        parts.unshift(tag + id + cls);
                        cur = cur.parentElement;
                    }
                    return parts.join(' > ');
                }

                function describeElement(el) {
                    var raw = el.className && (typeof el.className === 'string'
                        ? el.className
                        : (el.className.baseVal || ''));
                    var classes = raw ? raw.trim().split(/\s+/).slice(0, 3).join(' ') : '';

                    var text = (el.innerText || el.value || el.getAttribute('aria-label') || '')
                        .trim().replace(/\s+/g, ' ').slice(0, 80);

                    var href = el.tagName === 'A' ? (el.getAttribute('href') || '') : '';
                    var tag  = el.tagName ? el.tagName.toLowerCase() : '';
                    var path = buildElementPath(el);

                    // Only include fields with non-empty values — don't pollute the event
                    // payload with empty strings that add noise to dashboards.
                    var result = {};
                    if (tag)     { result.element_tag = tag; result.element = tag; } // element = backward-compat alias
                    if (el.id)   result.element_id      = el.id;
                    if (classes) result.element_classes  = classes;
                    if (text)    result.element_text     = text;
                    if (href)    result.element_href     = href;
                    if (path)    result.element_path     = path;
                    return result;
                }

                document.addEventListener('click', function(event) {
                    // Resolve to the nearest meaningful interactive ancestor.
                    // Non-interactive elements (bare <div>, <span>, <h2> etc.) are silently
                    // ignored — no fallback to event.target.
                    var target = findClickTarget(event.target);
                    if (!target) return;

                    var now = Date.now();
                    var st  = rageMap.get(target) || { count: 0, last: 0, timer: null };

                    if (now - st.last > RAGE_TIMEOUT) st.count = 0;
                    st.count++;
                    st.last = now;

                    if (st.timer) clearTimeout(st.timer);
                    st.timer = setTimeout(function() { rageMap.delete(target); }, RAGE_TIMEOUT);
                    rageMap.set(target, st);

                    if (st.count >= RAGE_THRESHOLD) {
                        rageMap.delete(target);
                        var params = describeElement(target); // contains only non-empty fields

                        Object.keys(options.dynamicEvents.automatic_event_rage_click).forEach(function(slug) {
                            var pysEvent = Utils.clone(options.dynamicEvents.automatic_event_rage_click[slug]);
                            Utils.copyProperties(params, pysEvent.params);
                            var px = getPixelBySlag(slug);
                            if (px) px.fireEvent(pysEvent.name, pysEvent);
                        });
                    }
                }, true);
            })();
        }

        // Global Video Speed tracking
        if (options.dynamicEvents.hasOwnProperty('automatic_event_video_speed')) {
            (function() {
                var pysFireVideoSpeed = function(videoEl, currRate) {
                    var html5Url = videoEl ? (videoEl.src || videoEl.currentSrc || '') : '';
                    var params = {
                        video_url: html5Url,
                        video_type: Utils.getVideoTypeFromUrl(html5Url),
                        video_title: Utils.getHtml5VideoTitle(html5Url),
                        playback_speed: currRate,
                        element: videoEl ? (videoEl.tagName ? videoEl.tagName.toLowerCase() : 'video') : 'video'
                    };
                    Object.keys(options.dynamicEvents.automatic_event_video_speed).forEach(function(slug) {
                        var pysEvent = Utils.clone(options.dynamicEvents.automatic_event_video_speed[slug]);
                        Utils.copyProperties(params, pysEvent.params);
                        var px = getPixelBySlag(slug);
                        if (px) px.fireEvent(pysEvent.name, pysEvent);
                    });
                };

                // HTML5 <video>
                document.addEventListener('ratechange', function(event) {
                    var video = event.target;
                    if (!video || video.tagName !== 'VIDEO') return;
                    var prev = video._pysGlobalSpeedRate !== undefined ? video._pysGlobalSpeedRate : 1;
                    var curr = video.playbackRate;
                    if (prev === curr) return;
                    video._pysGlobalSpeedRate = curr;
                    pysFireVideoSpeed(video, curr);
                }, true);
            })();
        }

        // setup WooCommerce events
        if (options.woo.enabled) {

            // Woo CartFlow AddToCart
            if (options.dynamicEvents.hasOwnProperty("wcf_add_to_cart_on_next_step_click")) {
                $("body").on("click",'.wcf-next-step-link',function () {
                    var pixels = Object.keys(options.dynamicEvents.wcf_add_to_cart_on_next_step_click);
                    for(var i = 0;i<pixels.length;i++) {
                        var event = Utils.clone(options.dynamicEvents.wcf_add_to_cart_on_next_step_click[pixels[i]])
                        getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                    }
                });
            }
            // Woo CartFlow Bump AddToCart
            if(options.dynamicEvents.hasOwnProperty("wcf_add_to_cart_on_bump_click") ||
                options.dynamicEvents.hasOwnProperty("wcf_bump")) {
                $("body").on('change','.wcf-bump-order-cb',function () {

                    if(this.checked) {
                        if(options.dynamicEvents.hasOwnProperty("wcf_add_to_cart_on_bump_click")) {
                            var pixels = Object.keys(options.dynamicEvents.wcf_add_to_cart_on_bump_click);
                            for(var i = 0;i<pixels.length;i++) {
                                var event = Utils.clone(options.dynamicEvents.wcf_add_to_cart_on_bump_click[pixels[i]]);
                                getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                            }
                        }


                        if(options.dynamicEvents.hasOwnProperty("wcf_bump")) {
                            var pixels = Object.keys(options.dynamicEvents.wcf_bump);
                            for(var i = 0;i<pixels.length;i++) {
                                var event = Utils.clone(options.dynamicEvents.wcf_bump[pixels[i]]);
                                getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                            }
                        }

                    } else {
                        if(options.dynamicEvents.hasOwnProperty("wcf_remove_from_cart_on_bump_click")) {
                            var pixels = Object.keys(options.dynamicEvents.wcf_remove_from_cart_on_bump_click);
                            for(var i = 0;i<pixels.length;i++) {
                                var event = Utils.clone(options.dynamicEvents.wcf_remove_from_cart_on_bump_click[pixels[i]]);
                                getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                            }
                        }

                    }


                });
            }


            // WooCommerce AddToCart
            if (options.dynamicEvents.hasOwnProperty("woo_add_to_cart_on_button_click")
                && options.woo.hasOwnProperty("addToCartCatchMethod")
                && options.woo.addToCartCatchMethod === "add_cart_js"
            ) {
                // Loop, any kind of "simple" product, except external
                $('.add_to_cart_button:not(.product_type_variable,.product_type_bundle,.single_add_to_cart_button)').on("click",function (e) {

                    var $button = $(this);
                    var $prod_info = $button.closest('.product').find('.pys_list_name_productdata').data();
                    var product_id = $(this).data('product_id');
                    Utils.setProductListCookie('productlist', JSON.stringify($prod_info))
                    var product_id = $(this).data('product_id');
                    if (typeof product_id !== 'undefined') {

                        if(options.dynamicEvents.hasOwnProperty("woo_add_to_cart_on_button_click")){
                            var tmpEventID = pys_generate_token();
                            $.each(options.dynamicEvents.woo_add_to_cart_on_button_click, function (i, tag) {
                                tag.eventID = tmpEventID;
                                // Also refresh the uniqueId cache so server-API path
                                // (ajaxForServerStaticEvent) gets the same fresh ID.
                                var idKey = tag.hasOwnProperty('custom_event_post_id') ? tag.custom_event_post_id : tag.e_id;
                                uniqueId[idKey] = tmpEventID;
                            });
                        }

                        Facebook.onWooAddToCartOnButtonEvent(product_id,$(this));
                        Analytics.onWooAddToCartOnButtonEvent(product_id, $prod_info);
                        GTM.onWooAddToCartOnButtonEvent(product_id, $prod_info);
                        GAds.onWooAddToCartOnButtonEvent(product_id);
                        Pinterest.onWooAddToCartOnButtonEvent(product_id);
                        Bing.onWooAddToCartOnButtonEvent(product_id);
                        TikTok.onWooAddToCartOnButtonEvent(product_id);
                        Reddit.onWooAddToCartOnButtonEvent(product_id);
                        OpenAI.onWooAddToCartOnButtonEvent(product_id);
                    }

                });

                // Single Product
                // tap try to https://stackoverflow.com/questions/30990967/on-tap-click-event-firing-twice-how-to-avoid-it
                //  $(document) not work
                $('body').onFirst('click','button.single_add_to_cart_button,.single_add_to_cart_button',function (e) {

                    var $button = $(this);
                    var $prod_info = $button.siblings('.pys_list_name_productdata').data();
                    var product_id = $(this).data('product_id');
                    Utils.setProductListCookie('productlist', JSON.stringify($prod_info))
                    if ($button.hasClass('disabled')) {
                        return;
                    }

                    var $form = $button.closest('form');

                    var product_type = Utils.PRODUCT_SIMPLE;
                    var is_external = false;

                    if ($form.length === 0) {
                        is_external = true;
                    } else if ($form.hasClass('variations_form')) {
                        product_type = Utils.PRODUCT_VARIABLE;
                    } else if($form.hasClass('bundle_form')) {
                        product_type = Utils.PRODUCT_BUNDLE;
                    } else if($form.hasClass('grouped_form')) {
                        product_type = Utils.PRODUCT_GROUPED;
                    }



                    var product_id;
                    var qty = 1;
                    if (product_type === Utils.PRODUCT_GROUPED) {
                        qty = 1;
                        product_id = parseInt($form.find('*[name="add-to-cart"]').val());
                    } else if (product_type === Utils.PRODUCT_VARIABLE) {
                        product_id = parseInt($form.find('*[name="add-to-cart"]').val());
                        var qtyTag = $form.find('input[name="quantity"]');
                        if(qtyTag.length <= 0) {
                            qtyTag = $form.find('select[name="quantity"]');
                        }
                        qty = parseInt(qtyTag.val());
                    } else if (is_external) {
                        product_id = options.woo.singleProductId;
                        qty = 1;
                    } else {
                        product_id = parseInt($form.find('*[name="add-to-cart"]').val());
                        var qtyTag = $form.find('input[name="quantity"]');
                        if(qtyTag.length <= 0) {
                            qtyTag = $form.find('select[name="quantity"]');
                        }
                        qty = parseInt(qtyTag.val());
                    }

                    //
                    if(options.dynamicEvents.hasOwnProperty("woo_add_to_cart_on_button_click")){
                        var tmpEventID = pys_generate_token();
                        $.each(options.dynamicEvents.woo_add_to_cart_on_button_click, function (i, tag) {
                            tag.eventID = tmpEventID;
                            // Also refresh the uniqueId cache so server-API path
                            // (ajaxForServerStaticEvent) gets the same fresh ID.
                            var idKey = tag.hasOwnProperty('custom_event_post_id') ? tag.custom_event_post_id : tag.e_id;
                            uniqueId[idKey] = tmpEventID;
                        });
                    }

                    Facebook.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    Analytics.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form, $prod_info);
                    GTM.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form, $prod_info);
                    GAds.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    Pinterest.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    Bing.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    TikTok.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    Reddit.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                    OpenAI.onWooAddToCartOnSingleEvent(product_id, qty, product_type, is_external, $form);
                });

            } else {
                $('.add_to_cart_button:not(.product_type_variable,.product_type_bundle,.single_add_to_cart_button)').on("click",function (e) {
                    var $button = $(this);
                    var $prod_info = $button.siblings('.pys_list_name_productdata').data();
                    var product_id = $(this).data('product_id');
                    Utils.setProductListCookie('productlist', JSON.stringify($prod_info))
                });

                // Single Product
                // tap try to https://stackoverflow.com/questions/30990967/on-tap-click-event-firing-twice-how-to-avoid-it
                //  $(document) not work
                $('body').onFirst('click','button.single_add_to_cart_button,.single_add_to_cart_button',function (e) {

                    var $button = $(this);
                    var $prod_info = $button.siblings('.pys_list_name_productdata').data();
                    Utils.setProductListCookie('productlist', $prod_info)
                });
            }

            // WooCommerce Affiliate
            if (options.dynamicEvents.hasOwnProperty("woo_affiliate")) {

                // Loop, external
                $('.product_type_external').on("click",function (e) {

                    var product_id = $(this).data('product_id');

                    if (typeof product_id !== 'undefined') {
                        Facebook.onWooAffiliateEvent(product_id);
                        Analytics.onWooAffiliateEvent(product_id);
                        GTM.onWooAffiliateEvent(product_id);
                        GAds.onWooAffiliateEvent(product_id);
                        Pinterest.onWooAffiliateEvent(product_id);
                        Bing.onWooAffiliateEvent(product_id);
                    }

                });

            }

            // WooCommerce RemoveFromCart
            if (options.dynamicEvents.hasOwnProperty("woo_remove_from_cart")) {

                $('body').on('click', options.woo.removeFromCartSelector, function (e) {

                    var $a = $(e.currentTarget),
                        href = $a.attr('href');

                    // extract cart item hash from remove button URL
                    var regex = new RegExp("[\\?&]remove_item=([^&#]*)"),
                        results = regex.exec(href);

                    if (results !== null) {

                        var item_hash = results[1];

                        if (options.dynamicEvents["woo_remove_from_cart"].hasOwnProperty(item_hash)) {
                            var events = options.dynamicEvents["woo_remove_from_cart"][item_hash];
                            Utils.fireEventForAllPixel("onWooRemoveFromCartEvent",events)
                        }

                    }

                });

            }

            // WooCommerce PayPal
            if (options.dynamicEvents.hasOwnProperty("woo_paypal")) {

                // Non-default binding used to avoid situations when some code in external js
                // stopping events propagation, eg. returns false, and our handler will never called
                $(document).onFirst('submit click', '#place_order', function (e) {

                    var method = $('form[name="checkout"] input[name="payment_method"]:checked').val();

                    if (method !== 'paypal') {
                        return;
                    }
                    var events = options.dynamicEvents.woo_paypal;
                    Utils.fireEventForAllPixel("onWooPayPalEvent",events)

                });

            }

            // WooCommerce checkout progress
            if(options.dynamicEvents.hasOwnProperty("woo_initiate_checkout_progress_f") ) {

                $(document).on("change",".woocommerce-validated #billing_first_name",function () {
                    var pixels = Object.keys(options.dynamicEvents.woo_initiate_checkout_progress_f);
                    for (var i = 0; i < pixels.length; i++) {
                        var event = Utils.clone(options.dynamicEvents.woo_initiate_checkout_progress_f[pixels[i]]);
                        getPixelBySlag(pixels[i]).onWooCheckoutProgressStep(event);
                    }
                });
            }
            if(options.dynamicEvents.hasOwnProperty("woo_initiate_checkout_progress_l")) {

                $(document).on("change",".woocommerce-validated #billing_last_name",function () {
                    var pixels = Object.keys(options.dynamicEvents.woo_initiate_checkout_progress_l);
                    for (var i = 0; i < pixels.length; i++) {
                        var event = Utils.clone(options.dynamicEvents.woo_initiate_checkout_progress_l[pixels[i]]);
                        getPixelBySlag(pixels[i]).onWooCheckoutProgressStep(event);
                    }
                });
            }

            if(options.dynamicEvents.hasOwnProperty("woo_initiate_checkout_progress_e")) {

                $(document).on("change",".woocommerce-validated #billing_email",function () {
                    var pixels = Object.keys(options.dynamicEvents.woo_initiate_checkout_progress_e);
                    for (var i = 0; i < pixels.length; i++) {
                        var event = Utils.clone(options.dynamicEvents.woo_initiate_checkout_progress_e[pixels[i]]);
                        getPixelBySlag(pixels[i]).onWooCheckoutProgressStep(event);
                    }
                });
            }
            if(options.dynamicEvents.hasOwnProperty("woo_initiate_checkout_progress_o")) {
                $(document).onFirst('submit click', '#place_order', function () {
                    var shippingMethodFull = $('[name="shipping_method[0]"]:checked').val();
                    var shippingMethod = shippingMethodFull ? shippingMethodFull.split(':')[0] : '';
                    var pixels = Object.keys(options.dynamicEvents.woo_initiate_checkout_progress_o);
                    for (var i = 0; i < pixels.length; i++) {
                        var event = Utils.clone(options.dynamicEvents.woo_initiate_checkout_progress_o[pixels[i]]);
                        // Add shipping_method to event params
                        event.params = event.params || {};
                        event.params.checkout_option = shippingMethod;
                        getPixelBySlag(pixels[i]).onWooCheckoutProgressStep(event);
                    }
                });
            }


            // WooCommerce

            $('.product.type-product a.woocommerce-loop-product__link').onFirst('click', function (evt) {
                var productId = $(this).closest('.product').find(".add_to_cart_button").attr("data-product_id");
                var eventTypes = ["woo_select_content_search", "woo_select_content_shop", "woo_select_content_tag", "woo_select_content_single", "woo_select_content_category"];
                var isEventFired = false;

                for (var i = 0; i < eventTypes.length; i++) {
                    var eventType = eventTypes[i];
                    if (options.dynamicEvents.hasOwnProperty(eventType) && options.dynamicEvents[eventType].hasOwnProperty(productId)) {
                        if(Analytics.isEnabled()){
                            Analytics.onWooSelectContent(options.dynamicEvents[eventType][productId][Analytics.tag()]);
                        }
                        if(GTM.isEnabled()){
                            GTM.onWooSelectContent(options.dynamicEvents[eventType][productId][GTM.tag()]);
                        }
                        isEventFired = true;
                        break;
                    }
                }

                if (!isEventFired) {
                    let prod_info = $(this).parent().find('.pys_list_name_productdata').data();
                    if (prod_info) {
                        const select_prod_list = {};
                        if (prod_info['pys_list_name_productlist_name']) {
                            select_prod_list.list_name = prod_info['pys_list_name_productlist_name']
                        }
                        if (prod_info['pys_list_name_productlist_id']) {
                            select_prod_list.list_id = prod_info['pys_list_name_productlist_id']
                        }
                        const url = new URL(window.location.href);
                        select_prod_list.url = url.origin + url.pathname;
                        Utils.setProductListCookie('select_prod_list', JSON.stringify(select_prod_list));
                    }
                }
            });

        }

        // setup EDD events
        if (options.edd.enabled) {

            // EDD AddToCart
            if (options.dynamicEvents.hasOwnProperty("edd_add_to_cart_on_button_click")) {

                $('form.edd_download_purchase_form .edd-add-to-cart').on("click",function (e) {

                    var $button = $(this);
                    var $form = $button.closest('form');
                    var variable_price = $button.data('variablePrice'); // yes/no
                    var price_mode = $button.data('priceMode'); // single/multi
                    var ids = [];
                    var quantities = [];
                    var qty;
                    var id;

                    if (variable_price === 'yes' && price_mode === 'multi') {

                        id = $form.find('input[name="download_id"]').val();

                        // get selected variants
                        $.each($form.find('input[name="edd_options[price_id][]"]:checked'), function (i, el) {
                            ids.push(id + '_' + $(el).val());
                        });

                        // get qty for selected variants
                        $.each(ids, function (i, variant_id) {

                            var variant_index = variant_id.split('_', 2);
                            qty = $form.find('input[name="edd_download_quantity_' + variant_index[1] + '"]').val();

                            if (typeof qty !== 'undefined') {
                                quantities.push(qty);
                            } else {
                                quantities.push(1);
                            }

                        });

                    } else if (variable_price === 'yes' && price_mode === 'single') {

                        id = $form.find('input[name="download_id"]').val();
                        ids.push(id + '_' + $form.find('input[name="edd_options[price_id][]"]:checked').val());

                        qty = $form.find('input[name="edd_download_quantity"]').val();

                        if (typeof qty !== 'undefined') {
                            quantities.push(qty);
                        } else {
                            quantities.push(1);
                        }

                    } else {

                        ids.push($button.data('downloadId'));

                        qty = $form.find('input[name="edd_download_quantity"]').val();

                        if (typeof qty !== 'undefined') {
                            quantities.push(qty);
                        } else {
                            quantities.push(1);
                        }
                    }

                    // fire event for each download/variant
                    $.each(ids, function (i, download_id) {

                        var q = parseInt(quantities[i]);
                        var variant_index = download_id.toString().split('_', 2);
                        var price_index;

                        if (variant_index.length === 2) {
                            download_id = variant_index[0];
                            price_index = variant_index[1];
                        }

                        Facebook.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        Analytics.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        GTM.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        GAds.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        Pinterest.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        Bing.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        TikTok.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        Reddit.onEddAddToCartOnButtonEvent(download_id, price_index, q);
                        OpenAI.onEddAddToCartOnButtonEvent(download_id, price_index, q);

                    });

                });

            }

            // EDD RemoveFromCart
            if (options.dynamicEvents.hasOwnProperty("edd_remove_from_cart") ) {

                $('form#edd_checkout_cart_form .edd_cart_remove_item_btn').on("click",function (e) {

                    var href = $(this).attr('href');
                    var key = href.substring(href.indexOf('=') + 1).charAt(0);

                    if (options.dynamicEvents.edd_remove_from_cart.hasOwnProperty(key)) {
                        var events = options.dynamicEvents.edd_remove_from_cart[key];
                        Utils.fireEventForAllPixel("onEddRemoveFromCartEvent",events)
                    }

                });

            }

        }

        Utils.setupURLClickEvents();

        // setup Comment Event
        if (options.dynamicEvents.hasOwnProperty("automatic_event_comment")
        ) {

            $('form.comment-form').on("submit",function () {
                if (options.dynamicEvents.hasOwnProperty("automatic_event_comment")) {
                    var pixels = Object.keys(options.dynamicEvents.automatic_event_comment);
                    for (var i = 0; i < pixels.length; i++) {
                        var event = Utils.clone(options.dynamicEvents.automatic_event_comment[pixels[i]]);
                        if ( pixels[i] !== 'tiktok' && pixels[i] !== 'reddit') {
                            Utils.copyProperties(Utils.getRequestParams(), event.params);
                        }
                        getPixelBySlag(pixels[i]).onCommentEvent(event);
                    }
                }
            });

        }

        // setup Form Event
        if ( options.dynamicEvents.hasOwnProperty("automatic_event_form")) {

            $(document).onFirst('submit', 'form', function (e) {

                var $form = $(this);

                // exclude WP forms
                const formClass = $form.attr('class') || '';
                const formRole = ($form.attr('role') || '').toLowerCase();
                const formId = $form.attr('id');

                if (
                    $form.hasClass('comment-form') ||
                    $form.hasClass('search-form') ||
                    $form.hasClass('woocommerce-ordering') ||
                    formClass.toLowerCase().includes('search') || formClass.toLowerCase().includes('add-to-cart') ||
                    formRole === 'search' ||
                    formId === 'adminbarsearch'
                ) {
                    return;
                }

                // exclude Woo forms
                if ($form.hasClass('woocommerce-product-search') || $form.hasClass('cart') || $form.hasClass('woocommerce-cart-form') ||
                    $form.hasClass('woocommerce-shipping-calculator') || $form.hasClass('checkout') || $form.hasClass('checkout_coupon')) {
                    return;
                }

                // exclude EDD forms
                if ($form.hasClass('edd_form') || $form.hasClass('edd_download_purchase_form')) {
                    return;
                }
                // exclude CF7 forms
                if ($form.hasClass('wpcf7-form')) {
                    return;
                }
                // exclude Gravity forms
                if ($form.attr('id') && $form.attr('id').includes('gform')) {
                    var target = $form.attr('target');
                    if (target && target.indexOf('gform_ajax_frame') !== -1) {
                        return;
                    }
                }
                // exclude Forminator forms
                if ($form.hasClass('forminator-custom-form') || $form.hasClass('forminator_ajax')) {
                    return;
                }
                // exclude WPforms forms
                if ($form.hasClass('wpforms-form') || $form.hasClass('wpforms-ajax-form')) {
                    return;
                }
                // exclude Formidable forms
                /*if ($form.hasClass('frm-show-form')) {
                    return;
                }*/
                // exclude Ninja Forms forms
                if ($form.parent().hasClass('nf-form-layout')) {
                    return;
                }
                // exclude Fluent forms
                if ($form.hasClass('frm-fluent-form')) {
                    return;
                }

                // exclude WS form forms
                if ($form.hasClass('wsf-form') ) {
                    return;
                }

                // exclude WS form forms
                if ( $form.hasClass( 'elementor-form' ) ) {
                    return;
                }

                // exclude Klaviyo forms: submitted by Klaviyo's script and reported
                // through the klaviyoForms event below; a native submit here is only
                // the Enter key reaching Klaviyo's hidden submit input, before validation
                if ( $form.hasClass( 'klaviyo-form' ) ) {
                    return;
                }

                if(!options.enable_success_send_form) {
                    var params = {
                        form_id: $form.attr('id'),
                        form_class: $form.attr('class') ? $form.attr('class') : $form.attr('id'),
                        text: $form.find('[type="submit"]').is('input') ?
                            $form.find('[type="submit"]').val() : $form.find('[type="submit"]').text()
                    };

                    if (options.dynamicEvents.hasOwnProperty("automatic_event_form")) {
                        var pixels = Object.keys(options.dynamicEvents.automatic_event_form);
                        for (var i = 0; i < pixels.length; i++) {
                            var event = Utils.clone(options.dynamicEvents.automatic_event_form[pixels[i]]);

                            if (pixels[i] === "tiktok" || pixels[i] === "reddit") {
                                getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                            } else {
                                Utils.copyProperties(params, event.params,)
                                Utils.copyProperties(Utils.getRequestParams(), event.params);
                                getPixelBySlag(pixels[i]).onFormEvent(event);
                            }
                        }
                    }
                }
            });


        }

        jQuery(document).on('elementor/popup/show', function(event) {
            for (var i = 0; i < jQuery(".wpcf7-form").length; i++) {
                wpcf7.init(jQuery(".wpcf7-form")[i]);
            }
        });

        document.addEventListener( 'wpcf7mailsent', function ( event ) {
            let form_id = event.detail.contactFormId,
                sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'CF7' ) ) {
                $.each( options.triggerEventTypes.CF7, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                sendEventId = eventId;
                                disabled_form_action = trigger.disabled_form_action;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }
            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'CF7' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );

        }, false );

        //GravityForm
        jQuery( document ).on( 'gform_confirmation_loaded', function ( event, formId ) {
            let form_id = formId,
                sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'gravity' ) ) {
                $.each( options.triggerEventTypes.gravity, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }

            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'gravity' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
            jQuery( document ).off( 'gform_confirmation_loaded' );
        } );
        //Forminator
        $( document ).on( 'forminator:form:submit:success', function ( event ) {

            let form_id = $( event.target ).find( 'input[name="form_id"]' ).val(),
                sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'forminator' ) ) {
                $.each( options.triggerEventTypes.forminator, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }
            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'forminator' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } );

        //WPForm
        $( 'form.wpforms-form' ).on( 'wpformsAjaxSubmitSuccess', ( event ) => {

            let form_id = $( event.target ).attr( 'data-formid' ),
                sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';

            if ( options.triggerEventTypes.hasOwnProperty( 'wpforms' ) ) {
                $.each( options.triggerEventTypes.wpforms, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                sendEventId = eventId;
                                disabled_form_action = trigger.disabled_form_action;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }
            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'wpforms' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } )

        $( document ).on( 'frmFormComplete', function ( event, form, response ) {
            const form_id = $( form ).find( 'input[name="form_id"]' ).val();
            let sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'formidable' ) ) {
                $.each( options.triggerEventTypes.formidable, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }
            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'formidable' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );

        } );

        // Ninja Forms
        $( document ).onFirst( 'nfFormSubmitResponse', function ( event, data ) {
            const form_id = data.response.data.form_id;
            let sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'ninjaform' ) ) {
                $.each( options.triggerEventTypes.ninjaform, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }
            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'ninjaform' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } );


        $(document).on('fluentform_submission_success', function ( event, data ) {
            if(!data || !data.form){
                return;
            }
            let $form = data.form; // Submitted form
            let config = data.config; // Form configuration
            let response = data.response; // Server response


            let $formItem = $form;
            let form_id = config.id;
            let sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'fluentform' ) ) {
                $.each( options.triggerEventTypes.fluentform, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }

            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'fluentform' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } );

        //WSForm
        $( document ).on( 'wsf-submit-complete', ( event, form_object, form_id ) => {
            let sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';
            if ( options.triggerEventTypes.hasOwnProperty( 'wsform' ) ) {
                $.each( options.triggerEventTypes.wsform, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        $.each( trigger.forms, function ( i, value ) {
                            if ( value == form_id ) {
                                disabled_form_action = trigger.disabled_form_action;
                                sendEventId = eventId;
                                form_submit_mode = trigger.form_submit_mode || 'both';
                            }
                        } )
                    } );
                } );
            }

            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'wsform' );
            }
            sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } )

        // Klaviyo Forms. Rendered and submitted by Klaviyo's own script: no page
        // reload and no WordPress request, so this window event is the only
        // signal. 'submit' fires once per form; 'stepSubmit' fires for every step
        // of a multi-step form and is left alone so a Lead is not doubled.
        window.addEventListener( 'klaviyoForms', function ( e ) {
            var detail = e && e.detail ? e.detail : {};
            if ( detail.type !== 'submit' || !detail.formId ) {
                return;
            }

            var form_id = String( detail.formId ),
                meta = detail.metaData && typeof detail.metaData === 'object' ? detail.metaData : {},
                sendEventId = null,
                disabled_form_action = false,
                form_submit_mode = 'both';

            // Klaviyo puts the submitted fields in metaData with a $ prefix
            // ($email, $phone_number); its docs show the keys bare. Read both.
            var metaValue = function ( key ) {
                var v = meta[ '$' + key ] !== undefined ? meta[ '$' + key ] : meta[ key ];
                return typeof v === 'string' && v.trim() !== '' ? v.trim() : null;
            };

            if ( options.advance_matching_form && options.advance_matching_form.enable_advance_matching_forms ) {
                var email = metaValue( 'email' ),
                    phone = metaValue( 'phone_number' ),
                    firstName = metaValue( 'first_name' ),
                    lastName = metaValue( 'last_name' );

                if ( email ) {
                    email = email.toLowerCase();
                    if ( !Utils.validateEmail( email ) ) {
                        email = null;
                    }
                }
                if ( phone ) {
                    phone = phone.replace( /\D/g, '' );
                    if ( phone.length <= 5 ) {
                        phone = null;
                    }
                }
                if ( email || phone || firstName || lastName ) {
                    Utils.saveAdvancedFormData( email, phone, firstName, lastName );
                }
            }

            if ( options.triggerEventTypes.hasOwnProperty( 'klaviyo_forms' ) ) {
                $.each( options.triggerEventTypes.klaviyo_forms, function ( eventId, triggers ) {
                    $.each( triggers, function ( index, trigger ) {
                        var forms = Array.isArray( trigger.forms ) ? trigger.forms : [],
                            // Form IDs are opaque six-character codes and most accounts
                            // have one or two forms: an empty list means every form.
                            matches = forms.length === 0;
                        $.each( forms, function ( i, value ) {
                            if ( value == form_id ) {
                                matches = true;
                            }
                        } );
                        if ( matches ) {
                            sendEventId = eventId;
                            disabled_form_action = trigger.disabled_form_action;
                            form_submit_mode = trigger.form_submit_mode || 'both';
                        }
                    } );
                } );
            }

            if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                Utils.handleTriggerFired( sendEventId, 'klaviyo_forms' );
            }
            // The embed container keeps the form's ID class after Klaviyo swaps
            // the form for its success view; a popup has no container to find.
            sendFormAction( $( '.klaviyo-form-' + form_id ), form_id, sendEventId, disabled_form_action, form_submit_mode );
        } );

        // Elementor Forms
        let forms = document.querySelectorAll( '.elementor-form' );
        // Apply the observer to each form
        forms.forEach( function ( form ) {
            observeElementorForm( form );
        } );

        // watching Elementor Popup forms
        let observer = new MutationObserver( function ( mutationsList, observer ) {
            for ( let i = 0; i < mutationsList.length; i++ ) {
                let popupForm = document.querySelector( '[class*="elementor-popup"] form' );
                if ( popupForm ) {
                    observeElementorForm( popupForm );
                    observer.disconnect();
                    break;
                }
            }
        } );
        observer.observe( document.body, { childList: true, subtree: true } );

        // load pixel APIs
        Utils.loadPixels();

        // setup Enrich content
        if(Utils.isCheckoutPage()) {
            Utils.addCheckoutFields();
        }
        if(options.woo.hasOwnProperty('woo_view_content_variation_is_selected') && options.woo.woo_view_content_variation_is_selected) {
            handleWooViewContentVariation()
        }
    }

    $(document).ready(function () {
        if ( options.dynamicDataUrl ) {
            fetch( options.dynamicDataUrl, {
                method: 'GET',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'Accept': 'application/json' }
            } )
                .then( function(r) { return r.ok ? r.json() : Promise.reject(r.status); } )
                .then( function(dynamic) {
                    // An empty reply ([] for bots, and in Pro for user roles the
                    // plugin is disabled for) means "do not track this visitor".
                    // Going on would set options.cookie to undefined and throw in
                    // pysNormalInit().
                    if ( ! dynamic || ! dynamic.cookie ) {
                        options.dynamicDataApplied = true;
                        if ( options.debug ) console.warn( '[PYS] dynamic-options: tracking is disabled for this visitor.' );
                        return;
                    }

                    options.ajax_event         = dynamic.ajax_event;
                    options.user_id            = dynamic.user_id;
                    options.cache_bypass       = dynamic.cache_bypass;
                    options.tracking_analytics = dynamic.tracking_analytics;
                    if ( dynamic.gdpr_dynamic && options.gdpr ) {
                        Object.assign( options.gdpr, dynamic.gdpr_dynamic );
                        if ( dynamic.gdpr_dynamic.analytics_storage_value !== null )
                            options.gdpr.analytics_storage.value = dynamic.gdpr_dynamic.analytics_storage_value;
                        if ( dynamic.gdpr_dynamic.ad_storage_value !== null )
                            options.gdpr.ad_storage.value = dynamic.gdpr_dynamic.ad_storage_value;
                        if ( dynamic.gdpr_dynamic.ad_user_data_value !== null )
                            options.gdpr.ad_user_data.value = dynamic.gdpr_dynamic.ad_user_data_value;
                        if ( dynamic.gdpr_dynamic.ad_personalization_value !== null )
                            options.gdpr.ad_personalization.value = dynamic.gdpr_dynamic.ad_personalization_value;
                    }
                    options.cookie = dynamic.cookie;
                    // Per-pixel user data (advanced matching) that was emptied out of
                    // the cached HTML. An inline value that still holds something wins:
                    // on pages we never strip (order received / EDD success) the HTML
                    // carries the order's own data, which beats the account-level data
                    // this endpoint can see.
                    if ( dynamic.pixels ) {
                        for ( var slug in dynamic.pixels ) {
                            if ( ! dynamic.pixels.hasOwnProperty( slug ) || ! options[ slug ] ) continue;
                            for ( var key in dynamic.pixels[ slug ] ) {
                                if ( ! dynamic.pixels[ slug ].hasOwnProperty( key ) ) continue;
                                var inline = options[ slug ][ key ];
                                if ( ! inline || Object.keys( inline ).length === 0 ) {
                                    options[ slug ][ key ] = dynamic.pixels[ slug ][ key ];
                                }
                            }
                        }
                    }

                    options.dynamicDataApplied = true;

                    if ( window.pys && window.pys.OpenAI
                        && typeof window.pys.OpenAI.refreshAdvancedMatching === 'function' ) {
                        window.pys.OpenAI.refreshAdvancedMatching();
                    }

                    pysNormalInit();
                } )
                .catch( function(err) {
                    if ( options.debug ) console.warn( '[PYS] dynamic-options fetch failed:', err );

                    options.dynamicDataApplied = true;
                    pysNormalInit();
                } );
        } else {
            pysNormalInit();
        }
    });


    function handleWooViewContentVariation() {
        var form = $('form.variations_form');

        form.on('change', 'select', function() {
            var selectedAttributes = {};
            form.find('select').each(function() {
                var attributeName = $(this).data('attribute_name') || $(this).attr('name');
                var attributeValue = $(this).val();
                if (attributeValue) {
                    selectedAttributes[attributeName] = attributeValue;
                }
            });

            $.ajax({
                url: options.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'get_variation_info',
                    product_id: form.data('product_id'), // Pass the main product ID
                    attributes: selectedAttributes
                },
                success: function(response) {
                    if (response.success) {
                        $.each(response.data, function(slug) {
                            $.each(response.data[slug], function(index, event) {
                                event.isVariationTrigger = true;
                                getPixelBySlag(slug).fireEvent(event.name, event);
                            });
                        });
                    } else {
                        console.log('Error retrieving data:', response.data);
                    }
                }
            });
        });
    }
    function sendFormAction(form_target, formId, customEventId = null, disabled = false, form_submit_mode = 'both'){
        // Check submit mode - skip automatic event if reload_only
        if (disabled == true || form_submit_mode === 'reload_only' ) {
            return;
        }

        var params = {
            form_id: formId,
            text: form_target.find('[type="submit"]').is('input') ? form_target.find('[type="submit"]').val() :
                form_target.find('.forminator-button-submit').text() != '' ? form_target.find('.forminator-button-submit').text() :
                    form_target.find('[type="submit"]').text()
        };

        // Klaviyo submits with a plain <button>; its input[type=submit] is hidden
        // and only yields the browser's default "Submit".
        if ( form_target.find( 'button.klaviyo-form-button' ).length ) {
            params.text = form_target.find( 'button.klaviyo-form-button' ).first().text().trim() || params.text;
        }

        if (options.dynamicEvents.hasOwnProperty("automatic_event_form")) {
            var pixels = Object.keys(options.dynamicEvents.automatic_event_form);
            for (var i = 0; i < pixels.length; i++) {

                if ( disabled && customEventId && typeof options.triggerEvents[customEventId][pixels[i]] !== 'undefined') {
                    continue;
                }
                var event = options.dynamicEvents.automatic_event_form[pixels[i]];
                if (pixels[i] === "tiktok" || pixels[i] === "reddit") {
                    getPixelBySlag(pixels[i]).fireEvent(event.name, event);
                } else {
                    Utils.copyProperties(params, event.params)
                    Utils.copyProperties(Utils.getRequestParams(), event.params);
                    getPixelBySlag(pixels[i]).onFormEvent(event);
                }
            }
        }
    }

    function setupEmailLinks( disabled_for_pixels = [] ) {
        if ( options.dynamicEvents.hasOwnProperty( "automatic_event_email_link" ) ) {
            var pixels = Object.keys( options.dynamicEvents.automatic_event_email_link );
            for ( var i = 0; i < pixels.length; i++ ) {
                if ( disabled_for_pixels.indexOf(pixels[ i ]) === -1 ) {
                    var event = Utils.clone( options.dynamicEvents.automatic_event_email_link[ pixels[ i ] ] );
                    if ( pixels[ i ] !== 'tiktok' && pixels[ i ] !== 'reddit' ) {
                        Utils.copyProperties( Utils.getRequestParams(), event.params );
                    }
                    getPixelBySlag( pixels[ i ] ).fireEvent( event.name, event );
                }
            }
        }
    }

    //Elementor Forms Observer
    function observeElementorForm( form ) {
        let observer = new MutationObserver( function ( mutations ) {

            for ( let i = 0; i < mutations.length; i++ ) {
                let mutation = mutations[ i ];

                if ( mutation.type === 'childList' || mutation.type === 'attributes' ) {
                    if ( $( form ).find( '.elementor-message-success' ).length > 0 ) {

                        let form_id = $( form ).attr( 'id' );
                        if ( !form_id ) {
                            form_id = $( form ).find( 'input[name="form_id"]' ).val();
                        }

                        let sendEventId = null,
                            disabled_form_action = false,
                            form_submit_mode = 'both';
                        if ( options.triggerEventTypes.hasOwnProperty( 'elementor_form' ) ) {
                            $.each( options.triggerEventTypes.elementor_form, function ( eventId, triggers ) {
                                $.each( triggers, function ( index, trigger ) {
                                    $.each( trigger.forms, function ( i, value ) {
                                        if ( value == form_id ) {
                                            disabled_form_action = trigger.disabled_form_action;
                                            sendEventId = eventId;
                                            form_submit_mode = trigger.form_submit_mode || 'both';
                                        }
                                    })
                                } );
                            } );
                        }
                        if ( sendEventId != null && ( form_submit_mode === 'both' || form_submit_mode === 'ajax_only' ) ) {
                            Utils.handleTriggerFired( sendEventId, 'elementor_form' );
                        }
                        sendFormAction( $( event.target ), form_id, sendEventId, disabled_form_action, form_submit_mode );

                        observer.disconnect();
                        break;
                    }
                }
            }
        } );

        // Start observing the form for changes
        observer.observe( form, {
            attributes: true,
            childList: true,
            subtree: true
        } );
    }

}(jQuery, pysOptions);


function pys_generate_token() {
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
}
function getBundlePriceOnSingleProduct(data) {
    var items_sum = 0;
    jQuery(".bundle_form .bundled_product").each(function(index){
        var id = jQuery(this).find(".cart").data("bundled_item_id");
        var item_price = data.prices[id];
        var item_quantity = jQuery(this).find(".bundled_qty").val();
        if(!jQuery(this).hasClass("bundled_item_optional") ||
            jQuery(this).find(".bundled_product_optional_checkbox input").prop('checked')) {
            items_sum += item_price*item_quantity;
        }
    });
    return items_sum;
}
function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            // Twin of ServerEventHelper::getUrlParameter(). A parameter with
            // no '=' has no value; skip it rather than inventing one, so
            // ?fbclid&fbclid=REAL still finds the real one.
            if (sParameterName[1] === undefined) {
                continue;
            }
            try {
                return decodeURIComponent(sParameterName[1]);
            } catch (e) {
                // decodeURIComponent throws on a malformed escape ("%",
                // "%zz", "a%2"). Return the raw value instead of throwing,
                // matching PHP's urldecode(), which is lenient about it.
                return sParameterName[1];
            }
        }
    }
    return false;
};
function inArray(needle, haystack) {
    var length = haystack.length;
    for(var i = 0; i < length; i++) {
        if(haystack[i] == needle) return true;
    }
    return false;
}

function getCookieYesCategory(pixel) {
    return ['analytics', 'ga', 'gtm'].indexOf(pixel) !== -1 ? 'analytics' : 'advertisement';
}
function getCookieYes(key) {
    const cookiesObj = document.cookie
        .split(";")
        .reduce((ac, cv) => {
            const [k, v] = cv.split("=");
            if (k && v) ac[k.trim()] = v;
            return ac;
        }, {});
    const consentCookie = cookiesObj["cookieyes-consent"] || cookiesObj["wt_consent"];
    if (!consentCookie) return undefined;
    const { [key]: value } = consentCookie
        .split(",")
        .reduce((obj, pair) => {
            const [k, v] = pair.split(":");
            if (k && v) obj[k] = v;
            return obj;
        }, {});
    return value;
}

function getRootDomain(useSubdomain = false) {
    const hostname = window.location.hostname; // Get the current hostname
    // Check if tldjs is defined before using it
    if (typeof tldjs === "undefined") {
        console.warn("tldjs is not defined");
        return hostname; // Return hostname as a fallback
    }

    const rootDomain = tldjs.getDomain(hostname); // Use tldjs to extract the root domain

    // Return the root domain with or without a leading dot based on useSubdomain
    return rootDomain ? (useSubdomain ? '.' + rootDomain : rootDomain) : hostname;
}
